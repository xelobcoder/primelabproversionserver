-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2024 at 12:21 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `limsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `activation`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `activation`;
CREATE TABLE `activation` (
  `ID` int(255) NOT NULL,
  `STATUS` varchar(100) NOT NULL DEFAULT 'INACTIVE',
  `PATIENTID` int(100) NOT NULL,
  `DATE` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `activation`:
--

-- --------------------------------------------------------

--
-- Table structure for table `applicationsettings`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `applicationsettings`;
CREATE TABLE `applicationsettings` (
  `keyid` int(255) NOT NULL,
  `bulkregistration` tinyint(1) NOT NULL DEFAULT 0,
  `fontsize` varchar(14) NOT NULL DEFAULT '13px',
  `textcolor` varchar(11) NOT NULL DEFAULT 'black',
  `BackgroundColor` varchar(50) NOT NULL DEFAULT 'wheat',
  `DeactivateBilling24hrs` tinyint(1) NOT NULL DEFAULT 0,
  `PaidBillsBeforeTransaction` tinyint(1) NOT NULL DEFAULT 1,
  `completeFlow` tinyint(1) NOT NULL DEFAULT 1,
  `approvalbeforeprinting` tinyint(1) NOT NULL DEFAULT 1,
  `smsActivated` tinyint(1) NOT NULL DEFAULT 0,
  `smsSettings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '{"result":"No","registration":"Yes","sample":"No","birthday":"No"}' CHECK (json_valid(`smsSettings`)),
  `emailNotification` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `applicationsettings`:
--

--
-- Dumping data for table `applicationsettings`
--

INSERT INTO `applicationsettings` (`keyid`, `bulkregistration`, `fontsize`, `textcolor`, `BackgroundColor`, `DeactivateBilling24hrs`, `PaidBillsBeforeTransaction`, `completeFlow`, `approvalbeforeprinting`, `smsActivated`, `smsSettings`, `emailNotification`) VALUES
(1, 0, '14', 'black', 'wheat', 1, 1, 1, 1, 0, '{\"result\":\"No\",\"registration\":\"Yes\",\"sample\":\"No\",\"birthday\":\"No\"}', 0);

-- --------------------------------------------------------

--
-- Table structure for table `betathalassemia`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `betathalassemia`;
CREATE TABLE `betathalassemia` (
  `keyid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `value` int(255) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='betathalassemia';

--
-- RELATIONSHIPS FOR TABLE `betathalassemia`:
--

--
-- Dumping data for table `betathalassemia`
--

INSERT INTO `betathalassemia` (`keyid`, `parameter`, `billingid`, `unit`, `created_on`, `updated_on`, `value`, `patientid`, `employeeid`) VALUES
(3, 'HFA', 216, 'mg/dl', '2023-12-05 08:57:13.137409', '2023-12-05 08:58:10.000000', 200, 2023101537, 2),
(4, 'HFB', 216, 'mg/sl', '2023-12-05 08:57:13.137409', '2023-12-05 08:58:10.000000', 200, 2023101537, 2);

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `billing`;
CREATE TABLE `billing` (
  `billingid` int(255) NOT NULL,
  `patientid` bigint(100) NOT NULL,
  `paid_amount` int(100) NOT NULL,
  `payable` int(100) NOT NULL,
  `discount` int(50) NOT NULL,
  `organization` int(25) NOT NULL,
  `clinician` int(25) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'self',
  `outstanding` int(100) NOT NULL,
  `taxIncluded` varchar(10) DEFAULT 'true',
  `taxValue` int(20) DEFAULT 0,
  `billedon` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `branchid` int(40) NOT NULL,
  `clientstatus` varchar(15) NOT NULL DEFAULT 'normal',
  `testcost` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `billing`:
--

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`billingid`, `patientid`, `paid_amount`, `payable`, `discount`, `organization`, `clinician`, `type`, `outstanding`, `taxIncluded`, `taxValue`, `billedon`, `branchid`, `clientstatus`, `testcost`) VALUES
(219, 1702200924561, 1000, 1000, 40, 0, 5, '4', 0, '1', 20, '2023-12-12 09:21:52.276859', 2, 'normal', 1020),
(233, 1702200924561, 1010, 1010, 39, 0, 0, '4', 0, '1', 20, '2023-12-16 02:53:17.442019', 1, 'moderate', 1029),
(235, 1702110827377, 529, 529, 0, 0, 0, '4', 0, '1', 20, '2023-12-16 04:43:39.978911', 1, 'moderate', 509),
(258, 1702808069956, 3000, 3000, 29, 0, 0, '4', 0, '1', 20, '2023-12-17 02:15:11.912309', 1, 'normal', 3009),
(263, 1702110827377, 40, 40, 0, 7, 0, '4', 0, '1', 20, '2024-01-05 02:34:28.624248', 1, 'normal', 20),
(264, 1702808069956, 60, 60, 20, 7, 0, '4', 0, '1', 20, '2023-12-21 00:47:34.318131', 1, 'normal', 60),
(265, 1703107987910, 700, 700, 0, 10, 0, '4', 0, '1', 20, '2023-12-21 00:50:18.207789', 1, 'normal', 680),
(283, 1702808069956, 3469, 3469, 200, 0, 41, 'cash', 0, '0', 0, '2024-01-06 20:04:54.592776', 1, 'none', 3669),
(284, 1702808069956, 1370, 1370, 100, 0, 41, 'cash', 0, '0', 0, '2024-01-09 17:13:41.416112', 1, 'none', 1470),
(285, 1704453099655, 500, 500, 90, 7, 0, '4', 0, '1', 20, '2024-01-09 17:20:12.912694', 1, 'moderate', 570),
(286, 1704453099655, 90, 90, 10, 7, 0, '4', 0, '1', 20, '2024-01-18 16:38:57.676362', 2, 'urgent', 80);

--
-- Triggers `billing`
--
DROP TRIGGER IF EXISTS `addPaymentHistory`;
DELIMITER $$
CREATE TRIGGER `addPaymentHistory` AFTER INSERT ON `billing` FOR EACH ROW BEGIN
INSERT INTO billinghx(billingid) VALUE (NEW.billingid);
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `onDeleteBilling`;
DELIMITER $$
CREATE TRIGGER `onDeleteBilling` AFTER DELETE ON `billing` FOR EACH ROW BEGIN 
DELETE FROM performing_test WHERE BILLINGID = OLD.BILLINGID;
DELETE FROM test_ascension WHERE billingid = OLD.BILLINGID;
DELETE FROM billinghx WHERE billingid = OLD.BILLINGID;
DELETE FROM samplestatus WHERE billingid = OLD.BILLINGID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `billinghx`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `billinghx`;
CREATE TABLE `billinghx` (
  `KeyID` int(255) NOT NULL,
  `Billingid` int(255) NOT NULL,
  `Date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `PaymentMode` int(25) NOT NULL,
  `Amount` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `billinghx`:
--

--
-- Dumping data for table `billinghx`
--

INSERT INTO `billinghx` (`KeyID`, `Billingid`, `Date`, `PaymentMode`, `Amount`) VALUES
(1, 1, '2023-09-03 09:00:18.976682', 4, 1000),
(2, 2, '2023-09-03 12:33:16.187891', 4, 0),
(3, 3, '2023-09-03 12:35:51.789360', 4, 50),
(4, 4, '2023-09-03 21:06:56.154649', 4, 500),
(5, 2, '2023-09-03 21:12:12.645002', 0, 30),
(6, 2, '2023-09-03 21:12:28.061551', 0, 20),
(7, 5, '2023-09-04 05:21:09.786065', 4, 1600),
(8, 6, '2023-09-04 10:37:51.153552', 4, 1080),
(9, 7, '2023-09-04 10:51:58.305295', 4, 6600),
(10, 8, '2023-09-04 10:52:55.725068', 4, 6600),
(11, 9, '2023-09-04 10:53:30.366183', 4, 6600),
(12, 10, '2023-09-04 10:53:52.608198', 4, 6600),
(13, 11, '2023-09-04 10:54:32.923407', 4, 6600),
(14, 12, '2023-09-04 10:55:08.739245', 4, 6600),
(15, 13, '2023-09-04 10:55:58.916300', 4, 6600),
(16, 14, '2023-09-04 10:56:00.607397', 4, 6600),
(17, 15, '2023-09-04 10:56:10.244939', 4, 6600),
(18, 16, '2023-09-04 10:56:11.129310', 4, 6600),
(19, 17, '2023-09-04 10:56:16.549474', 4, 6600),
(20, 18, '2023-09-04 11:07:59.086076', 4, 6600),
(21, 19, '2023-09-04 11:08:11.811687', 4, 6600),
(22, 20, '2023-09-04 11:08:47.717271', 4, 6600),
(23, 21, '2023-09-04 11:39:42.871233', 4, 550),
(24, 22, '2023-09-04 12:07:35.526062', 4, 6600),
(25, 23, '2023-09-04 12:07:46.434776', 4, 6600),
(26, 24, '2023-09-04 12:07:47.546111', 4, 6600),
(27, 25, '2023-09-04 12:08:06.680351', 4, 6600),
(28, 26, '2023-09-04 12:08:27.348731', 4, 6600),
(29, 27, '2023-09-04 12:08:35.314618', 4, 6600),
(30, 28, '2023-09-04 12:08:35.910416', 4, 6600),
(31, 29, '2023-09-04 12:10:08.720816', 4, 6600),
(32, 30, '2023-09-04 12:10:10.412708', 4, 6600),
(33, 31, '2023-09-04 12:10:11.454321', 4, 6600),
(34, 32, '2023-09-04 12:10:40.438348', 4, 6600),
(35, 33, '2023-09-04 12:10:40.481841', 4, 6600),
(36, 34, '2023-09-04 12:14:07.610150', 4, 6600),
(37, 35, '2023-09-04 12:15:13.661149', 4, 6000),
(38, 36, '2023-09-04 12:39:56.576590', 4, 1030),
(39, 37, '2023-09-04 12:46:34.205882', 4, 6560),
(40, 38, '2023-09-04 14:52:36.965254', 4, 60),
(41, 39, '2023-09-04 14:53:23.148588', 4, 500),
(42, 39, '2023-09-04 15:11:37.183887', 0, 100),
(43, 40, '2023-09-04 15:12:24.800674', 4, 30),
(44, 41, '2023-09-04 15:38:36.677552', 4, 0),
(45, 42, '2023-09-04 15:46:49.523842', 4, 6000),
(46, 43, '2023-09-04 15:47:09.407541', 4, 6000),
(47, 44, '2023-09-04 15:47:16.349553', 4, 6000),
(48, 45, '2023-09-04 16:02:28.113035', 4, 500),
(49, 46, '2023-09-04 16:12:13.741960', 4, 6000),
(50, 47, '2023-09-04 16:14:21.055553', 4, 6000),
(51, 48, '2023-09-04 16:17:31.044680', 4, 6000),
(52, 49, '2023-09-04 16:18:05.675769', 4, 600),
(53, 50, '2023-09-04 16:20:00.928423', 4, 600),
(54, 41, '2023-09-04 16:21:44.768746', 0, 600),
(55, 51, '2023-09-04 16:37:45.592612', 4, 20),
(56, 52, '2023-09-04 16:38:38.836998', 4, 40),
(57, 52, '2023-09-04 16:42:20.442478', 0, 10),
(58, 53, '2023-09-05 05:25:22.165408', 4, 10),
(59, 54, '2023-09-05 05:42:21.176938', 4, 20),
(60, 55, '2023-09-05 06:10:18.022738', 4, 60),
(61, 55, '2023-09-05 06:29:08.990250', 0, 540),
(62, 53, '2023-09-05 06:29:30.908101', 0, 10),
(63, 56, '2023-09-05 06:29:42.874786', 4, 20),
(64, 57, '2023-09-05 06:48:57.341853', 4, 50),
(170, 126, '2023-11-04 02:23:00.783336', 4, 20),
(191, 170, '2023-11-17 10:39:30.085386', 0, 0),
(192, 171, '2023-11-17 10:39:41.313552', 0, 0),
(193, 172, '2023-11-17 11:06:28.323516', 0, 0),
(194, 173, '2023-11-17 11:08:18.231357', 4, 50),
(195, 174, '2023-11-17 11:12:36.638940', 4, 50),
(196, 175, '2023-11-17 11:13:14.116513', 4, 50),
(240, 219, '2023-12-12 09:21:52.276859', 4, 1000),
(254, 233, '2023-12-16 02:53:17.442019', 4, 1010),
(256, 235, '2023-12-16 04:43:39.978911', 4, 529),
(279, 258, '2023-12-17 02:15:11.912309', 4, 3000),
(284, 263, '2023-12-17 02:34:28.624248', 4, 40),
(285, 264, '2023-12-21 00:47:34.318131', 4, 60),
(286, 265, '2023-12-21 00:50:18.207789', 4, 700),
(304, 283, '2024-01-06 20:04:54.592776', 0, 3469),
(305, 284, '2024-01-09 17:13:41.416112', 0, 1370),
(306, 285, '2024-01-09 17:20:12.912694', 4, 500),
(307, 286, '2024-01-18 16:38:57.676362', 4, 90);

-- --------------------------------------------------------

--
-- Table structure for table `billingtemporarytable`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `billingtemporarytable`;
CREATE TABLE `billingtemporarytable` (
  `orderid` int(11) NOT NULL,
  `clinicianid` int(11) NOT NULL,
  `organizationid` int(11) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '{}' CHECK (json_valid(`data`)),
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `processed` tinyint(1) NOT NULL DEFAULT 0,
  `patientid` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `billingtemporarytable`:
--

--
-- Dumping data for table `billingtemporarytable`
--

INSERT INTO `billingtemporarytable` (`orderid`, `clinicianid`, `organizationid`, `data`, `created_on`, `processed`, `patientid`) VALUES
(10, 41, 0, '[{\"id\":3,\"name\":\"Widal\",\"price\":600},{\"id\":6,\"name\":\"Hepatitis B\",\"price\":500},{\"id\":10,\"name\":\"liver function test\",\"price\":509},{\"id\":11,\"name\":\"renal function test\",\"price\":500},{\"id\":12,\"name\":\"Lipid profile\",\"price\":900},{\"id\":13,\"name\":\"urinalysis\",\"price\":60},{\"id\":14,\"name\":\"\",\"price\":0},{\"id\":15,\"name\":\"Thyroid functional test\",\"price\":600}]', '2023-12-29 19:42:25.569005', 1, 1702808069956),
(11, 41, 0, '[{\"id\":5,\"name\":\"cardiac enzymes\",\"price\":600},{\"id\":8,\"name\":\"Hepatitis C\",\"price\":600},{\"id\":20,\"name\":\"fasting blood sugar\",\"price\":20},{\"id\":31,\"name\":\"Luteinizing Hormone\",\"price\":50},{\"id\":51,\"name\":\"obstetrics scan\",\"price\":80},{\"id\":54,\"name\":\"abdominal pelvic scan\",\"price\":120}]', '2024-01-06 20:16:00.021569', 1, 1702808069956),
(12, 41, 0, '[{\"id\":5,\"name\":\"cardiac enzymes\",\"price\":600},{\"id\":11,\"name\":\"renal function test\",\"price\":500}]', '2024-01-14 12:01:08.368820', 1, 1702110827377),
(13, 41, 0, '[{\"id\":7,\"name\":\"Hepatitis B Profile\",\"price\":500},{\"id\":6,\"name\":\"Hepatitis B\",\"price\":500},{\"id\":10,\"name\":\"liver function test\",\"price\":509},{\"id\":13,\"name\":\"urinalysis\",\"price\":60},{\"id\":21,\"name\":\"random blood sugar\",\"price\":20}]', '2024-01-20 21:12:09.631719', 0, 1702200924561);

-- --------------------------------------------------------

--
-- Table structure for table `bloodcultureandsensitivitytestsetup`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `bloodcultureandsensitivitytestsetup`;
CREATE TABLE `bloodcultureandsensitivitytestsetup` (
  `keyid` int(100) NOT NULL,
  `drug` varchar(100) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `bloodcultureandsensitivitytestsetup`:
--

--
-- Dumping data for table `bloodcultureandsensitivitytestsetup`
--

INSERT INTO `bloodcultureandsensitivitytestsetup` (`keyid`, `drug`, `created_on`, `updated_on`) VALUES
(1, 'genesis', '2023-12-04 10:38:32.558028', '0000-00-00 00:00:00.000000'),
(2, 'prostate specific antigen test', '2023-12-04 10:38:32.582244', '0000-00-00 00:00:00.000000'),
(3, 'fluconazole', '2023-12-04 10:38:32.606596', '0000-00-00 00:00:00.000000'),
(4, 'clotrimaxole', '2023-12-04 10:38:32.672078', '0000-00-00 00:00:00.000000'),
(5, 'amoxacillin', '2023-12-04 10:38:32.713593', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `bloodgroup`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `bloodgroup`;
CREATE TABLE `bloodgroup` (
  `ID` int(100) NOT NULL,
  `BILLINGID` int(100) NOT NULL,
  `BGROUP` varchar(30) NOT NULL,
  `RHESUS` varchar(30) NOT NULL,
  `CREATED_ON` date DEFAULT current_timestamp(),
  `UPDATED_ON` date DEFAULT current_timestamp(),
  `TIME` time(6) DEFAULT current_timestamp(),
  `PATIENTID` int(255) NOT NULL,
  `REMARKS` varchar(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `bloodgroup`:
--

--
-- Dumping data for table `bloodgroup`
--

INSERT INTO `bloodgroup` (`ID`, `BILLINGID`, `BGROUP`, `RHESUS`, `CREATED_ON`, `UPDATED_ON`, `TIME`, `PATIENTID`, `REMARKS`, `employeeid`) VALUES
(1, 1, 'AB', 'positive', '2023-09-03', '2023-09-03', '09:02:43.000000', 2023729, 'wefjjfu', NULL),
(2, 62, 'B', 'negative', '2023-09-06', '2023-09-06', '09:56:05.000000', 2023854, 'jfuiwquiududu', NULL),
(3, 67, 'B', 'positive', '2023-09-12', '2023-09-12', '20:54:33.000000', 202385, 'hhh', NULL),
(4, 73, 'B', 'positive', '2023-09-15', '2023-09-15', '14:37:13.000000', 2023854, '<p>oef2efi2if2iiiiwiie</p>', NULL),
(5, 69, 'B', 'negative', '2023-09-18', '2023-09-18', '13:01:05.000000', 2023854, 'jfjfjqfhqfgw', NULL),
(6, 66, 'AB', 'negative', '2023-09-18', '2023-09-18', '13:01:47.000000', 2023854, 'kefoqwoioqwo\nkwiirfiw\n\n\nuefuiqrui', NULL),
(7, 70, 'B', 'positive', '2023-09-18', '2023-09-18', '13:02:28.000000', 2023854, 'ieriowefiowfioefo\noweoffopofofofws\n;wkfwlfl2flqfkqe\n\nk2eqkgwf\'olq\'l', NULL),
(8, 205, 'AB', 'negative', '2023-12-01', '2023-12-01', '23:32:39.000000', 202310127, '<p>eiiwefifikdkqwo</p>', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `branch`;
CREATE TABLE `branch` (
  `branchid` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `activation` tinyint(1) NOT NULL DEFAULT 0,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` int(21) NOT NULL,
  `managerid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `branch`:
--

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branchid`, `name`, `date`, `activation`, `address`, `email`, `contact`, `managerid`) VALUES
(1, 'yendi branch', '2023-09-03', 0, 'Kalpohin Lowcost 30A', 'tiifuhamza@gmail.com', 249493933, '3'),
(2, 'sda branch', '2023-09-03', 0, 'Kalpohin Lowcost 30A.\n\nPrincipal throry', 'tiifuhamza@gmail.com', 249493933, '3'),
(3, 'buipe branch', '2023-09-03', 0, 'Kalpohin Lowcost 30A', 'tiifuhamza@gmail.com', 249493933, ''),
(4, 'Tamale central', '2023-09-03', 1, 'Kalpohin Lowcost 30A', 'tiifuhamza@gmail.com', 249493933, '1'),
(9, 'kumasi ', '2023-10-09', 0, 'hwdfjwfjjfjqfj', 'jjajajjajaj@gmail.com', 2147483647, '1'),
(10, 'bimbilla', '2023-10-11', 0, 'Bimbilla Makayila \nP.O Box 1293\nKalpohin Lowcost 30A', 'bimbilla@lobnos.com', 283838383, '1');

-- --------------------------------------------------------

--
-- Table structure for table `clinicianbasicinfo`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `clinicianbasicinfo`;
CREATE TABLE `clinicianbasicinfo` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `occupation` varchar(100) NOT NULL,
  `organization` int(50) NOT NULL,
  `updated_on` date DEFAULT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `phone` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='collects only the basic information of the clinician';

--
-- RELATIONSHIPS FOR TABLE `clinicianbasicinfo`:
--

--
-- Dumping data for table `clinicianbasicinfo`
--

INSERT INTO `clinicianbasicinfo` (`id`, `name`, `email`, `location`, `address`, `occupation`, `organization`, `updated_on`, `created_on`, `phone`) VALUES
(4, 'Mildred Bag', 'hamzatiifu45@gmail.com', 'yanale', 'jdjfkdjud', 'other', 0, NULL, '2023-09-12 17:37:59.431113', 585949378),
(5, 'mohammmed hamza', 'mohammaed@gmial.cpm', 'Tamale', 'Kalpohin Lowcost 30A', 'nurse', 0, NULL, '2023-09-12 17:50:52.588645', 398494984),
(6, 'tiifu faizah', 'hamzatiifgu457@gmail.com', 'popodpodpo', 'podpodpopo', 'nurse', 0, NULL, '2023-09-12 18:28:41.207588', 693493773),
(7, 'Tiifu hamza', 'hamzatiifu45props@gmail.com', 'yanale', 'Northern region', 'nurse', 0, NULL, '2023-09-12 19:45:35.722453', 595964565),
(8, 'ffefeiofio', 'johnsonbuma@gmail.com', 'tamale', 'podpodpopo', 'nurse', 0, NULL, '2023-09-12 19:53:08.712140', 241758550),
(9, 'none', '00000000000@gmail.com', 'popodpodpo', 'Northern region', 'therapist', 0, NULL, '2023-09-12 20:43:12.230917', 0),
(10, 'enam akoetey', 'enam@gmsir.com', 'Tamale', 'principelk sad dogs', 'nurse', 0, NULL, '2023-09-23 07:49:49.758853', 374784894),
(11, 'Mildred Bagxxx', 'mildred@gmail.com', 'Tamale', 'Kalpohin Lowcost 30A', 'nurse', 0, NULL, '2023-10-27 04:53:39.526922', 595964565),
(12, 'tiifu hamza vercel', 'hamzatiifdjjsdju45@gmail.com', 'Tamale', 'kalpohin lowcost 30A', 'nurse', 0, NULL, '2023-10-28 10:38:40.198143', 595964565),
(41, 'tiifu kojo hamza', 'asananyaaba45@gmail.com', 'tamale', 'Kalpohin Lowcost 30A', 'nurse', 0, NULL, '2023-12-29 03:18:17.648227', 778888888);

--
-- Triggers `clinicianbasicinfo`
--
DROP TRIGGER IF EXISTS `onDeleteClinician`;
DELIMITER $$
CREATE TRIGGER `onDeleteClinician` AFTER DELETE ON `clinicianbasicinfo` FOR EACH ROW BEGIN 
DELETE FROM clinicianpaymentinfo WHERE CLINICIANID = OLD.ID;
DELETE FROM clinicianscredentials WHERE  CLINICIANID = OLD.ID;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `onInsertClinician`;
DELIMITER $$
CREATE TRIGGER `onInsertClinician` AFTER INSERT ON `clinicianbasicinfo` FOR EACH ROW BEGIN 
INSERT INTO clinicianpaymentinfo (CLINICIANID)
VALUE(NEW.ID);
INSERT INTO clinicianscredentials(clinicianid,email)
VALUE(NEW.ID,NEW.EMAIL);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `clinicianpaymentinfo`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `clinicianpaymentinfo`;
CREATE TABLE `clinicianpaymentinfo` (
  `ID` int(255) NOT NULL,
  `clinicianid` int(10) NOT NULL,
  `module` varchar(100) NOT NULL,
  `momo` int(50) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `accountnumber` int(100) DEFAULT NULL,
  `accountname` varchar(255) DEFAULT NULL,
  `organization` int(50) NOT NULL,
  `updated_on` date DEFAULT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `commission` int(10) DEFAULT NULL,
  `momoname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='collects only the basic information of the clinician';

--
-- RELATIONSHIPS FOR TABLE `clinicianpaymentinfo`:
--

--
-- Dumping data for table `clinicianpaymentinfo`
--

INSERT INTO `clinicianpaymentinfo` (`ID`, `clinicianid`, `module`, `momo`, `bankname`, `bankbranch`, `accountnumber`, `accountname`, `organization`, `updated_on`, `created_on`, `commission`, `momoname`) VALUES
(1, 0, 'cash', 595964565, 'feditlity banck', '9393030', 0, 'Tiifu hamza', 0, '2023-09-03', '0000-00-00 00:00:00.000000', 10, NULL),
(4, 4, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-09-12 17:37:59.431113', NULL, NULL),
(5, 5, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-09-12 17:50:52.588645', NULL, NULL),
(6, 6, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-09-12 18:28:41.207588', NULL, NULL),
(7, 7, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-09-12 19:45:35.722453', NULL, NULL),
(8, 8, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-09-12 19:53:08.712140', NULL, NULL),
(9, 9, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-09-12 20:43:12.230917', NULL, NULL),
(10, 10, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-09-23 07:49:49.758853', NULL, NULL),
(11, 11, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-10-27 04:53:39.526922', NULL, NULL),
(12, 12, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-10-28 10:38:40.198143', NULL, NULL),
(41, 41, '', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2023-12-29 03:18:17.648227', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `clinicianscredentials`
--
-- Creation: Dec 29, 2023 at 12:14 PM
--

DROP TABLE IF EXISTS `clinicianscredentials`;
CREATE TABLE `clinicianscredentials` (
  `id` int(100) NOT NULL,
  `clinicianid` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `isAuthenticated` tinyint(1) NOT NULL DEFAULT 0,
  `authenticationMode` varchar(20) NOT NULL,
  `authenticatedon` varchar(20) NOT NULL,
  `ispasswordUpdated` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `clinicianscredentials`:
--

--
-- Dumping data for table `clinicianscredentials`
--

INSERT INTO `clinicianscredentials` (`id`, `clinicianid`, `email`, `password`, `isAuthenticated`, `authenticationMode`, `authenticatedon`, `ispasswordUpdated`) VALUES
(28, 41, 'asananyaaba45@gmail.com', 'ecd90f9853', 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `clotbleedingtime`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `clotbleedingtime`;
CREATE TABLE `clotbleedingtime` (
  `keyid` int(100) NOT NULL,
  `billingid` int(100) NOT NULL,
  `patientid` bigint(50) NOT NULL,
  `comments` varchar(100) NOT NULL,
  `bleedingtime` int(50) NOT NULL,
  `clottingtime` int(50) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `clotbleedingtime`:
--

--
-- Dumping data for table `clotbleedingtime`
--

INSERT INTO `clotbleedingtime` (`keyid`, `billingid`, `patientid`, `comments`, `bleedingtime`, `clottingtime`, `created_on`, `updated_on`, `employeeid`) VALUES
(1, 212, 2023101537, '<p>hefhdhdh</p>', 8, 8, '2023-11-30 10:11:36.460536', '2023-11-30 10:42:29.120877', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `commodity`
--
-- Creation: Jan 11, 2024 at 07:13 AM
--

DROP TABLE IF EXISTS `commodity`;
CREATE TABLE `commodity` (
  `comid` int(255) NOT NULL,
  `commodity` varchar(255) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `category` varchar(255) NOT NULL,
  `suppliedby` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `commodity`:
--

--
-- Dumping data for table `commodity`
--

INSERT INTO `commodity` (`comid`, `commodity`, `date`, `category`, `suppliedby`) VALUES
(1, 'solutions cleaner', '2023-10-11 10:57:18.607047', 'chemicals', NULL),
(2, 'edta tubes ', '2023-10-11 10:57:18.665805', 'consumables', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `companyprofile`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `companyprofile`;
CREATE TABLE `companyprofile` (
  `ID` int(255) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `MOTTO` varchar(255) NOT NULL,
  `PHONENUMBER` int(100) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `ALTERNATIVENUMBER` int(10) DEFAULT NULL,
  `WEBSITE` varchar(50) DEFAULT NULL,
  `STREET` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `companyprofile`:
--

--
-- Dumping data for table `companyprofile`
--

INSERT INTO `companyprofile` (`ID`, `NAME`, `EMAIL`, `MOTTO`, `PHONENUMBER`, `ADDRESS`, `ALTERNATIVENUMBER`, `WEBSITE`, `STREET`) VALUES
(1, 'Mauplaus Diagnostic Limited', 'mauplausl@gmail.com', 'Health and happiness', 595964565, 'Opposite SDA Gbanjil Road Hse No 19', NULL, 'mauplus@gmail.com', 'Kalpohin Lowcost 30A');

-- --------------------------------------------------------

--
-- Table structure for table `composedemails`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `composedemails`;
CREATE TABLE `composedemails` (
  `id` int(255) NOT NULL,
  `employeeid` int(10) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `target` text NOT NULL,
  `ispublished` varchar(10) NOT NULL DEFAULT 'false',
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `body` longtext NOT NULL,
  `scheduledate` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `composedemails`:
--

--
-- Dumping data for table `composedemails`
--

INSERT INTO `composedemails` (`id`, `employeeid`, `subject`, `target`, `ispublished`, `created_on`, `updated_on`, `body`, `scheduledate`) VALUES
(1, 2, 'kwkwfkkwefkwdkwefk jefjwdkk', '', 'false', '2023-12-17 11:00:43.131127', NULL, '<h2>jefjwefkwefjkwefkkwefkwefkhello world</h2><p>&nbsp;</p><p>i2efjfjqjifqwjifjiqfqwf a wdgujvwdjf2jq</p>', NULL),
(2, 2, 'kwkwfkkwefkwdkwefk jefjwdkk', '', 'false', '2023-12-17 11:00:44.700763', NULL, '<h2>jefjwefkwefjkwefkkwefkwefkhello world</h2><p>&nbsp;</p><p>i2efjfjqjifqwjifjiqfqwf a wdgujvwdjf2jq</p>', NULL),
(3, 2, 'kwkwfkkwefkwdkwefk jefjwdkk', '', 'false', '2023-12-17 11:01:23.856446', NULL, '<h2>jefjwefkwefjkwefkkwefkwefkhello world</h2><p>&nbsp;</p><p>i2efjfjqjifqwjifjiqfqwf a wdgujvwdjf2jq</p>', NULL),
(4, 2, 'kwkwfkkwefkwdkwefk jefjwdkk', '[{\"email\":\"tiifu@gmail.com\"},{\"email\":\"hamzatiifu45@gmail.com\"},{\"email\":\"shefiktiifu@yahoo.com\"},{\"email\":\"haktiifu@yahoo.com\"}]', 'true', '2023-12-17 11:01:41.241610', NULL, '<h2>jefjwefkwefjkwefkkwefkwefkhello world</h2><p>&nbsp;</p><p>i2efjfjqjifqwjifjiqfqwf a wdgujvwdjf2jq</p>', '2023-12-08 19:53:00.000000'),
(5, 2, 'kwkwfkkwefkwdkwefk jefjwdkk', 'bulk staff', 'true', '2023-12-17 11:01:41.248191', NULL, '<h2>jefjwefkwefjkwefkkwefkwefkhello world</h2><p>&nbsp;</p><p>i2efjfjqjifqwjifjiqfqwf a wdgujvwdjf2jq</p>', '2023-12-22 14:52:00.000000'),
(6, 2, 'kwkwfkkwefkwdkwefk jefjwdkk', '[{\"email\":\"leonidesintell@gmail.com\"}]', 'true', '2023-12-17 11:02:26.562309', NULL, '<h2>jefjwefkwefjkwefkkwefkwefkhello world</h2><p>&nbsp;</p><p>i2efjfjqjifqwjifjiqfqwf a wdgujvwdjf2jq</p>', NULL),
(7, 2, 'kwkwfkkwefkwdkwefk jefjwdkk', '[{\"email\":\"hamzatiifu45@gmail.com\"}]', 'true', '2023-12-17 11:03:45.215093', NULL, '<h2>jefjwefkwefjkwefkkwefkwefkhello world</h2><p>&nbsp;</p><p>i2efjfjqjifqwjifjiqfqwf a wdgujvwdjf2jq</p>', NULL),
(8, 2, 'kwkwfkkwefkwdkwefk jefjwdkk', '[{\"email\":\"hamzatiifu45@gmail.com\"}]', 'true', '2023-12-17 11:04:30.954083', NULL, '<h2>jefjwefkwefjkwefkkwefkwefkhello world</h2><p>&nbsp;</p><p>i2efjfjqjifqwjifjiqfqwf a wdgujvwdjf2jq</p>', NULL),
(9, 2, 'Arsenal legend Ian Wright to leave Match of the Day at end of season', '[{\"email\":\"hamzatiifu45@gmail.com\"}]', 'true', '2023-12-17 11:06:48.592636', NULL, '<p>Wright said on his official X – formerly Twitter – account: “After my debut show whilst still a player in 1997 and many more memorable years, I’ll be stepping back from BBC MOTD at the end of this season.</p><p>“I feel very privileged to have had such an incredible run on the most iconic football show in the world.</p><p>“I’m stepping back having made great friends and many great memories. This decision has been coming for a while – maybe my birthday earlier this year fast-tracked it a little – but ultimately it’s time to do a few more different things with my Saturdays.</p><p>“I’m really looking forward to my last months on the show and covering what will hopefully be an amazing Premier League title race.”</p><p>&nbsp;</p><p>Wright first appeared on the BBC show in 1997 during his distinguished playing days at Arsenal and became a regular in 2002 two years after his retirement from the game.</p><p>On his first appearance, he told presenter Des Lynam the programme was his “Graceland”, and his enduring passion for football has been abundantly clear since.</p><p><strong>READ MORE:&nbsp;</strong><a href=\"https://www.football365.com/news/man-utd-massive-mistake-fred-transfer-liverpool-hate-mailbox\"><strong>Did Man Utd make a ‘massive mistake’ selling Fred? And Liverpool fan explains why he doesn’t hate Red Devils…</strong></a></p><p><img src=\"https://assets.msn.com/staticsb/statics/pr-3888520/icons-wc/icons/VideoBlue.svg\" width=\"16\" height=\"14\"><strong>Related video</strong>: Arteta on team mood off the pitch and Brighton (Full Presser part three) (Dailymotion)</p>', NULL),
(10, 2, 'While Fed officials have pushed back against market expectations of how soon the Federal Open Market Committe', '[{\"email\":\"hamzatiifu45@gmail.com\"},{\"email\":\"shefiktiifu@yahoo.com\"},{\"email\":\"haktiifu@yahoo.com\"},{\"email\":\"asananyaaba45@gmail.com\"}]', 'true', '2023-12-20 05:21:07.044857', NULL, '<p>While Fed officials have <a href=\"https://www.reuters.com/markets/rates-bonds/feds-mester-says-next-phase-is-see-how-long-its-policy-needs-remain-restrictive-2023-12-18/\">pushed back</a> against market expectations of how soon the Federal Open Market Committee (FOMC) could cut rates, those comments have done little to sway market pricing and stem the greenback\'s decline.</p><p>\"We\'re going to maybe see a little bit of a rocky start to the year where people are going to try to sell dollars just on Fed expectations and as the Bank of England and ECB remain somewhat in the higher-for-longer camp, and EM assets continue to rally,\" Brad Bechtel, global head of FX at Jefferies in New York.</p><p>But the relative strength of the U.S. economy should insulate the dollar from further pronounced weakness, he said.</p><p>\"In the U.S., maybe we slow a bit, but we don\'t go into recession. That\'s actually still pretty dollar positive,\" Bechtel said.</p><p>The dollar index , which measures the currency\'s strength against a basket of six rivals, was 0.30 % lower at 102.18 . The index has dipped 1.5% over the last week.</p><p>Chicago Fed President Austan Goolsbee <a href=\"https://www.reuters.com/markets/us/feds-goolsbee-says-he-has-been-confused-by-market-reaction-2023-12-18/\">on Monday said</a> the Fed was not pre-committing to cutting rates soon or swiftly, and the jump in market expectations that it will do so was at odds with how the U.S. central bank functions.</p><p>A reading on the core Personal Consumption Expenditures (PCE) price index - the Fed\'s preferred measure of underlying inflation - is due this week, and may provide clarity on whether inflation has slowed enough for the Fed to begin easing policy next year.</p><p>The risk-sensitive Australian and New Zealand dollars sat around their highest in nearly five months, further beneficiaries of the softening dollar.</p><p>The Aussie was 0.78 % higher at $ 0.6757 , its highest since late July. <a href=\"https://www.reuters.com/markets/rates-bonds/australia-central-bank-considered-hiking-again-dec-paused-more-data-2023-12-19/\">Minutes</a> from the Reserve Bank of Australia\'s December policy meeting showed on Tuesday that the bank considered hiking rates, but decided there were enough encouraging signs on inflation to pause for more data.The kiwi rose 0.85% to 0.62645.</p><p>The <a href=\"https://www.reuters.com/markets/currencies/canadian-dollar-rallies-cpi-data-cools-rate-cut-bets-2023-12-19/\">Canadian dollar strengthened</a> to a four-and-a-half-month high against its U.S. counterpart as investors reduced bets on an early start to Bank of Canada interest rate cuts after domestic data showed inflation holding steady in November.</p><p>The <a href=\"https://www.reuters.com/markets/currencies/sterling-climbs-investors-eye-further-gains-2024-2023-12-19/\">pound rose</a> 0.56%, helped by the dollar\'s broad weakness and as investors increasingly talked up sterling as a hot prospect for next year.</p><p>In cryptocurrencies, Bitcoin was about flat on the day at $42,365.</p><p>Reporting by Saqib Iqbal Ahmed; Additional reporting by Rae Wee in Singapore and Alun John in London, additional reporting by Summer Zhen in Hong Kong; Editing by Ed Osmond and Nick Zieminski</p>', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `departmentconsumption`
--
-- Creation: Dec 26, 2023 at 08:50 AM
-- Last update: Jan 22, 2024 at 10:51 PM
--

DROP TABLE IF EXISTS `departmentconsumption`;
CREATE TABLE `departmentconsumption` (
  `id` int(50) NOT NULL,
  `quantity` int(50) NOT NULL,
  `stockid` int(50) NOT NULL,
  `departmentid` int(50) NOT NULL,
  `batchnumber` varchar(50) DEFAULT NULL,
  `createdOn` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `brand` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `departmentconsumption`:
--

--
-- Dumping data for table `departmentconsumption`
--

INSERT INTO `departmentconsumption` (`id`, `quantity`, `stockid`, `departmentid`, `batchnumber`, `createdOn`, `brand`) VALUES
(1, 20, 1, 5, NULL, '2023-10-17 14:51:17.826577', 'villa'),
(2, 100, 2, 5, NULL, '2023-10-17 14:51:22.212813', 'lobba'),
(3, 70, 8, 5, '6766', '2023-10-17 14:51:26.098505', 'litmus'),
(4, 480, 1, 4, 'gerald', '2023-10-28 11:46:11.986890', 'lobba'),
(5, 3800, 2, 4, '5666', '2023-10-28 11:46:16.337547', 'johnson'),
(6, 1000, 8, 4, '6766', '2023-10-28 11:46:27.031306', 'litmus'),
(7, 200, 2, 8, NULL, '2024-01-22 21:27:05.224166', NULL),
(8, 1000, 2, 8, NULL, '2024-01-22 21:28:05.665725', NULL),
(9, 1200, 2, 8, NULL, '2024-01-22 21:28:10.167077', NULL),
(10, 200, 2, 5, NULL, '2024-01-22 22:25:56.650672', NULL),
(11, 200, 3, 5, NULL, '2024-01-22 23:51:57.532767', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `departmentconsumptionhx`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `departmentconsumptionhx`;
CREATE TABLE `departmentconsumptionhx` (
  `comsumeid` int(255) NOT NULL,
  `department` int(50) NOT NULL,
  `stockid` int(50) NOT NULL,
  `batchnumber` varchar(50) DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `debit` int(50) NOT NULL,
  `credit` int(50) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `time` time(6) NOT NULL DEFAULT current_timestamp(),
  `employeeid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `departmentconsumptionhx`:
--

--
-- Triggers `departmentconsumptionhx`
--
DROP TRIGGER IF EXISTS `updateDepartmentMainStocks`;
DELIMITER $$
CREATE TRIGGER `updateDepartmentMainStocks` AFTER INSERT ON `departmentconsumptionhx` FOR EACH ROW BEGIN
UPDATE departmentstocks SET quantityAvailable = quantityAvailable - NEW.debit WHERE deptid = NEW.department AND stockid = NEW.stockid;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `departmentrequisitionhx`
--
-- Creation: Jan 22, 2024 at 05:33 PM
-- Last update: Jan 22, 2024 at 11:12 PM
--

DROP TABLE IF EXISTS `departmentrequisitionhx`;
CREATE TABLE `departmentrequisitionhx` (
  `id` int(255) NOT NULL,
  `departmentid` int(255) NOT NULL,
  `stockid` int(255) NOT NULL,
  `quantity_requested` int(255) NOT NULL,
  `quantity_approved` int(255) DEFAULT NULL,
  `comsumptionunit` varchar(255) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `date` date NOT NULL DEFAULT current_timestamp(),
  `requisitionid` varchar(255) NOT NULL,
  `issue_message` text DEFAULT NULL,
  `departmentReceived` int(10) DEFAULT 0,
  `store_supplied` int(10) DEFAULT 0,
  `quantityReceived` int(20) DEFAULT 0,
  `batchnumber` varchar(50) DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `requestingemployee` int(20) NOT NULL,
  `receivingemployee` int(20) NOT NULL,
  `approvedon` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `departmentrequisitionhx`:
--

--
-- Dumping data for table `departmentrequisitionhx`
--

INSERT INTO `departmentrequisitionhx` (`id`, `departmentid`, `stockid`, `quantity_requested`, `quantity_approved`, `comsumptionunit`, `status`, `date`, `requisitionid`, `issue_message`, `departmentReceived`, `store_supplied`, `quantityReceived`, `batchnumber`, `brand`, `requestingemployee`, `receivingemployee`, `approvedon`) VALUES
(1, 5, 2, 300, 200, 'l', 'received', '2024-01-21', 'd6da2839-e902-4b9d-a5e1-ddcce6ed1458', NULL, 1, 1, 200, NULL, NULL, 3, 3, '2024-01-22'),
(2, 5, 3, 300, 200, 'pcs', 'received', '2024-01-21', 'd1f9eb5c-1ef2-4dfc-ab1f-ba15b1e0dca5', NULL, 1, 1, 200, NULL, NULL, 3, 3, '2024-01-22'),
(3, 5, 4, 300, 200, 'pcs', 'approved', '2024-01-21', '1c5624e4-e5f8-4a47-85ed-e0faf38fd6f1', NULL, 0, 1, 0, NULL, NULL, 3, 0, '2024-01-22'),
(4, 5, 9, 300, 0, 'g', 'approved', '2024-01-21', 'e8d8012f-d99f-4d58-b8a6-fd4433a6dff1', NULL, 0, 0, 0, NULL, NULL, 3, 0, NULL),
(5, 8, 2, 400, 200, 'l', 'received', '2024-01-21', 'fe707c85-b1cb-4da3-9872-b42c237cafdc', NULL, 1, 1, 200, NULL, NULL, 3, 3, '2024-01-22'),
(6, 8, 2, 20000, 1000, 'l', 'received', '2024-01-22', 'fb37a6c9-0fce-4e59-bce0-011d9283e76f', NULL, 1, 1, 1000, NULL, NULL, 3, 3, '2024-01-22'),
(7, 8, 2, 16000, 1200, 'l', 'received', '2024-01-22', 'ffae52b9-d931-4233-8019-4c23c8a9d5a3', NULL, 1, 1, 1200, NULL, NULL, 3, 3, '2024-01-22'),
(8, 5, 10, 200, NULL, 'pcs', 'pending', '2024-01-22', 'c4bcf00d-eda0-44c9-831d-8088c8dd6912', NULL, 0, 0, 0, NULL, NULL, 3, 0, NULL),
(9, 5, 12, 200, NULL, 'pcs', 'pending', '2024-01-22', 'a8e9eebb-1d02-4421-9cf5-6f4abeb6c62b', NULL, 0, 0, 0, NULL, NULL, 3, 0, NULL),
(10, 5, 2, 200, NULL, 'l', 'pending', '2024-01-22', '2ac5585b-a45d-4dca-ae26-47055993fa11', NULL, 0, 0, 0, NULL, NULL, 3, 0, NULL),
(11, 5, 3, 1000, 1000, 'pcs', 'approved', '2024-01-22', '09a4a137-1ffb-447c-8e03-e7c1135fb6ab', NULL, 0, 1, 0, NULL, NULL, 3, 0, '2024-01-22'),
(12, 5, 4, 500, 100, 'pcs', 'approved', '2024-01-22', '8a86d325-6247-4ce2-a150-7f254242d5ae', NULL, 0, 1, 0, NULL, NULL, 3, 0, '2024-01-22'),
(13, 5, 3, 1000, 500, 'pcs', 'approved', '2024-01-22', '37198f13-f674-411e-89cf-e9507f61c597', NULL, 0, 1, 0, NULL, NULL, 3, 0, '2024-01-22'),
(14, 5, 4, 1000, 500, 'pcs', 'approved', '2024-01-22', '921cd155-8600-4e59-bcfb-be27196ddb5f', NULL, 0, 1, 0, NULL, NULL, 3, 0, '2024-01-22'),
(15, 5, 3, 5000, 500, 'pcs', 'approved', '2024-01-22', '7fbcc5b3-3c04-449c-9135-1061ed1ad2c2', NULL, 0, 1, 0, NULL, NULL, 3, 0, NULL),
(16, 5, 4, 500, 500, 'pcs', 'approved', '2024-01-23', 'f342f4a7-2959-46d2-9317-0a158fe79138', NULL, 0, 1, 0, NULL, NULL, 3, 0, NULL);

--
-- Triggers `departmentrequisitionhx`
--
DROP TRIGGER IF EXISTS `updateMainStocks`;
DELIMITER $$
CREATE TRIGGER `updateMainStocks` AFTER UPDATE ON `departmentrequisitionhx` FOR EACH ROW BEGIN
  -- Declare variables for stock count and batch availability
  DECLARE stock_count INT;
  DECLARE batchAvailable INT;

  -- Check if the stockid exists in departmentstocks
  SELECT COUNT(*) INTO stock_count
  FROM departmentstocks
  WHERE stockid = NEW.stockid AND deptid = OLD.departmentid;

  -- Check if a batch is available in departmentconsumption
  SELECT COUNT(*) INTO batchAvailable
  FROM departmentconsumption WHERE stockid = NEW.stockid AND batchnumber = OLD.batchnumber AND departmentid = OLD.departmentid AND brand = OLD.brand;

  -- If department received the item and the quantity received is greater than 0
  IF NEW.departmentReceived = 1 AND NEW.quantityReceived > 0 AND OLD.store_supplied
  = 1
   THEN
    -- Update department consumption if a batch is available
    IF batchAvailable > 0 THEN 
      -- Update the quantity in departmentconsumption
      UPDATE departmentconsumption SET quantity = NEW.quantityReceived + quantity
      WHERE stockid = NEW.stockid AND departmentid = OLD.departmentid;
    
      -- Update the historical record in departmentconsumptionhx
       
    INSERT INTO departmentconsumptionhx(department,stockid,batchnumber,brand,credit,employeeid) 
    VALUES (OLD.departmentid,NEW.stockid,OLD.batchnumber,OLD.brand,NEW.quantityReceived,NEW.receivingemployee);
    ELSE 
      -- Insert a new record in departmentconsumption if no batch is available
      INSERT INTO departmentconsumption (quantity, stockid, departmentid, batchnumber, brand) 
      VALUES (NEW.quantityReceived, OLD.stockid, OLD.departmentid, OLD.batchnumber, OLD.brand);
    END IF;

    -- Update department main stocks if stock_count is greater than 0
    IF stock_count > 0 THEN
      -- Stockid exists, update the quantityAvailable in departmentstocks
      UPDATE departmentstocks
      SET quantityAvailable = NEW.quantityReceived + quantityAvailable
      WHERE stockid = NEW.stockid AND deptid = OLD.departmentid;
    ELSE
      -- Stockid doesn't exist, insert a new record in departmentstocks
      INSERT INTO departmentstocks (stockid, quantityAvailable, deptid, comsumptionunit)
      VALUES (NEW.stockid, NEW.quantityReceived, OLD.departmentid, OLD.comsumptionunit);
    END IF;

    -- Update the generalstocks table
    UPDATE generalstocks
    SET quantity = quantity - NEW.quantityReceived
    WHERE stockid = OLD.stockid;
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` int(255) NOT NULL,
  `department` varchar(100) NOT NULL,
  `departmentManager` varchar(100) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `employeeid` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `departments`:
--

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `department`, `departmentManager`, `date`, `employeeid`) VALUES
(1, 'serology', 'abu hajia sheheda', '2023-09-03 08:53:29.767465', 27),
(2, 'hematology', 'opoku razak', '2023-09-03 08:53:29.842905', 3),
(3, 'endocrinology', 'opoku razak', '2023-09-03 08:53:29.892959', 3),
(4, 'chemistry', 'Nyaaba Asana Awineyila', '2023-09-03 08:53:29.959643', 1),
(5, 'microbiology', 'Nyaaba Asana Awineyila', '2023-09-03 08:53:30.000791', 1),
(6, 'ultrasound', 'Nyaaba Asana Awineyila', '2023-10-03 07:56:04.602421', 1),
(8, 'endoscopy', 'Nyaaba Asana Awineyila', '2023-10-08 18:42:27.532698', 1);

-- --------------------------------------------------------

--
-- Table structure for table `departmentstocks`
--
-- Creation: Dec 26, 2023 at 08:50 AM
-- Last update: Jan 22, 2024 at 10:51 PM
--

DROP TABLE IF EXISTS `departmentstocks`;
CREATE TABLE `departmentstocks` (
  `id` int(255) NOT NULL,
  `deptid` int(255) NOT NULL,
  `stockid` int(255) NOT NULL,
  `quantityAvailable` int(255) NOT NULL,
  `date_added` date NOT NULL DEFAULT current_timestamp(),
  `dateupdated` date DEFAULT NULL,
  `comsumptionunit` varchar(210) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `departmentstocks`:
--

--
-- Dumping data for table `departmentstocks`
--

INSERT INTO `departmentstocks` (`id`, `deptid`, `stockid`, `quantityAvailable`, `date_added`, `dateupdated`, `comsumptionunit`) VALUES
(1, 5, 1, 20, '2023-10-17', NULL, 'g'),
(2, 5, 2, 300, '2023-10-17', NULL, 'l'),
(3, 5, 8, 70, '2023-10-17', NULL, 'ml'),
(4, 4, 1, 480, '2023-10-28', NULL, 'g'),
(5, 4, 2, 3800, '2023-10-28', NULL, 'l'),
(6, 4, 8, 1000, '2023-10-28', NULL, 'ml'),
(7, 8, 2, 2400, '2024-01-22', NULL, 'l'),
(8, 5, 3, 200, '2024-01-22', NULL, 'pcs');

-- --------------------------------------------------------

--
-- Table structure for table `emaillog`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `emaillog`;
CREATE TABLE `emaillog` (
  `id` int(255) NOT NULL,
  `target` int(50) NOT NULL,
  `type` varchar(100) NOT NULL,
  `success` int(20) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `reason` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `emaillog`:
--

--
-- Dumping data for table `emaillog`
--

INSERT INTO `emaillog` (`id`, `target`, `type`, `success`, `date`, `reason`) VALUES
(3, 233, 'billing receipt', 1, '2023-12-16 02:53:17.620224', NULL),
(4, 250, 'billing receipt', 1, '2023-12-17 01:54:07.546842', NULL),
(5, 258, 'billing receipt', 1, '2023-12-17 02:15:12.309275', NULL),
(6, 260, 'billing receipt', 0, '2023-12-17 02:30:54.285970', '0'),
(7, 261, 'billing receipt', 0, '2023-12-17 02:32:06.009658', '0'),
(8, 262, 'billing receipt', 0, '2023-12-17 02:33:14.770085', '0'),
(9, 263, 'billing receipt', 0, '2023-12-17 02:34:28.785339', 'email not provided'),
(10, 1, 'email token verification', 1, '2023-12-20 23:09:02.818289', NULL),
(11, 1, 'email token verification', 1, '2023-12-20 23:19:28.567020', NULL),
(12, 1, 'email token verification', 1, '2023-12-20 23:24:09.008969', NULL),
(13, 2147483647, 'email token verification', 1, '2023-12-20 23:24:43.933713', NULL),
(14, 2147483647, 'email token verification', 1, '2023-12-20 23:29:39.620294', NULL),
(15, 2147483647, 'email token verification', 1, '2023-12-20 23:50:30.103324', NULL),
(16, 2147483647, 'email token verification', 1, '2023-12-21 00:05:21.184876', NULL),
(17, 2147483647, 'email token verification', 1, '2023-12-21 00:15:07.680105', NULL),
(18, 2147483647, 'Authentication email', 1, '2023-12-21 00:28:12.180992', 'email sent'),
(19, 2147483647, 'email token verification', 1, '2023-12-21 00:33:37.388305', NULL),
(20, 2147483647, 'email token verification', 1, '2023-12-21 00:42:33.846937', NULL),
(21, 2147483647, 'email token verification', 1, '2023-12-21 00:42:34.833100', NULL),
(22, 264, 'billing receipt', 1, '2023-12-21 00:47:34.554507', NULL),
(23, 265, 'billing receipt', 1, '2023-12-21 00:50:18.437779', NULL),
(24, 1, 'Authentication email', 1, '2023-12-28 11:13:39.380540', 'email sent'),
(25, 1, 'Authentication email', 1, '2023-12-28 11:26:22.256250', 'email sent'),
(26, 1, 'Authentication email', 1, '2023-12-28 12:42:35.104161', 'email sent'),
(27, 28, 'Authentication email', 1, '2023-12-29 00:07:19.798137', 'email sent'),
(28, 29, 'Authentication email', 1, '2023-12-29 00:09:02.956361', 'email sent'),
(29, 1, 'email token verification', 1, '2023-12-29 00:29:13.382363', NULL),
(30, 1, 'email token verification', 1, '2023-12-29 00:30:31.791418', NULL),
(31, 30, 'Authentication email', 1, '2023-12-29 00:43:04.745044', 'email sent'),
(32, 31, 'Authentication email', 1, '2023-12-29 00:58:03.166068', 'email sent'),
(33, 32, 'Authentication email', 1, '2023-12-29 01:45:29.220082', 'email sent'),
(34, 33, 'Authentication email', 1, '2023-12-29 01:47:36.028387', 'email sent'),
(35, 34, 'Authentication email', 1, '2023-12-29 02:45:54.248004', 'email sent'),
(36, 35, 'Authentication email', 1, '2023-12-29 03:04:30.971210', 'email sent'),
(37, 36, 'Authentication email', 1, '2023-12-29 03:07:34.909772', 'email sent'),
(38, 37, 'Authentication email', 1, '2023-12-29 03:11:13.672111', 'email sent'),
(39, 38, 'Authentication email', 1, '2023-12-29 03:12:41.356704', 'email sent'),
(40, 39, 'Authentication email', 1, '2023-12-29 03:14:42.180600', 'email sent'),
(41, 40, 'Authentication email', 1, '2023-12-29 03:15:21.638698', 'email sent'),
(42, 41, 'Authentication email', 1, '2023-12-29 03:18:17.733137', 'email sent'),
(43, 266, 'billing receipt', 1, '2024-01-05 12:12:58.600841', NULL),
(44, 267, 'billing receipt', 0, '2024-01-06 12:37:14.930604', '0'),
(45, 268, 'billing receipt', 0, '2024-01-06 12:40:05.528108', '0'),
(46, 269, 'billing receipt', 1, '2024-01-06 12:58:12.827615', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `emailpreference`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `emailpreference`;
CREATE TABLE `emailpreference` (
  `id` int(255) NOT NULL,
  `registration` varchar(3) NOT NULL DEFAULT 'No',
  `result` varchar(3) NOT NULL DEFAULT 'No',
  `rejection` varchar(3) NOT NULL DEFAULT 'No',
  `approval` varchar(3) NOT NULL DEFAULT 'No',
  `transactions` varchar(3) NOT NULL DEFAULT 'No',
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `birthday` varchar(3) NOT NULL DEFAULT 'Yes',
  `billing` varchar(3) NOT NULL DEFAULT 'Yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `emailpreference`:
--

--
-- Dumping data for table `emailpreference`
--

INSERT INTO `emailpreference` (`id`, `registration`, `result`, `rejection`, `approval`, `transactions`, `updated_on`, `birthday`, `billing`) VALUES
(1, 'Yes', 'Yes', 'Yes', 'No', 'No', NULL, 'No', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `fshresult`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `fshresult`;
CREATE TABLE `fshresult` (
  `keyid` int(255) NOT NULL,
  `parameter` varchar(50) NOT NULL,
  `billingid` int(20) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `value` int(100) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `unit` varchar(40) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `fshresult`:
--

--
-- Dumping data for table `fshresult`
--

INSERT INTO `fshresult` (`keyid`, `parameter`, `billingid`, `patientid`, `value`, `created_on`, `updated_on`, `comment`, `unit`, `employeeid`) VALUES
(1, 'fsh', 73, 2023854, 444, '2023-09-15 14:38:03.042504', '2023-09-15 14:38:48.000000', 'ifoweoweiofioweio', '', NULL),
(2, 'fsh', 101, 202382112, 444, '2023-10-05 21:23:18.827755', '0000-00-00 00:00:00.000000', 'kjfj2ef1wjj', '', NULL),
(3, 'FSH', 211, 2023101537, 50, '2023-11-28 07:10:54.418452', '0000-00-00 00:00:00.000000', '', 'U/L', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `fshsetup`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `fshsetup`;
CREATE TABLE `fshsetup` (
  `setupid` int(255) NOT NULL,
  `upper` int(10) NOT NULL,
  `lower` int(10) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `parameter` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `fshsetup`:
--

--
-- Dumping data for table `fshsetup`
--

INSERT INTO `fshsetup` (`setupid`, `upper`, `lower`, `unit`, `gender`, `parameter`) VALUES
(1, 200, 100, 'U/L', 'male', 'FSH'),
(2, 3000, 200, 'U/L', 'female', 'FSH');

-- --------------------------------------------------------

--
-- Table structure for table `generalemailsettings`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `generalemailsettings`;
CREATE TABLE `generalemailsettings` (
  `id` int(100) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `apppassword` varchar(100) NOT NULL,
  `verificationSubject` varchar(200) NOT NULL,
  `readySubject` varchar(200) NOT NULL,
  `sampleSubject` varchar(200) NOT NULL,
  `createdon` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `generalemailsettings`:
--

-- --------------------------------------------------------

--
-- Table structure for table `generalstocks`
--
-- Creation: Jan 11, 2024 at 09:45 AM
-- Last update: Jan 22, 2024 at 10:51 PM
--

DROP TABLE IF EXISTS `generalstocks`;
CREATE TABLE `generalstocks` (
  `stockid` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` int(10) NOT NULL,
  `consumptionunit` varchar(255) NOT NULL,
  `purchaseunit` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL,
  `alertlevel` int(255) NOT NULL,
  `materialcode` varchar(255) NOT NULL,
  `updatedOn` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `warehouse` int(10) DEFAULT NULL,
  `shelf` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `generalstocks`:
--

--
-- Dumping data for table `generalstocks`
--

INSERT INTO `generalstocks` (`stockid`, `name`, `category`, `consumptionunit`, `purchaseunit`, `quantity`, `alertlevel`, `materialcode`, `updatedOn`, `date`, `warehouse`, `shelf`) VALUES
(2, 'syringes', 3, 'l', 'ml', -1300, 100, 'KKD', '2024-01-22 22:25:56.650672', '2023-10-06 05:40:48.098000', 9, 12),
(3, 'tiiu', 3, 'pcs', 'ml', 9800, 8888, 'mjfdjj', '2024-01-22 23:51:57.532767', '2024-01-11 08:31:43.068000', 10, 17),
(4, 'tiifu', 7, 'pcs', 'ml', 1000, 8888, 'mjfdjj', '2024-01-21 13:46:41.000000', '2024-01-11 09:31:43.068000', 10, 18),
(5, 'edta tubes', 1, 'g', 'box', 0, 200, 'edta', '2024-01-21 13:41:51.591398', '2023-09-23 20:38:08.758000', NULL, NULL),
(7, 'Mildred Bag', 2, 'l', 'kg', 0, 200, 'Mild', '2024-01-21 13:41:51.591398', '2023-10-13 06:44:29.560000', 7, 6),
(8, 'cotton', 3, 'ml', 'l', 0, 8484, 'jdjdj', '2024-01-21 13:41:51.591398', '2023-10-13 04:53:21.830000', 7, 6),
(9, 'edta tubes', 2, 'g', 'box', 0, 200, 'edta', '2024-01-21 13:41:51.591398', '2023-09-23 22:38:08.758000', 1, 9),
(10, 'eans holder ', 3, 'pcs', 'pcs', 0, 100, 'beaHoo', '2024-01-21 13:41:51.591398', '2023-11-14 22:03:31.919861', 5, 7),
(12, 'Tiifu', 7, 'pcs', 'ml', 0, 8888, 'mjfdjj', '2024-01-21 13:41:51.591398', '2024-01-11 09:31:43.068000', 5, 5),
(19, 'firman', 7, 'g', 'ml', 0, 100, '4894djjj', '2024-01-21 13:41:51.591398', '2024-01-11 09:57:29.611000', 5, 5),
(20, 'warebowls', 2, 'bottle', 'pcs', 0, 200, 'edta', '2024-01-21 13:41:51.591398', '2024-01-13 13:13:15.507611', NULL, NULL),
(21, 'tiifu shefij hamza', 2, 'g', 'g', 0, 939, 'KEKEK', '2024-01-21 13:41:51.591398', '2024-01-13 14:44:34.476574', NULL, NULL),
(22, 'tiifuxndfhj', 2, 'g', 'l', 0, 949393, 'djegiwk', '2024-01-21 13:41:51.591398', '2024-01-13 15:33:38.863883', 7, 7),
(23, 'Test Stock', 1, 'unit', 'unit', 0, 5, '12345', '2024-01-21 13:41:51.591398', '2024-01-18 10:50:14.960067', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `generalstorecredithx`
--
-- Creation: Jan 19, 2024 at 02:30 PM
--

DROP TABLE IF EXISTS `generalstorecredithx`;
CREATE TABLE `generalstorecredithx` (
  `id` int(100) NOT NULL,
  `productordersid` int(100) NOT NULL,
  `stockid` int(100) NOT NULL,
  `credit` int(100) DEFAULT NULL,
  `brandid` int(100) NOT NULL,
  `batchnumber` varchar(100) NOT NULL,
  `creditDate` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `generalstorecredithx`:
--

--
-- Dumping data for table `generalstorecredithx`
--

INSERT INTO `generalstorecredithx` (`id`, `productordersid`, `stockid`, `credit`, `brandid`, `batchnumber`, `creditDate`) VALUES
(1, 3, 3, 10000, 44, 'LOT67', '2024-01-21 13:46:41.099408'),
(2, 2, 4, 1000, 29, 'EIEI', '2024-01-21 13:46:41.171978'),
(3, 1, 2, 1000, 24, 'IEII', '2024-01-21 13:46:41.338463'),
(4, 4, 2, 300, 32, 'loy5', '2024-01-22 01:56:39.226367');

-- --------------------------------------------------------

--
-- Table structure for table `generalstoredebithx`
--
-- Creation: Jan 19, 2024 at 02:29 PM
--

DROP TABLE IF EXISTS `generalstoredebithx`;
CREATE TABLE `generalstoredebithx` (
  `id` int(100) NOT NULL,
  `stockid` int(100) NOT NULL,
  `brandid` int(100) NOT NULL,
  `debitdate` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `batchnumber` varchar(100) NOT NULL,
  `productordersid` int(100) NOT NULL,
  `debitqty` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `generalstoredebithx`:
--

--
-- Triggers `generalstoredebithx`
--
DROP TRIGGER IF EXISTS `updateMainStockAfterDeptReceived`;
DELIMITER $$
CREATE TRIGGER `updateMainStockAfterDeptReceived` AFTER INSERT ON `generalstoredebithx` FOR EACH ROW BEGIN 
 IF NEW.debitqty > 0 THEN 
 -- UPDATING MAIN SUPPLY AFTER DEBIT 
     UPDATE mainstoresupply SET quantity = quantity -   NEW.debitqty WHERE brandid = NEW.brandid AND stockid = NEW.stockid;
     END IF;
     END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `glycated_haemoglobin`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `glycated_haemoglobin`;
CREATE TABLE `glycated_haemoglobin` (
  `id` int(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `result` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `glucose` varchar(255) DEFAULT NULL,
  `time` time(6) NOT NULL DEFAULT current_timestamp(),
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `glycated_haemoglobin`:
--

--
-- Dumping data for table `glycated_haemoglobin`
--

INSERT INTO `glycated_haemoglobin` (`id`, `billingid`, `patientid`, `created_on`, `updated_on`, `result`, `comments`, `glucose`, `time`, `employeeid`) VALUES
(4, 211, 2023101537, '2023-11-29 03:21:17.541978', '2023-12-02 00:02:04.760896', '44', '<p>fkkfkf</p>', '66', '03:21:17.000000', NULL),
(5, 205, 202310127, '2023-12-01 23:33:34.074521', NULL, '894', '<p>ekofkwek</p>', '939', '23:33:34.000000', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `haemoglobinelectrophoresis`
--
-- Creation: Dec 05, 2023 at 04:52 AM
--

DROP TABLE IF EXISTS `haemoglobinelectrophoresis`;
CREATE TABLE `haemoglobinelectrophoresis` (
  `parameter` varchar(100) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `upper` int(100) NOT NULL,
  `lower` int(100) NOT NULL,
  `setupid` int(255) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `employeeid` int(11) NOT NULL,
  `updated_on` datetime(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000' ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `haemoglobinelectrophoresis`:
--

--
-- Dumping data for table `haemoglobinelectrophoresis`
--

INSERT INTO `haemoglobinelectrophoresis` (`parameter`, `unit`, `upper`, `lower`, `setupid`, `created_on`, `employeeid`, `updated_on`) VALUES
('hbF', 'g/dL', 200, 2030, 1, '2023-12-02 13:15:28.574711', 0, '0000-00-00 00:00:00.000000'),
('hbA', 'g/dL', 16, 12, 2, '2023-12-02 13:15:28.574935', 0, '0000-00-00 00:00:00.000000'),
('hbA2', 'g/dL', 16, 2, 3, '2023-12-02 13:15:28.575090', 0, '0000-00-00 00:00:00.000000'),
('hbC', 'g/dL', 2000, 100, 4, '2023-12-02 13:15:28.575193', 0, '0000-00-00 00:00:00.000000'),
('hbS', 'g/dL', 1000, 200, 5, '2023-12-02 13:15:28.576830', 0, '0000-00-00 00:00:00.000000'),
('zii', 'g/dL', 4000, 200, 6, '2023-12-02 13:15:28.576998', 0, '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `hepatitisbresult`
--
-- Creation: Dec 05, 2023 at 04:50 AM
-- Last update: Jan 22, 2024 at 09:19 PM
--

DROP TABLE IF EXISTS `hepatitisbresult`;
CREATE TABLE `hepatitisbresult` (
  `id` int(100) NOT NULL,
  `billingid` int(100) NOT NULL,
  `patientid` bigint(100) NOT NULL,
  `created_on` date DEFAULT current_timestamp(),
  `time` time(6) DEFAULT current_timestamp(),
  `results` varchar(255) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `employeeid` int(11) DEFAULT NULL,
  `updated_on` datetime(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000' ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `hepatitisbresult`:
--

--
-- Dumping data for table `hepatitisbresult`
--

INSERT INTO `hepatitisbresult` (`id`, `billingid`, `patientid`, `created_on`, `time`, `results`, `comments`, `employeeid`, `updated_on`) VALUES
(1, 1, 2023729, '2023-09-03', '09:02:53.000000', 'non reactive', 'jdjwdfjkwdfj', NULL, '0000-00-00 00:00:00.000000'),
(2, 58, 2023854, '2023-09-05', '11:26:47.000000', 'non reactive', 'kle;fioefuiqo7fyuqwjh', NULL, '0000-00-00 00:00:00.000000'),
(3, 61, 202385, '2023-09-05', '11:34:42.000000', 'non reactive', 'juduqwfqwyu', NULL, '0000-00-00 00:00:00.000000'),
(4, 73, 2023854, '2023-09-15', '14:37:34.000000', 'non reactive', 'kwfiwiwefiiwef', NULL, '0000-00-00 00:00:00.000000'),
(5, 66, 2023854, '2023-09-18', '13:01:32.000000', 'non reactive', 'kwefkfoqioio', NULL, '0000-00-00 00:00:00.000000'),
(6, 84, 202382111, '2023-10-03', '08:06:15.000000', 'non reactive', 'kgkkgwjgjwfj', NULL, '0000-00-00 00:00:00.000000'),
(7, 283, 1702808069956, '2024-01-22', '22:19:24.000000', 'reactive', '<p>jkjajdj</p>', NULL, '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `hepatitisb_profile`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `hepatitisb_profile`;
CREATE TABLE `hepatitisb_profile` (
  `id` int(255) NOT NULL,
  `HBsAg` varchar(50) NOT NULL DEFAULT 'non reactive',
  `HBsAb` varchar(50) NOT NULL DEFAULT 'non reactive',
  `HBeAg` varchar(50) NOT NULL DEFAULT 'non reactive',
  `HBeAb` varchar(50) NOT NULL DEFAULT 'non reactive',
  `HBcAb` varchar(50) NOT NULL DEFAULT 'non reactive',
  `comments` varchar(255) NOT NULL,
  `billingid` int(100) NOT NULL,
  `created_on` date DEFAULT current_timestamp(),
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `patientid` bigint(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `hepatitisb_profile`:
--

--
-- Dumping data for table `hepatitisb_profile`
--

INSERT INTO `hepatitisb_profile` (`id`, `HBsAg`, `HBsAb`, `HBeAg`, `HBeAb`, `HBcAb`, `comments`, `billingid`, `created_on`, `updated_on`, `patientid`, `employeeid`) VALUES
(1, 'non reactive', 'non reactive', 'reactive', 'reactive', 'reactive', 'wekfkwejkwekj', 5, '2023-09-04', NULL, 2023729, NULL),
(2, 'reactive', 'reactive', 'non reactive', 'reactive', 'non reactive', 'wdkjqJFKAFUY', 36, '2023-09-04', NULL, 2023729, NULL),
(3, 'reactive', 'reactive', 'reactive', 'reactive', 'non reactive', 'qfjkjqwfwfhjh', 62, '2023-09-06', NULL, 2023854, NULL),
(4, 'reactive', 'non reactive', 'reactive', 'non reactive', 'reactive', 'weiogoweoiqwefoqwerio', 70, '2023-09-18', NULL, 2023854, NULL),
(5, 'reactive', 'non reactive', 'reactive', 'reactive', 'reactive', 'no rounds ', 114, '2023-10-28', NULL, 20239723, NULL),
(6, 'reactive', 'reactive', 'reactive', 'reactive', 'reactive', '<p>huuhh</p>', 207, '2023-11-26', '2023-12-04 07:52:21.000000', 2023101538, NULL),
(7, 'non reactive', 'non reactive', 'non reactive', 'non reactive', 'non reactive', '<p>kvkwdk</p>', 204, '2023-11-27', '2023-12-04 00:00:00.000000', 2023101537, NULL),
(8, 'non reactive', 'non reactive', 'non reactive', 'non reactive', 'non reactive', '<p>kdkwdkwdkwdkfkkfwkfkqfkqkfqk</p>', 218, '2023-12-09', NULL, 1702110827377, 2);

-- --------------------------------------------------------

--
-- Table structure for table `hepatitiscresult`
--
-- Creation: Dec 05, 2023 at 04:51 AM
--

DROP TABLE IF EXISTS `hepatitiscresult`;
CREATE TABLE `hepatitiscresult` (
  `id` int(100) NOT NULL,
  `billingid` int(100) NOT NULL,
  `patientid` bigint(100) NOT NULL,
  `created_on` date DEFAULT current_timestamp(),
  `time` time(6) DEFAULT current_timestamp(),
  `results` varchar(255) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `employeeid` int(11) DEFAULT NULL,
  `updated_on` datetime(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000' ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `hepatitiscresult`:
--

--
-- Dumping data for table `hepatitiscresult`
--

INSERT INTO `hepatitiscresult` (`id`, `billingid`, `patientid`, `created_on`, `time`, `results`, `comments`, `employeeid`, `updated_on`) VALUES
(1, 34, 2023729, '2023-09-04', '12:47:33.000000', 'reactive', 'iweiwiqwi', NULL, '0000-00-00 00:00:00.000000'),
(2, 50, 202384, '2023-09-04', '16:32:13.000000', 'non reactive', '3kjeetu2et2euifjkwxm,zui\njiwuflwegjeug2eifwduijefjejf\n\nejwfjwefj2efjwdwyfuefsvwduig\n\njhejkwei2eioo2ei2eio2r', NULL, '0000-00-00 00:00:00.000000'),
(3, 49, 202384, '2023-09-04', '17:24:31.000000', 'non reactive', 'wdkjawhjwej', NULL, '0000-00-00 00:00:00.000000'),
(4, 61, 202385, '2023-09-05', '11:34:20.000000', 'non reactive', 'juweujuqwfy', NULL, '0000-00-00 00:00:00.000000'),
(5, 198, 2023101537, '2023-11-20', '00:55:31.000000', 'reactive', 'iweiiwefiwei', NULL, '0000-00-00 00:00:00.000000'),
(8, 215, 2023101539, '2023-12-07', '10:38:17.000000', 'reactive', '<p>sjsjsj</p>', NULL, '2023-12-07 11:00:15.080152'),
(9, 217, 20239720, '2023-12-07', '11:38:44.000000', 'reactive', '<p>kdkwefk</p>', NULL, '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `inventorycustomization`
--
-- Creation: Jan 14, 2024 at 07:39 AM
--

DROP TABLE IF EXISTS `inventorycustomization`;
CREATE TABLE `inventorycustomization` (
  `id` int(50) NOT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '{}' CHECK (json_valid(`settings`)),
  `updated_on` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `inventorycustomization`:
--

--
-- Dumping data for table `inventorycustomization`
--

INSERT INTO `inventorycustomization` (`id`, `settings`, `updated_on`) VALUES
(1, '{\"alertdays\":21,\"stocksAutoDeduct\":true}', '2024-01-14 08:47:18.000000');

-- --------------------------------------------------------

--
-- Table structure for table `lhresult`
--
-- Creation: Nov 29, 2023 at 05:01 PM
--

DROP TABLE IF EXISTS `lhresult`;
CREATE TABLE `lhresult` (
  `keyid` int(255) NOT NULL,
  `parameter` varchar(50) NOT NULL,
  `billingid` int(20) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `value` int(100) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000' ON UPDATE current_timestamp(6),
  `comment` varchar(100) NOT NULL,
  `unit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `lhresult`:
--

--
-- Dumping data for table `lhresult`
--

INSERT INTO `lhresult` (`keyid`, `parameter`, `billingid`, `patientid`, `value`, `created_on`, `updated_on`, `comment`, `unit`) VALUES
(1, 'lh', 101, 202382112, 777, '2023-10-05 21:23:28.095631', '0000-00-00 00:00:00.000000', 'kjqshfqwjj', ''),
(2, 'LH', 103, 20239720, 444, '2023-10-07 10:26:34.427341', '2023-10-07 10:38:31.000000', 'kekkqkkwkk', ''),
(3, 'LH', 212, 2023101537, 40, '2023-11-29 09:32:03.521281', '2023-11-29 10:22:57.342850', '', 'U/L');

-- --------------------------------------------------------

--
-- Table structure for table `lhsetup`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `lhsetup`;
CREATE TABLE `lhsetup` (
  `setupid` int(255) NOT NULL,
  `upper` int(10) NOT NULL,
  `lower` int(10) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `parameter` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `lhsetup`:
--

--
-- Dumping data for table `lhsetup`
--

INSERT INTO `lhsetup` (`setupid`, `upper`, `lower`, `unit`, `gender`, `parameter`) VALUES
(1, 500, 200, 'U/L', 'male', 'LH'),
(2, 400, 200, 'U/L', 'female', 'LH');

-- --------------------------------------------------------

--
-- Table structure for table `loginlogs`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `loginlogs`;
CREATE TABLE `loginlogs` (
  `keyid` int(255) NOT NULL,
  `loginTime` datetime(6) NOT NULL,
  `employeeid` int(10) NOT NULL,
  `loginSessionId` int(10) NOT NULL,
  `logoutTime` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `loginlogs`:
--

-- --------------------------------------------------------

--
-- Table structure for table `mainstoresupply`
--
-- Creation: Jan 17, 2024 at 05:36 PM
--

DROP TABLE IF EXISTS `mainstoresupply`;
CREATE TABLE `mainstoresupply` (
  `id` int(50) NOT NULL,
  `stockid` int(255) NOT NULL,
  `quantity` int(255) DEFAULT 0,
  `brandid` int(10) DEFAULT NULL,
  `updated_on` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `mainstoresupply`:
--

--
-- Dumping data for table `mainstoresupply`
--

INSERT INTO `mainstoresupply` (`id`, `stockid`, `quantity`, `brandid`, `updated_on`) VALUES
(1, 3, 10300, 0, '2024-01-21 13:46:41.099408'),
(2, 4, 1300, 0, '2024-01-21 13:46:41.171978'),
(3, 2, 1300, 0, '2024-01-21 13:46:41.338463');

-- --------------------------------------------------------

--
-- Table structure for table `malaria`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `malaria`;
CREATE TABLE `malaria` (
  `keyid` int(255) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `species` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `parasitenumber` int(60) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `malaria`:
--

--
-- Dumping data for table `malaria`
--

INSERT INTO `malaria` (`keyid`, `patientid`, `billingid`, `species`, `comments`, `parasitenumber`, `created_on`, `updated_on`, `employeeid`) VALUES
(1, 2023729, 1, 'Falciparum', 'oiwiwefi', 100, '2023-09-03 09:01:43.626931', NULL, NULL),
(2, 2023854, 63, 'Falciparum', 'kgwjgkwjk', 18, '2023-09-06 10:44:41.349574', NULL, NULL),
(3, 20238186, 78, 'Falciparum', 'ieieiifoqweo', 2120, '2023-09-18 10:16:54.200351', NULL, NULL),
(4, 2023854, 71, 'Falciparum', 'iowefiwefiooqweoioi', 500, '2023-09-18 13:01:19.677786', NULL, NULL),
(5, 202382111, 79, 'Falciparum', '<p>severe aneamia		</p>', 4949, '2023-09-21 09:54:01.460682', '2023-09-25 23:11:52.000000', NULL),
(6, 202382111, 80, 'Falciparum', 'uwduwifquu', 400, '2023-09-21 12:52:18.246753', NULL, NULL),
(7, 20238187, 98, 'Falciparum', 'kwkwdkkwfk', 200, '2023-10-05 10:09:29.779214', NULL, NULL),
(8, 20238155, 109, 'ovalex', 'hwvjjvwdsjjjscjjj', 290, '2023-10-09 05:26:08.810072', NULL, NULL),
(9, 20239723, 108, 'Falciparum', 'k2efjfyudhwefhwhfhdfhwdfhqh  hwfhhwvuwiifdfqhfdfiwdifq   ywdfqufuwd\n\n\nhwfhwdhfqtfqufuya', 8238, '2023-10-10 19:24:24.690064', NULL, NULL),
(10, 20239723, 111, 'ovalex', 'iqsqsjaj', 88, '2023-10-17 19:34:48.441375', NULL, NULL),
(11, 202392724, 118, 'Falciparum', 'jfjfjdjjjsj', 100, '2023-10-28 10:19:24.602066', NULL, NULL),
(12, 20239723, 110, 'Falciparum', 'kdkwdkk', 120, '2023-10-30 13:45:29.165821', NULL, NULL),
(13, 20239721, 112, 'Falciparum', 'kwdkwkk', 400, '2023-10-30 13:46:13.402324', NULL, NULL),
(14, 20239723, 107, 'Falciparum', 'oiwfkwei', 120, '2023-10-30 13:46:42.028086', NULL, NULL),
(15, 20238155, 122, 'Falciparum', 'Malaria reactive', 400, '2023-10-31 00:37:25.188668', NULL, NULL),
(16, 202310127, 125, 'Falciparum', 'Malaria parasites seen', 200, '2023-11-04 02:28:18.924044', NULL, NULL),
(17, 202310428, 127, 'Falciparum', 'Malaria parasites seen ', 300, '2023-11-06 16:40:47.668993', NULL, NULL),
(18, 2023101429, 197, 'Falciparum', '<p>kofqwefj</p>', 120, '2023-11-20 07:50:53.322283', '2023-12-01 23:24:21.000000', NULL),
(19, 202392724, 196, 'Falciparum', 'JWDFJFJJQJWJ\n\nFJJFJFFjwdjwdfhhfhqsfh', 200, '2023-11-20 07:52:11.506100', '2023-12-07 10:01:13.000000', 2),
(20, 2023101537, 201, 'Falciparum', 'kjwdfjwjwfj', 200, '2023-11-21 01:47:14.275152', '2023-11-24 17:10:37.000000', NULL),
(21, 20239518, 199, 'Falciparum', '<p>efjjfuyfqfc hehfhfhqfhws fwififjweui</p>', 1230, '2023-11-23 10:55:50.868417', '2023-12-02 01:13:06.000000', NULL),
(22, 2023101537, 204, 'ovalex', 'JWFJWFJHQDJH', 2000, '2023-11-26 11:39:28.657006', NULL, NULL),
(23, 2023101539, 215, 'Falciparum', '<p>eoi2efuw2</p>', 50, '2023-12-04 20:00:58.959280', '2023-12-04 20:31:39.000000', NULL),
(24, 1702200924561, 219, 'Falciparum', '<p>jjefjfjj</p>', 1120, '2023-12-12 09:23:08.964075', NULL, 2),
(25, 1704453099655, 286, 'ovalex', '<p>vxdd</p>', 120, '2024-01-18 18:44:52.474940', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `manager_sample_descision`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `manager_sample_descision`;
CREATE TABLE `manager_sample_descision` (
  `sampleid` int(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `manager` varchar(255) DEFAULT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `testid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `manager_sample_descision`:
--

-- --------------------------------------------------------

--
-- Table structure for table `me`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `me`;
CREATE TABLE `me` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `me`:
--

--
-- Dumping data for table `me`
--

INSERT INTO `me` (`id`, `user`) VALUES
(4, 3),
(7, 3),
(8, 3),
(9, 3),
(10, 3),
(11, 3),
(12, 3),
(13, 3),
(14, 3),
(15, 3),
(16, 3),
(17, 3),
(18, 3),
(19, 3),
(20, 3),
(21, 3),
(22, 3),
(23, 3),
(24, 3),
(25, 3),
(26, 3),
(27, 3),
(28, 3),
(29, 3),
(30, 3);

-- --------------------------------------------------------

--
-- Table structure for table `new_patients`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `new_patients`;
CREATE TABLE `new_patients` (
  `id` int(255) NOT NULL,
  `patientid` bigint(20) DEFAULT NULL,
  `firstname` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `age` int(10) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `marital_status` varchar(50) NOT NULL,
  `mobile_number` varchar(13) NOT NULL,
  `agetype` varchar(10) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `activation_status` varchar(10) NOT NULL DEFAULT 'FALSE',
  `lastname` varchar(255) NOT NULL,
  `middlename` varchar(255) DEFAULT NULL,
  `organization` varchar(100) DEFAULT NULL,
  `contactpointer` varchar(10) NOT NULL DEFAULT 'self'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `new_patients`:
--

--
-- Dumping data for table `new_patients`
--

INSERT INTO `new_patients` (`id`, `patientid`, `firstname`, `email`, `dob`, `age`, `gender`, `marital_status`, `mobile_number`, `agetype`, `occupation`, `date`, `activation_status`, `lastname`, `middlename`, `organization`, `contactpointer`) VALUES
(1, 1702110827377, 'Tiifu', '', '1995-11-06', 28, 'male', '', '0595964565', 'years', '', '2023-12-09', 'TRUE', 'Hamza', 'Kojo', NULL, 'self'),
(2, 1702200924561, 'tiifu ', 'hamzatiifu45@gmail.com', '1995-11-06', 0, 'male', 'single', '0595964564', '', 'nursing ', '2023-12-10', 'TRUE', 'hamza', 'hamq', NULL, 'self'),
(3, 1702808069956, 'shefik ', 'asananyaaba45@gmail.com', '1993-09-09', 30, 'male', 'married', '0241758550', 'years', 'Network administrator', '2023-12-17', 'TRUE', 'tTiifu', 'Kweku', ' Alkatech', 'self'),
(67, 1703107987910, 'Tiifu', 'leonidesintell@gmail.com', '1995-11-06', 28, 'male', 'married', '0595964565', 'years', 'nursing ', '2023-12-20', 'TRUE', 'Hamza', 'Kojo', 'Leonides', 'self'),
(86, 1704453099655, 'tiifu', 'xelobcoder@gmail.com', '1995-11-06', 28, 'female', 'single', '0241758555', 'years', 'nursing ', '2024-01-05', 'TRUE', 'hamza', 'shefij', 'Leonides', 'self');

--
-- Triggers `new_patients`
--
DROP TRIGGER IF EXISTS `autoAddClients`;
DELIMITER $$
CREATE TRIGGER `autoAddClients` AFTER INSERT ON `new_patients` FOR EACH ROW BEGIN 
INSERT INTO patients_credentials(PATIENTID,USERNAME,PASSWORD)
VALUES(NEW.PATIENTID,CONCAT(NEW.FIRSTNAME,NEW.LASTNAME),CONCAT(NEW.FIRSTNAME,NEW.LASTNAME,NEW.PATIENTID));
INSERT INTO patientemmergencycontactinformation(patientid) VALUES (NEW.patientid);
INSERT INTO patientsaddress(patientid)VALUES (NEW.patientid);
INSERT INTO patients_settings(PATIENTID)VALUES(NEW.PATIENTID);
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `autoDeleteClient`;
DELIMITER $$
CREATE TRIGGER `autoDeleteClient` AFTER DELETE ON `new_patients` FOR EACH ROW BEGIN
 DELETE FROM patientemmergencycontactinformation WHERE patientid = OLD.PATIENTID;
 DELETE FROM patients_settings WHERE patientid = OLD.PATIENTID;
 DELETE FROM patients_credentials WHERE patientid = OLD.PATIENTID;
 DELETE FROM patientsaddress WHERE patientid = OLD.PATIENTID;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `orderreceivedaccountsummary`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `orderreceivedaccountsummary`;
CREATE TABLE `orderreceivedaccountsummary` (
  `orderTransactionid` bigint(50) DEFAULT NULL,
  `taxAmount` int(20) DEFAULT NULL,
  `method` varchar(20) NOT NULL DEFAULT 'absolute',
  `debit` int(50) NOT NULL DEFAULT 0,
  `credit` int(50) NOT NULL DEFAULT 0,
  `insertedOn` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updatedOn` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `orderreceivedaccountsummary`:
--

--
-- Dumping data for table `orderreceivedaccountsummary`
--

INSERT INTO `orderreceivedaccountsummary` (`orderTransactionid`, `taxAmount`, `method`, `debit`, `credit`, `insertedOn`, `updatedOn`) VALUES
(1705841129049, 500, 'absolute', 25000, 0, '2024-01-21 13:45:29.051766', '2024-01-21 13:46:41.000000'),
(1705884928262, 100, 'absolute', 3100, 0, '2024-01-22 01:55:28.264721', '2024-01-22 01:56:39.000000');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--
-- Creation: Jan 17, 2024 at 08:18 PM
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `productordersid` int(255) NOT NULL,
  `stockid` int(255) NOT NULL,
  `orderTransactionid` bigint(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `supplierid` int(255) NOT NULL,
  `suppliername` varchar(255) NOT NULL,
  `purchaseunit` varchar(255) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `quantity` int(255) NOT NULL,
  `received` varchar(255) DEFAULT 'FALSE',
  `quantityReceived` int(255) DEFAULT 0,
  `batchnumber` varchar(255) DEFAULT NULL,
  `balance` int(255) DEFAULT 0,
  `expirydate` date DEFAULT NULL,
  `receiveddate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `price` int(255) DEFAULT 0,
  `totalamount` int(255) DEFAULT 0,
  `productused` varchar(50) DEFAULT 'FALSE',
  `pricing` varchar(15) NOT NULL DEFAULT 'unit',
  `brand` int(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `orders`:
--

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`productordersid`, `stockid`, `orderTransactionid`, `name`, `supplierid`, `suppliername`, `purchaseunit`, `date`, `quantity`, `received`, `quantityReceived`, `batchnumber`, `balance`, `expirydate`, `receiveddate`, `status`, `price`, `totalamount`, `productused`, `pricing`, `brand`) VALUES
(1, 2, 1705841129049, 'syringes', 1, 'johnson johnson', 'Box', '2024-01-21 13:45:29.051766', 1000, 'TRUE', 1000, 'IEII', 0, '2024-02-11', '2024-01-21', 'received', 10, 10000, 'FALSE', 'unit', 24),
(2, 4, 1705841129049, 'tiifu', 1, 'johnson johnson', 'litre', '2024-01-21 13:45:29.066138', 1000, 'TRUE', 1000, 'EIEI', 0, '2024-02-11', '2024-01-21', 'received', 10, 10000, 'FALSE', 'unit', 29),
(3, 3, 1705841129049, 'tiiu', 3, 'king joe suppliers', 'Box', '2024-01-21 13:45:29.065999', 10000, 'TRUE', 10000, 'LOT67', 0, '2024-02-11', '2024-01-12', 'received', 0, 4500, 'FALSE', 'unit', 44),
(4, 2, 1705884928262, 'syringes', 5, 'Barakah Delimwine', 'Box', '2024-01-22 01:55:28.264721', 300, 'TRUE', 300, 'loy5', 0, '2024-02-11', '2024-01-22', 'received', 10, 3000, 'FALSE', 'unit', 32);

--
-- Triggers `orders`
--
DROP TRIGGER IF EXISTS `createorderTransactionSummary`;
DELIMITER $$
CREATE TRIGGER `createorderTransactionSummary` AFTER INSERT ON `orders` FOR EACH ROW BEGIN
INSERT INTO orderreceivedaccountsummary (orderTransactionid) VALUE(NEW.orderTransactionid) ON DUPLICATE KEY UPDATE orderTransactionid = NEW.orderTransactionid;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `updateGeneralStocksOnUpdate`;
DELIMITER $$
CREATE TRIGGER `updateGeneralStocksOnUpdate` AFTER UPDATE ON `orders` FOR EACH ROW BEGIN
   -- update generalstocks 
    UPDATE generalstocks
          SET quantity =
    CASE WHEN NEW.quantityReceived > 0  THEN 
      quantity + NEW.quantityReceived
      ELSE 
       quantity
      END,
    updatedOn = NOW()  
    WHERE stockid = NEW.stockid;
    -- update main store supply
    IF(SELECT COUNT(*) FROM mainstoresupply WHERE stockid = OLD.stockid AND brandid = OLD.brand) > 0 THEN 
    UPDATE mainstoresupply SET quantity = NEW.quantityReceived + quantity;
    ELSE 
    INSERT INTO mainstoresupply (stockid,brandid,quantity) VALUES (OLD.STOCKID,OLD.BRAND,NEW.quantityReceived);
   END IF;
   INSERT INTO generalstorecredithx (productordersid,stockid,credit,batchnumber,brandid)
VALUES(OLD.productordersid,OLD.stockid,NEW.quantityReceived,
       NEW.batchnumber,NEW.brand);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `organization`;
CREATE TABLE `organization` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `mobile` int(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `gpsmapping` varchar(255) DEFAULT NULL,
  `website` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `organization`:
--

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`id`, `name`, `location`, `street`, `mobile`, `address`, `email`, `region`, `gpsmapping`, `website`) VALUES
(1, 'leonides', 'tamale', 'Kalpohin Lowcost 30A', 2147483647, 'Kalpohin Lowcost 30A', 'hamzatiifu45@gmail.com', 'Northern', 'NS-9309-399', 'www.leonides.com'),
(7, 'leonides technologies and suivellance', 'tamale', 'Kalpohin Lowcost 30A', 2147483647, 'Kalpohin Lowcost 30A', 'hamzatiifu45@gmail.com', 'Northern', NULL, 'www.leonides.com'),
(8, 'tiifu boronson engineering and principals', 'tamale ', 'jolly friends', 241758559, 'Kalpohin Lowcost 30A', 'hamzatiifu45@gemail.com', 'Eastern', NULL, ''),
(9, 'kabsad hospital', 'tamale', 'Kalpohin Lowcost 30A', 2147483647, 'Tamale Technical university, Wurishes', 'hamzatiifu45@gmail.com', 'Northern', NULL, '0595964565'),
(10, 'kings diagnostics', 'tamale', 'atambissi', 595964565, 'Kalpohin Lowcost 30A', 'hamzatiifu45@gmail.com', 'Northern', NULL, 'mylab.com');

--
-- Triggers `organization`
--
DROP TRIGGER IF EXISTS `insertIntoContactNaccount`;
DELIMITER $$
CREATE TRIGGER `insertIntoContactNaccount` AFTER INSERT ON `organization` FOR EACH ROW BEGIN 
INSERT INTO organizationcontactperson(organizationid) VALUE(NEW.id);

INSERT INTO organizationaccountinformation (organizationid) VALUE(NEW.id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `organizationaccountinformation`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `organizationaccountinformation`;
CREATE TABLE `organizationaccountinformation` (
  `id` int(11) NOT NULL,
  `organizationid` int(11) NOT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `branch` varchar(255) DEFAULT NULL,
  `accountname` varchar(255) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `module` varchar(20) DEFAULT 'cash',
  `momoname` varchar(100) DEFAULT NULL,
  `momo` int(15) DEFAULT NULL,
  `commission` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `organizationaccountinformation`:
--

--
-- Dumping data for table `organizationaccountinformation`
--

INSERT INTO `organizationaccountinformation` (`id`, `organizationid`, `bankname`, `branch`, `accountname`, `account`, `module`, `momoname`, `momo`, `commission`) VALUES
(1, 7, 'access bank', 'tamale', 'Tiifu hamza', '88384737388', 'bank', NULL, NULL, 10),
(2, 8, 'Access bank', 'Tamale', 'tiifu hamza', '8349493993', 'momo', 'tiifu hamqa', 241758557, 10),
(3, 9, NULL, NULL, NULL, NULL, 'cash', NULL, NULL, 10),
(4, 10, NULL, NULL, NULL, NULL, 'momo', 'tiifu shefik', 241758558, 10);

-- --------------------------------------------------------

--
-- Table structure for table `organizationcontactperson`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `organizationcontactperson`;
CREATE TABLE `organizationcontactperson` (
  `id` int(11) NOT NULL,
  `organizationid` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` int(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `organizationcontactperson`:
--

--
-- Dumping data for table `organizationcontactperson`
--

INSERT INTO `organizationcontactperson` (`id`, `organizationid`, `name`, `email`, `mobile`) VALUES
(1, 7, 'tiifu hamza kojo hamza', 'hamzatiifu45@gmail.com', 2147483647),
(2, 8, 'Tiifu Hamza', 'tiifuofficial@gmail.com', 241758550),
(3, 9, 'nyaaba mildred', 'hamzatiifu45@gmail.com', 2147483647),
(4, 10, 'Mr David fillanond', 'fillabond@gmail.com', 249434803);

-- --------------------------------------------------------

--
-- Table structure for table `pageaccess`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `pageaccess`;
CREATE TABLE `pageaccess` (
  `keyid` int(255) NOT NULL,
  `employeeid` int(255) NOT NULL,
  `registration` tinyint(1) NOT NULL,
  `billing` tinyint(1) NOT NULL,
  `inventory` tinyint(1) NOT NULL,
  `supply` tinyint(1) NOT NULL,
  `payments` tinyint(1) NOT NULL,
  `approval` tinyint(1) NOT NULL,
  `settings` tinyint(1) NOT NULL,
  `phelobotomy` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `pageaccess`:
--

-- --------------------------------------------------------

--
-- Table structure for table `patientemmergencycontactinformation`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `patientemmergencycontactinformation`;
CREATE TABLE `patientemmergencycontactinformation` (
  `keyid` int(100) NOT NULL,
  `patientid` bigint(100) NOT NULL,
  `emmergencyContactName` varchar(50) DEFAULT NULL,
  `emmergencyContactNumber` varchar(50) DEFAULT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `patientemmergencycontactinformation`:
--

--
-- Dumping data for table `patientemmergencycontactinformation`
--

INSERT INTO `patientemmergencycontactinformation` (`keyid`, `patientid`, `emmergencyContactName`, `emmergencyContactNumber`, `relationship`, `occupation`, `address`) VALUES
(109, 1702110827377, NULL, NULL, NULL, NULL, NULL),
(125, 1702200924561, NULL, NULL, NULL, NULL, NULL),
(126, 1702808069956, NULL, NULL, NULL, NULL, NULL),
(136, 1703107987910, NULL, NULL, NULL, NULL, NULL),
(155, 1704453099655, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patientsaddress`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `patientsaddress`;
CREATE TABLE `patientsaddress` (
  `keyid` int(255) NOT NULL,
  `patientid` bigint(100) NOT NULL,
  `area` varchar(100) DEFAULT NULL,
  `region` varchar(50) DEFAULT NULL,
  `gpsLocation` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `patientsaddress`:
--

--
-- Dumping data for table `patientsaddress`
--

INSERT INTO `patientsaddress` (`keyid`, `patientid`, `area`, `region`, `gpsLocation`, `address`) VALUES
(170, 1702110827377, NULL, NULL, NULL, NULL),
(186, 1702200924561, NULL, NULL, NULL, NULL),
(187, 1702808069956, NULL, NULL, NULL, NULL),
(197, 1703107987910, NULL, NULL, NULL, NULL),
(216, 1704453099655, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patients_credentials`
--
-- Creation: Nov 15, 2023 at 02:45 AM
--

DROP TABLE IF EXISTS `patients_credentials`;
CREATE TABLE `patients_credentials` (
  `id` int(20) NOT NULL,
  `patientid` bigint(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `updated` varchar(6) NOT NULL DEFAULT 'false',
  `updated_on` datetime(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000' ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `patients_credentials`:
--

--
-- Dumping data for table `patients_credentials`
--

INSERT INTO `patients_credentials` (`id`, `patientid`, `username`, `password`, `updated`, `updated_on`) VALUES
(46, 1702110827377, 'TiifuHamza', 'TiifuHamza1702110827377', 'false', '0000-00-00 00:00:00.000000'),
(62, 1702200924561, 'tiifu hamza', 'tiifu hamza1702200924561', 'false', '0000-00-00 00:00:00.000000'),
(63, 1702808069956, 'shefik tTiifu', 'shefik tTiifu1702808069956', 'false', '0000-00-00 00:00:00.000000'),
(73, 1703107987910, 'TiifuHamza', 'TiifuHamza1703107987910', 'false', '0000-00-00 00:00:00.000000'),
(92, 1704453099655, 'tiifuhamza', 'tiifuhamza1704453099655', 'false', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `patients_settings`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `patients_settings`;
CREATE TABLE `patients_settings` (
  `id` int(50) NOT NULL,
  `patientid` bigint(50) NOT NULL,
  `mode` varchar(50) NOT NULL DEFAULT 'hardcopy',
  `method` varchar(50) NOT NULL DEFAULT 'None',
  `notify` tinyint(1) DEFAULT 1,
  `_read` tinyint(1) DEFAULT NULL,
  `read_on` datetime(6) DEFAULT NULL,
  `authenticated` tinyint(1) NOT NULL DEFAULT 0,
  `authenticationMode` varchar(20) DEFAULT NULL,
  `emailAuthenticated` varchar(6) NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `patients_settings`:
--

--
-- Dumping data for table `patients_settings`
--

INSERT INTO `patients_settings` (`id`, `patientid`, `mode`, `method`, `notify`, `_read`, `read_on`, `authenticated`, `authenticationMode`, `emailAuthenticated`) VALUES
(1, 202382112, 'WhatApp', 'email', 0, NULL, NULL, 0, NULL, 'false'),
(2, 20239518, 'WhatApp', 'sms', 0, NULL, NULL, 0, NULL, 'false'),
(3, 20239619, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(4, 20239720, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(5, 20239721, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(6, 20239722, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(7, 20239723, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(8, 202392724, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(9, 202393125, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(10, 202393126, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(11, 202310127, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(12, 202310428, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(13, 2023101429, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(14, 2023101430, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(15, 2023101431, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(16, 2023101432, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(17, 2023101433, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(18, 2023101434, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(19, 2023101535, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(20, 2023101536, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(21, 2023101537, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(22, 2023101538, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(23, 2023101539, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(24, 202311840, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(25, 202311841, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(26, 202311842, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(27, 202311843, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(28, 202311844, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(29, 202311845, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(30, 202311846, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(31, 202311851, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(32, 202311852, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(33, 202311853, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(34, 202311854, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(35, 202311855, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(36, 202311856, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(37, 202311861, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(38, 99999999, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(39, 202311884, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(40, 202311885, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(41, 202311886, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(42, 202311887, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(43, 2023118, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(44, 20231181, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(45, 20231182, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(46, 20231183, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(47, 20231184, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(48, 20231185, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(49, 20231186, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(50, 2023119, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(51, 2023110, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(52, 202311000, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(53, 202311827, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(54, 2023128, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(93, 1702110827377, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(109, 1702200924561, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(110, 1702808069956, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(120, 1703107987910, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false'),
(139, 1704453099655, 'hardcopy', 'None', 1, NULL, NULL, 0, NULL, 'false');

-- --------------------------------------------------------

--
-- Table structure for table `paymentmodes`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `paymentmodes`;
CREATE TABLE `paymentmodes` (
  `KeyID` int(255) NOT NULL,
  `PaymentMode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `paymentmodes`:
--

--
-- Dumping data for table `paymentmodes`
--

INSERT INTO `paymentmodes` (`KeyID`, `PaymentMode`) VALUES
(3, 'bank transfer'),
(4, 'cash'),
(2, 'cheque'),
(5, 'invoice'),
(1, 'momo');

-- --------------------------------------------------------

--
-- Table structure for table `performing_test`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `performing_test`;
CREATE TABLE `performing_test` (
  `ID` int(255) NOT NULL,
  `PATIENTID` varchar(255) NOT NULL,
  `DATE` date NOT NULL DEFAULT current_timestamp(),
  `URGENCY` varchar(255) NOT NULL,
  `BILLINGID` int(100) NOT NULL,
  `SAMPLING_CENTER` int(25) NOT NULL,
  `PHELOBOTOMIST` int(100) DEFAULT NULL,
  `TIME` time(6) NOT NULL DEFAULT current_timestamp(),
  `PHELOBOTOMY_MESSAGE` varchar(255) NOT NULL,
  `INSPECTION` int(11) NOT NULL,
  `INSPECTION_TIME` time(6) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `performing_test`:
--

--
-- Triggers `performing_test`
--
DROP TRIGGER IF EXISTS `onDeletePerformingTest`;
DELIMITER $$
CREATE TRIGGER `onDeletePerformingTest` AFTER DELETE ON `performing_test` FOR EACH ROW BEGIN
DELETE FROM test_ascension  WHERE billingid = OLD.billingid;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `psaresult`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `psaresult`;
CREATE TABLE `psaresult` (
  `keyid` int(255) NOT NULL,
  `parameter` varchar(50) NOT NULL,
  `billingid` int(20) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `value` int(100) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `comment` varchar(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL,
  `unit` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `psaresult`:
--

--
-- Dumping data for table `psaresult`
--

INSERT INTO `psaresult` (`keyid`, `parameter`, `billingid`, `patientid`, `value`, `created_on`, `updated_on`, `comment`, `employeeid`, `unit`) VALUES
(1, 'PSA', 103, 20239720, 8848, '2023-10-07 10:45:06.656859', '0000-00-00 00:00:00.000000', 'jfjwfjjj', NULL, ''),
(2, 'PSA', 107, 20239723, 55, '2023-10-10 19:23:38.720847', '0000-00-00 00:00:00.000000', 'kekkwdkvhvjjsdvkakvajvkdvwdjks  hwjhasdjkvavadkva   \njfjwjvdvjjwdfs kxskvkkvhjwdvjsjkvajkjkajk\n\n', NULL, ''),
(3, 'PSA', 122, 20238155, 10, '2023-10-31 00:37:08.725457', '0000-00-00 00:00:00.000000', 'PSA high', NULL, ''),
(4, '  PSA', 217, 20239720, 300, '2023-12-07 11:33:50.478740', '2023-12-07 11:36:01.000000', '', 2, 'U/L'),
(5, '  PSA', 219, 1702200924561, 23, '2023-12-12 09:23:17.291877', NULL, '', 2, 'U/L');

-- --------------------------------------------------------

--
-- Table structure for table `psasetup`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `psasetup`;
CREATE TABLE `psasetup` (
  `setupid` int(255) NOT NULL,
  `upper` int(10) NOT NULL,
  `lower` int(10) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `parameter` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `psasetup`:
--

--
-- Dumping data for table `psasetup`
--

INSERT INTO `psasetup` (`setupid`, `upper`, `lower`, `unit`, `gender`, `parameter`) VALUES
(1, 3000, 100, 'U/L', '', '  PSA');

-- --------------------------------------------------------

--
-- Table structure for table `result_aids`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_aids`;
CREATE TABLE `result_aids` (
  `keyid` int(255) NOT NULL,
  `reaction` varchar(50) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `billingid` int(50) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `comments` varchar(50) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_aids`:
--

--
-- Dumping data for table `result_aids`
--

INSERT INTO `result_aids` (`keyid`, `reaction`, `created_on`, `updated_on`, `billingid`, `patientid`, `comments`, `employeeid`) VALUES
(1, 'non reactive', '2023-11-27 07:12:51.663735', '2023-12-07 13:22:04.000000', 210, 2023101539, '<p>Hi i am almost there and here to give my best t', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `result_beta_hcg`
--
-- Creation: Dec 26, 2023 at 08:50 AM
-- Last update: Jan 22, 2024 at 09:18 PM
--

DROP TABLE IF EXISTS `result_beta_hcg`;
CREATE TABLE `result_beta_hcg` (
  `keyid` int(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `patientid` bigint(255) NOT NULL,
  `comments` varchar(11) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_beta_hcg`:
--

--
-- Dumping data for table `result_beta_hcg`
--

INSERT INTO `result_beta_hcg` (`keyid`, `value`, `billingid`, `unit`, `created_on`, `updated_on`, `patientid`, `comments`, `employeeid`) VALUES
(1, '54', 212, 'U/L', '2023-11-29 11:19:14.204454', '2023-11-30 11:20:29.292677', 2023101537, 'iividfi', NULL),
(2, '14', 265, '20', '2024-01-22 22:18:50.634147', NULL, 1703107987910, '<p>kejavjjj', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `result_cardiac_enzymes`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_cardiac_enzymes`;
CREATE TABLE `result_cardiac_enzymes` (
  `id` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `value` int(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `patientid` bigint(255) NOT NULL,
  `unit` varchar(10) NOT NULL DEFAULT 'mg/dl',
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_cardiac_enzymes`:
--

--
-- Dumping data for table `result_cardiac_enzymes`
--

INSERT INTO `result_cardiac_enzymes` (`id`, `parameter`, `billingid`, `value`, `created_on`, `updated_on`, `patientid`, `unit`, `employeeid`) VALUES
(1, 'creatinine kinase (CK)', 34, 550, '2023-09-04 12:47:24.511382', '2023-09-04 12:47:24.511382', 2023729, 'mg/dl', NULL),
(2, 'aspartate transaminase(AST)', 34, 525, '2023-09-04 12:47:24.511382', '2023-09-04 12:47:24.511382', 2023729, 'mg/dl', NULL),
(3, 'lactate dehydrogenase (LDH)', 34, 55, '2023-09-04 12:47:24.511382', '2023-09-04 12:47:24.511382', 2023729, 'mg/dl', NULL),
(4, 'creatinine kinase (CK)', 35, 444, '2023-09-04 12:48:02.865218', '2023-09-04 12:48:02.865218', 2023729, 'mg/dl', NULL),
(5, 'aspartate transaminase(AST)', 35, 444, '2023-09-04 12:48:02.865218', '2023-09-04 12:48:02.865218', 2023729, 'mg/dl', NULL),
(6, 'lactate dehydrogenase (LDH)', 35, 44, '2023-09-04 12:48:02.865218', '2023-09-04 12:48:02.865218', 2023729, 'mg/dl', NULL),
(7, 'creatinine kinase (CK)', 37, 444, '2023-09-04 12:49:12.974642', '2023-09-04 12:49:12.974642', 2023729, 'mg/dl', NULL),
(8, 'aspartate transaminase(AST)', 37, 44, '2023-09-04 12:49:12.974642', '2023-09-04 12:49:12.974642', 2023729, 'mg/dl', NULL),
(9, 'lactate dehydrogenase (LDH)', 37, 44, '2023-09-04 12:49:12.974642', '2023-09-04 12:49:12.974642', 2023729, 'mg/dl', NULL),
(10, 'creatinine kinase (CK)', 43, 54554, '2023-09-04 17:24:22.474909', '2023-09-04 17:24:22.474909', 202384, 'mg/dl', NULL),
(11, 'aspartate transaminase(AST)', 43, 444, '2023-09-04 17:24:22.474909', '2023-09-04 17:24:22.474909', 202384, 'mg/dl', NULL),
(12, 'lactate dehydrogenase (LDH)', 43, 444, '2023-09-04 17:24:22.474909', '2023-09-04 17:24:22.474909', 202384, 'mg/dl', NULL),
(13, 'creatinine kinase (CK)', 46, 444, '2023-09-04 17:24:54.450054', '2023-09-04 17:24:54.450054', 202384, 'mg/dl', NULL),
(14, 'aspartate transaminase(AST)', 46, 4, '2023-09-04 17:24:54.450054', '2023-09-04 17:24:54.450054', 202384, 'mg/dl', NULL),
(15, 'lactate dehydrogenase (LDH)', 46, 44, '2023-09-04 17:24:54.450054', '2023-09-04 17:24:54.450054', 202384, 'mg/dl', NULL),
(16, 'creatinine kinase (CK)', 48, 444, '2023-09-04 17:25:04.354330', '2023-09-04 17:25:04.354330', 202384, 'mg/dl', NULL),
(17, 'aspartate transaminase(AST)', 48, 444, '2023-09-04 17:25:04.354330', '2023-09-04 17:25:04.354330', 202384, 'mg/dl', NULL),
(18, 'lactate dehydrogenase (LDH)', 48, 444, '2023-09-04 17:25:04.354330', '2023-09-04 17:25:04.354330', 202384, 'mg/dl', NULL),
(19, 'creatinine kinase (CK)', 60, 555, '2023-09-05 11:34:13.012162', '2023-09-05 11:34:13.012162', 202385, 'mg/dl', NULL),
(20, 'aspartate transaminase(AST)', 60, 555, '2023-09-05 11:34:13.012162', '2023-09-05 11:34:13.012162', 202385, 'mg/dl', NULL),
(21, 'lactate dehydrogenase (LDH)', 60, 55, '2023-09-05 11:34:13.012162', '2023-09-05 11:34:13.012162', 202385, 'mg/dl', NULL),
(22, 'creatinine kinase (CK)', 74, 444, '2023-09-15 14:41:14.449552', '2023-09-15 14:41:14.449552', 2023854, 'mg/dl', NULL),
(23, 'aspartate transaminase(AST)', 74, 444, '2023-09-15 14:41:14.449552', '2023-09-15 14:41:14.449552', 2023854, 'mg/dl', NULL),
(24, 'lactate dehydrogenase (LDH)', 74, 444, '2023-09-15 14:41:14.449552', '2023-09-15 14:41:14.449552', 2023854, 'mg/dl', NULL),
(25, 'creatinine kinase (CK)', 84, 100, '2023-10-03 09:14:21.644768', '2023-10-03 09:14:21.644768', 202382111, 'mg/dl', NULL),
(26, 'aspartate transaminase(AST)', 84, 100, '2023-10-03 09:14:21.644768', '2023-10-03 09:14:21.644768', 202382111, 'mg/dl', NULL),
(27, 'lactate dehydrogenase (LDH)', 84, 100, '2023-10-03 09:14:21.644768', '2023-10-03 09:14:21.644768', 202382111, 'mg/dl', NULL),
(28, 'creatinine kinase (CK)', 102, 82, '2023-10-06 12:23:02.086329', '2023-10-06 12:23:02.086329', 202382112, 'mg/dl', NULL),
(29, 'aspartate transaminase(AST)', 102, 993, '2023-10-06 12:23:02.086329', '2023-10-06 12:23:02.086329', 202382112, 'mg/dl', NULL),
(30, 'lactate dehydrogenase (LDH)', 102, 939, '2023-10-06 12:23:02.086329', '2023-10-06 12:23:02.086329', 202382112, 'mg/dl', NULL),
(31, 'creatinine kinase (CK)', 87, 55, '2023-10-07 17:33:17.538269', '2023-10-07 17:33:17.538269', 202381910, 'mg/dl', NULL),
(32, 'aspartate transaminase(AST)', 87, 55, '2023-10-07 17:33:17.538269', '2023-10-07 17:33:17.538269', 202381910, 'mg/dl', NULL),
(33, 'lactate dehydrogenase (LDH)', 87, 55, '2023-10-07 17:33:17.538269', '2023-10-07 17:33:17.538269', 202381910, 'mg/dl', NULL),
(34, 'creatinine kinase (CK)', 107, 100, '2023-10-30 13:46:32.148551', '2023-10-30 13:46:32.148551', 20239723, 'mg/dl', NULL),
(35, 'aspartate transaminase(AST)', 107, 100, '2023-10-30 13:46:32.148551', '2023-10-30 13:46:32.148551', 20239723, 'mg/dl', NULL),
(36, 'lactate dehydrogenase (LDH)', 107, 100, '2023-10-30 13:46:32.148551', '2023-10-30 13:46:32.148551', 20239723, 'mg/dl', NULL),
(37, 'creatinine kinase (CK)', 198, 44, '2023-11-20 00:55:50.976580', '2023-11-21 02:52:45.000000', 2023101537, 'mg/dl', NULL),
(38, 'aspartate transaminase(AST)', 198, 44, '2023-11-20 00:55:50.976580', '2023-11-21 02:52:45.000000', 2023101537, 'mg/dl', NULL),
(39, 'lactate dehydrogenase (LDH)', 198, 2090, '2023-11-20 00:55:50.976580', '2023-11-21 02:52:45.000000', 2023101537, 'mg/dl', NULL),
(40, 'creatinine kinase (CK)', 196, 100, '2023-11-20 07:52:25.570670', '2023-12-07 10:01:09.000000', 202392724, 'mg/dl', 2),
(41, 'aspartate transaminase(AST)', 196, 200, '2023-11-20 07:52:25.570670', '2023-12-07 10:01:09.000000', 202392724, 'mg/dl', 2),
(42, 'lactate dehydrogenase (LDH)', 196, 20, '2023-11-20 07:52:25.570670', '2023-12-07 10:01:09.000000', 202392724, 'mg/dl', 2),
(43, 'creatinine kinase (CK)', 201, 200, '2023-11-21 01:47:02.016430', '2023-11-21 06:16:11.000000', 2023101537, 'mg/dl', NULL),
(44, 'aspartate transaminase(AST)', 201, 200, '2023-11-21 01:47:02.016430', '2023-11-21 06:16:12.000000', 2023101537, 'mg/dl', NULL),
(45, 'lactate dehydrogenase (LDH)', 201, 2090, '2023-11-21 01:47:02.016430', '2023-11-21 06:16:12.000000', 2023101537, 'mg/dl', NULL),
(46, 'lactate dehydrogenase (LDH)', 213, 300, '2023-12-02 03:34:35.637602', '2023-12-02 03:34:35.637602', 2023101539, 'U/L', NULL),
(47, 'creatinine kinase (CK)', 213, 300, '2023-12-02 03:34:35.637602', '2023-12-02 03:34:35.637602', 2023101539, 'U/L', NULL),
(48, 'aspartate transaminase(AST)', 213, 939, '2023-12-02 03:34:35.637602', '2023-12-02 03:34:35.637602', 2023101539, 'U/L', NULL),
(49, 'creatinine kinase (CK)', 215, 20, '2023-12-04 20:00:41.588959', '2023-12-04 20:00:41.588959', 2023101539, 'U/L', NULL),
(50, 'lactate dehydrogenase (LDH)', 215, 20, '2023-12-04 20:00:41.588959', '2023-12-04 20:00:41.588959', 2023101539, 'U/L', NULL),
(51, 'aspartate transaminase(AST)', 215, 20, '2023-12-04 20:00:41.588959', '2023-12-04 20:00:41.588959', 2023101539, 'U/L', NULL),
(52, 'creatinine kinase (CK)', 218, 5, '2023-12-09 04:26:38.276534', '2023-12-09 04:26:38.276534', 1702110827377, 'U/L', 2),
(53, 'lactate dehydrogenase (LDH)', 218, 55, '2023-12-09 04:26:38.276534', '2023-12-09 04:26:38.276534', 1702110827377, 'U/L', 2),
(54, 'aspartate transaminase(AST)', 218, 55, '2023-12-09 04:26:38.276534', '2023-12-09 04:26:38.276534', 1702110827377, 'U/L', 2);

-- --------------------------------------------------------

--
-- Table structure for table `result_comments`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_comments`;
CREATE TABLE `result_comments` (
  `keyid` int(255) NOT NULL,
  `testid` int(50) NOT NULL,
  `billingid` int(50) NOT NULL,
  `comments` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_comments`:
--

--
-- Dumping data for table `result_comments`
--

INSERT INTO `result_comments` (`keyid`, `testid`, `billingid`, `comments`) VALUES
(1, 4, 1, 'wefjjfu'),
(2, 11, 4, 'wkjjfkwfjw'),
(3, 11, 5, 'l3rl3rlle'),
(4, 5, 34, '5uuwffuysfuq'),
(5, 5, 35, '4lkdjjqs'),
(6, 11, 36, 'e;lkoiwfjqwfljkh'),
(7, 5, 37, '44'),
(8, 10, 37, 'wkejfuiqwfi'),
(9, 10, 45, 'jdgjkwgjhjhafwdhfn'),
(10, 5, 43, '44wfkwgjkwefgdqfhmqwsjh'),
(11, 5, 46, '4'),
(12, 5, 48, 'JKFJKWdGHQGDH'),
(13, 11, 58, 'korfelf;euif2ep9egf\n\nifioe;kluefio;elefiuguefk\n\n\nwfidgi3rgyuviefg[pwuirqik'),
(14, 5, 60, 'wkfjqjkfjhqjheh'),
(15, 4, 62, 'jfuiwquiududu'),
(16, 11, 62, '5qwkwfgh'),
(17, 15, 63, 'kgkwekgk'),
(18, 4, 67, 'hhh'),
(19, 4, 73, 'oef2efi2if2'),
(20, 5, 74, 'fkowkfjj'),
(21, 22, 78, '3rke3kfkoefko'),
(22, 4, 69, 'jfjfjqfhqfgw'),
(23, 4, 66, 'kefoqwoioqwo\nkwiirfiw\n\n\nuefuiqrui'),
(24, 4, 70, 'ieriowefiowfioefo\noweoffopofofofws\n;wkfwlfl2flqfkqe\n\nk2eqkgwf\'olq\'l'),
(25, 22, 79, 'ugoiegiefkwfj'),
(26, 5, 84, 'JFJWW\n\nFARHan is here to stay and have a good time so that things can be better for him'),
(27, 5, 102, '99292929'),
(28, 5, 87, '2k2fwdjhjh'),
(29, 11, 112, 'oego2eo1o'),
(30, 5, 107, 'jjjjj'),
(31, 10, 128, 'jddjj'),
(32, 5, 198, 'uuu'),
(33, 5, 196, '<p>jfjjfjdjfjq jwdjjfjqfjqwj</p>'),
(34, 11, 200, 'kjewfjkqwfjqsjghqch'),
(35, 10, 200, '<p>hddhqdjjdjType your text here</p>'),
(36, 5, 201, 'iwdfjififjjkcasjk'),
(37, 10, 202, 'here lies a lot of things to cater for our needs'),
(38, 22, 197, '<p>uiuyuiui</p>'),
(39, 22, 194, 'plwfkowfoiefjjiefifk'),
(40, 11, 203, 'jwdfjsjwjjfj'),
(41, 10, 203, 'klawdvsdklvwkl'),
(42, 22, 208, 'Normal result'),
(43, 22, 208, 'Normal result'),
(44, 15, 210, 'jvjwfjfjwfjwfj  jjwejfjf'),
(45, 12, 210, 'wdjkfjwfjjfj'),
(46, 15, 210, 'jvjwfjfjwfjwfj  jjwejfjf'),
(47, 32, 211, '<p>Normal FSH result presented</p><p>a</p><p>and my time time here is going to be long and productive&nbsp;</p><p>n</p><p>d</p>'),
(48, 10, 211, '<p>wkkwefk shrint my time here&nbsp;</p>'),
(49, 15, 212, 'wdfhfjj'),
(50, 31, 212, 'hefhfhhj'),
(51, 4, 205, '<p>eiiwefifikdkqwo</p>'),
(52, 5, 213, '<p>j3fj2j2j</p>'),
(53, 12, 215, '<p>ejfjwrjj</p>'),
(54, 5, 215, '<p>jwfjfjwf &nbsp;wfhjfjfjf &nbsp;wejfjj</p>'),
(55, 58, 216, '<p>jdwfjqeqjj</p>'),
(56, 56, 217, '<p>kefkdk</p>'),
(57, 5, 218, '<p>KLEFKLERKL</p>'),
(58, 11, 218, '<p>jwfkwefkqwdkqfk &nbsp;wfjqwjfqwkfkqw &nbsp;wjfqfkqfkqwkjf &nbsp;wjfjqwfkqwkqwk &nbsp;iwekwefkwfqkqwk</p>'),
(59, 12, 219, '<p>ifjwjj</p>'),
(60, 56, 219, '<p>dfnjkwkjqwdjkqw &nbsp;jwefjqwjw</p>'),
(61, 15, 283, '<p>jfjefjqjj</p>'),
(62, 10, 283, '<p>jwefjqefjjf &nbsp;hwgvwvjj</p>'),
(63, 11, 283, '<p>jefjwefjj</p>'),
(64, 12, 283, '<p>hhhh</p>');

-- --------------------------------------------------------

--
-- Table structure for table `result_esr`
--
-- Creation: Dec 26, 2023 at 08:50 AM
-- Last update: Jan 22, 2024 at 09:19 PM
--

DROP TABLE IF EXISTS `result_esr`;
CREATE TABLE `result_esr` (
  `keyid` int(100) NOT NULL,
  `value` int(40) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `billingid` int(100) NOT NULL,
  `patientid` bigint(100) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_esr`:
--

--
-- Dumping data for table `result_esr`
--

INSERT INTO `result_esr` (`keyid`, `value`, `comments`, `billingid`, `patientid`, `created_on`, `updated_on`, `employeeid`) VALUES
(1, 67, 'kwfkkj', 76, 2023854, '2023-09-18 10:00:01.204534', NULL, NULL),
(2, 100, '<p>jdjefj</p>', 210, 2023101539, '2023-11-27 07:12:44.855159', '2023-12-07 20:49:52.000000', NULL),
(3, 120, '<p>jjjj</p>', 265, 1703107987910, '2024-01-22 22:19:03.678543', NULL, NULL),
(4, 8484, '<p>9fioduiwefuiji</p>', 286, 1704453099655, '2024-01-22 22:19:13.114005', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `result_fasting_blood_sugar`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_fasting_blood_sugar`;
CREATE TABLE `result_fasting_blood_sugar` (
  `keyid` int(255) NOT NULL,
  `billingid` int(60) NOT NULL,
  `patientid` bigint(50) NOT NULL,
  `result` int(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `comments` varchar(50) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_fasting_blood_sugar`:
--

--
-- Dumping data for table `result_fasting_blood_sugar`
--

INSERT INTO `result_fasting_blood_sugar` (`keyid`, `billingid`, `patientid`, `result`, `unit`, `created_on`, `updated_on`, `comments`, `employeeid`) VALUES
(1, 213, 2023101539, 3838, 'mg/dl', '2023-12-04 01:18:07.405587', '2023-12-04 01:37:38.000000', '<p>dkkwfk</p>', NULL),
(2, 215, 2023101539, 20, 'mg/dl', '2023-12-04 20:00:29.390795', NULL, '<p>jdfjfjfjfj hfwej</p>', NULL),
(3, 218, 1702110827377, 20, 'mg/dl', '2023-12-09 04:26:27.335272', NULL, '<p>jsjkdksk</p>', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `result_function_full_blood_count`
--
-- Creation: Dec 05, 2023 at 04:47 AM
--

DROP TABLE IF EXISTS `result_function_full_blood_count`;
CREATE TABLE `result_function_full_blood_count` (
  `keyid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000' ON UPDATE current_timestamp(6),
  `value` int(20) NOT NULL,
  `patientid` bigint(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_function_full_blood_count`:
--

--
-- Dumping data for table `result_function_full_blood_count`
--

INSERT INTO `result_function_full_blood_count` (`keyid`, `parameter`, `billingid`, `unit`, `created_on`, `updated_on`, `value`, `patientid`) VALUES
(1, 'wbc', 78, '', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 555, 20238186),
(2, 'neutrophils', 78, 'g/dl', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 4544, 20238186),
(3, 'eosinophils', 78, '', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 444, 20238186),
(4, 'basophils', 78, '', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 44, 20238186),
(5, 'lymphocytes', 78, '', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 4454, 20238186),
(6, 'monocytes', 78, 'g/hj', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 45, 20238186),
(7, 'mch', 78, 'g/hj', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 55, 20238186),
(8, 'mcv', 78, 'g/hj', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 5, 20238186),
(9, 'mchc', 78, '%', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 555, 20238186),
(10, 'rdw-cv', 78, '%', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 555, 20238186),
(11, 'rdw-sd', 78, '%', '2023-09-18 10:16:43.079918', '2023-09-18 10:16:43.079918', 55, 20238186),
(12, 'wbc', 79, '', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 88, 202382111),
(13, 'neutrophils', 79, 'g/dl', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 899, 202382111),
(14, 'eosinophils', 79, '', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 88, 202382111),
(15, 'basophils', 79, '', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 99, 202382111),
(16, 'lymphocytes', 79, '', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 89, 202382111),
(17, 'monocytes', 79, 'g/hj', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 9, 202382111),
(18, 'mch', 79, 'g/hj', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 99, 202382111),
(19, 'mcv', 79, 'g/hj', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 999, 202382111),
(20, 'mchc', 79, '%', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 8999, 202382111),
(21, 'rdw-cv', 79, '%', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 658, 202382111),
(22, 'rdw-sd', 79, '%', '2023-09-21 19:30:35.664553', '2023-09-21 19:30:35.664553', 555, 202382111),
(23, 'wbc', 197, 'mg/dl', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.482639', 444, 2023101429),
(24, 'neutrophils', 197, 'mg/dlg/dl', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.487609', 4, 2023101429),
(25, 'eosinophils', 197, 'mg/dl', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.487129', 44, 2023101429),
(26, 'basophils', 197, 'mg/dl', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.482504', 4, 2023101429),
(27, 'lymphocytes', 197, 'mg/dl', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.487766', 44, 2023101429),
(28, 'monocytes', 197, 'mg/dlg/hj', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.487216', 4, 2023101429),
(29, 'mch', 197, 'mg/dlg/hj', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.486952', 4, 2023101429),
(30, 'mcv', 197, 'mg/dlg/hj', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.487908', 4, 2023101429),
(31, 'mchc', 197, 'mg/dl%', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.487351', 4, 2023101429),
(32, 'rdw-cv', 197, 'mg/dl%', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.487042', 44, 2023101429),
(33, 'rdw-sd', 197, 'mg/dl%', '2023-11-23 05:36:23.130140', '2023-12-01 23:24:01.564712', 4, 2023101429),
(34, 'wbc', 194, '', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 55, 202310127),
(35, 'neutrophils', 194, 'g/dl', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 55, 202310127),
(36, 'eosinophils', 194, '', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 55, 202310127),
(37, 'basophils', 194, '', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 5, 202310127),
(38, 'lymphocytes', 194, '', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 55, 202310127),
(39, 'monocytes', 194, 'g/hj', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 5, 202310127),
(40, 'mch', 194, 'g/hj', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 5, 202310127),
(41, 'mcv', 194, 'g/hj', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 5, 202310127),
(42, 'mchc', 194, '%', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 5, 202310127),
(43, 'rdw-cv', 194, '%', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 55, 202310127),
(44, 'rdw-sd', 194, '%', '2023-11-23 06:15:40.764996', '2023-11-23 06:15:40.764996', 55, 202310127),
(67, 'wbc', 208, 'mg/dl', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 399, 2023101538),
(68, 'neutrophils', 208, 'mg/dlg/dl', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 999, 2023101538),
(69, 'eosinophils', 208, 'mg/dl', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 9, 2023101538),
(70, 'basophils', 208, 'mg/dl', '2023-11-26 18:40:19.844261', '2023-11-29 10:23:27.153794', 98, 2023101538),
(71, 'lymphocytes', 208, 'mg/dl', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 939, 2023101538),
(72, 'monocytes', 208, 'mg/dlg/hj', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 939, 2023101538),
(73, 'mch', 208, 'mg/dlg/hj', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 939, 2023101538),
(74, 'mcv', 208, 'mg/dlg/hj', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 9, 2023101538),
(75, 'mchc', 208, 'mg/dl%', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 99, 2023101538),
(76, 'rdw-cv', 208, 'mg/dl%', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 99, 2023101538),
(77, 'rdw-sd', 208, 'mg/dl%', '2023-11-26 18:40:19.844261', '0000-00-00 00:00:00.000000', 99, 2023101538);

-- --------------------------------------------------------

--
-- Table structure for table `result_function_liver`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_function_liver`;
CREATE TABLE `result_function_liver` (
  `liverid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `value` int(255) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_function_liver`:
--

--
-- Dumping data for table `result_function_liver`
--

INSERT INTO `result_function_liver` (`liverid`, `parameter`, `billingid`, `unit`, `created_on`, `updated_on`, `value`, `patientid`, `employeeid`) VALUES
(1, 'albumin', 37, 'mg/dl', '2023-09-04 12:49:23.169744', NULL, 55, 2023729, NULL),
(2, 'total protein', 37, 'mg/dl', '2023-09-04 12:49:23.169744', NULL, 55, 2023729, NULL),
(3, 'alp', 37, 'mg/dl', '2023-09-04 12:49:23.169744', NULL, 555, 2023729, NULL),
(4, 'ast', 37, 'mg/dl', '2023-09-04 12:49:23.169744', NULL, 555, 2023729, NULL),
(5, 'alt', 37, 'mg/dl', '2023-09-04 12:49:23.169744', NULL, 5555, 2023729, NULL),
(6, 'bun', 37, 'mg/dl', '2023-09-04 12:49:23.169744', NULL, 555, 2023729, NULL),
(7, 'creatinine', 37, 'mg/dl', '2023-09-04 12:49:23.169744', NULL, 55, 2023729, NULL),
(8, 'albumin', 45, 'mg/dl', '2023-09-04 16:03:37.930716', NULL, 200, 202384, NULL),
(9, 'total protein', 45, 'mg/dl', '2023-09-04 16:03:37.930716', NULL, 49, 202384, NULL),
(10, 'alp', 45, 'mg/dl', '2023-09-04 16:03:37.930716', NULL, 9404, 202384, NULL),
(11, 'ast', 45, 'mg/dl', '2023-09-04 16:03:37.930716', NULL, 94994, 202384, NULL),
(12, 'alt', 45, 'mg/dl', '2023-09-04 16:03:37.930716', NULL, 9499, 202384, NULL),
(13, 'bun', 45, 'mg/dl', '2023-09-04 16:03:37.930716', NULL, 9393, 202384, NULL),
(14, 'creatinine', 45, 'mg/dl', '2023-09-04 16:03:37.930716', NULL, 9439, 202384, NULL),
(15, 'albumin', 128, 'mg/dl', '2023-11-06 16:41:14.229962', NULL, 30, 202310428, NULL),
(16, 'total protein', 128, 'mg/dl', '2023-11-06 16:41:14.229962', NULL, 40, 202310428, NULL),
(17, 'alp', 128, 'mg/dl', '2023-11-06 16:41:14.229962', NULL, 30, 202310428, NULL),
(18, 'ast', 128, 'mg/dl', '2023-11-06 16:41:14.229962', NULL, 30, 202310428, NULL),
(19, 'alt', 128, 'mg/dl', '2023-11-06 16:41:14.229962', NULL, 3, 202310428, NULL),
(20, 'bun', 128, 'mg/dl', '2023-11-06 16:41:14.229962', NULL, 3, 202310428, NULL),
(21, 'creatinine', 128, 'mg/dl', '2023-11-06 16:41:14.229962', NULL, 839, 202310428, NULL),
(22, 'albumin', 200, 'mg/dl', '2023-11-20 22:34:17.976598', NULL, 55, 2023101539, NULL),
(23, 'total protein', 200, 'mg/dl', '2023-11-20 22:34:17.976598', NULL, 55, 2023101539, NULL),
(24, 'alp', 200, 'mg/dl', '2023-11-20 22:34:17.976598', NULL, 55, 2023101539, NULL),
(25, 'ast', 200, 'mg/dl', '2023-11-20 22:34:17.976598', NULL, 55, 2023101539, NULL),
(26, 'alt', 200, 'mg/dl', '2023-11-20 22:34:17.976598', NULL, 55, 2023101539, NULL),
(27, 'bun', 200, 'mg/dl', '2023-11-20 22:34:17.976598', NULL, 555, 2023101539, NULL),
(28, 'creatinine', 200, 'mg/dl', '2023-11-20 22:34:17.976598', NULL, 555, 2023101539, NULL),
(29, 'albumin', 202, 'mg/dl', '2023-11-22 07:13:55.758794', NULL, 55, 2023101539, NULL),
(30, 'total protein', 202, 'mg/dl', '2023-11-22 07:13:55.758794', NULL, 555, 2023101539, NULL),
(31, 'alp', 202, 'mg/dl', '2023-11-22 07:13:55.758794', NULL, 55, 2023101539, NULL),
(32, 'ast', 202, 'mg/dl', '2023-11-22 07:13:55.758794', NULL, 555, 2023101539, NULL),
(33, 'alt', 202, 'mg/dl', '2023-11-22 07:13:55.758794', NULL, 555, 2023101539, NULL),
(34, 'bun', 202, 'mg/dl', '2023-11-22 07:13:55.758794', NULL, 555, 2023101539, NULL),
(35, 'creatinine', 202, 'mg/dl', '2023-11-22 07:13:55.758794', NULL, 555, 2023101539, NULL),
(38, 'alp', 201, 'mg/dl', '2023-11-20 22:34:17.976598', NULL, 55, 2023101539, NULL),
(39, 'ast', 201, 'mg/dl', '2023-11-20 22:34:17.976598', NULL, 55, 2023101539, NULL),
(40, 'albumin', 203, 'mg/dl', '2023-11-23 19:45:28.349298', NULL, 56, 2023101539, NULL),
(41, 'total protein', 203, 'mg/dl', '2023-11-23 19:45:28.349298', NULL, 66, 2023101539, NULL),
(42, 'alp', 203, 'mg/dl', '2023-11-23 19:45:28.349298', NULL, 98, 2023101539, NULL),
(43, 'ast', 203, 'mg/dl', '2023-11-23 19:45:28.349298', NULL, 56, 2023101539, NULL),
(44, 'alt', 203, 'mg/dl', '2023-11-23 19:45:28.349298', NULL, 345, 2023101539, NULL),
(45, 'bun', 203, 'mg/dl', '2023-11-23 19:45:28.349298', NULL, 87, 2023101539, NULL),
(46, 'creatinine', 203, 'mg/dl', '2023-11-23 19:45:28.349298', NULL, 69, 2023101539, NULL),
(47, 'albumin', 211, 'mg/dl', '2023-11-28 14:13:16.960553', NULL, 455, 2023101537, NULL),
(48, 'total protein', 211, 'mg/dl', '2023-11-28 14:13:16.960553', NULL, 55, 2023101537, NULL),
(49, 'alp', 211, 'mg/dl', '2023-11-28 14:13:16.960553', NULL, 55, 2023101537, NULL),
(50, 'ast', 211, 'mg/dl', '2023-11-28 14:13:16.960553', NULL, 55, 2023101537, NULL),
(51, 'alt', 211, 'mg/dl', '2023-11-28 14:13:16.960553', NULL, 55, 2023101537, NULL),
(52, 'bun', 211, 'mg/dl', '2023-11-28 14:13:16.960553', NULL, 555, 2023101537, NULL),
(53, 'creatinine', 211, 'mg/dl', '2023-11-28 14:13:16.960553', NULL, 555, 2023101537, NULL),
(54, 'creatinine', 283, 'mg/dl', '2024-01-06 21:15:13.106774', NULL, 200, 1702808069956, 2),
(55, 'alp', 283, 'mg/dl', '2024-01-06 21:15:13.106774', NULL, 200, 1702808069956, 2),
(56, 'albumin', 283, 'mg/dl', '2024-01-06 21:15:13.106774', NULL, 200, 1702808069956, 2),
(57, 'total protein', 283, 'mg/dl', '2024-01-06 21:15:13.106774', NULL, 200, 1702808069956, 2),
(58, 'ast', 283, 'mg/dl', '2024-01-06 21:15:13.106774', NULL, 200, 1702808069956, 2),
(59, 'alt', 283, 'mg/dl', '2024-01-06 21:15:13.106774', NULL, 200, 1702808069956, 2),
(60, 'bun', 283, 'mg/dl', '2024-01-06 21:15:13.106774', NULL, 200, 1702808069956, 2);

-- --------------------------------------------------------

--
-- Table structure for table `result_function_renal`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_function_renal`;
CREATE TABLE `result_function_renal` (
  `keyid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `value` int(20) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_function_renal`:
--

--
-- Dumping data for table `result_function_renal`
--

INSERT INTO `result_function_renal` (`keyid`, `parameter`, `billingid`, `unit`, `created_on`, `updated_on`, `value`, `patientid`, `employeeid`) VALUES
(1, 'BUN', 4, 'mg/dl', '2023-09-04 05:14:38.312845', '2023-09-04 05:14:38.312845', 445, 2023729, NULL),
(2, 'Creatinine', 4, 'mg/dl', '2023-09-04 05:14:38.312845', '2023-09-04 05:14:38.312845', 555, 2023729, NULL),
(3, 'potasium', 4, 'mg/dl', '2023-09-04 05:14:38.312845', '2023-09-04 05:14:38.312845', 555, 2023729, NULL),
(4, 'sodium', 4, 'mg/dl', '2023-09-04 05:14:38.312845', '2023-09-04 05:14:38.312845', 666, 2023729, NULL),
(5, 'chloride', 4, 'mg/dl', '2023-09-04 05:14:38.312845', '2023-09-04 05:14:38.312845', 111, 2023729, NULL),
(6, 'bicarbonate', 4, 'mg/dl', '2023-09-04 05:14:38.312845', '2023-09-04 05:14:38.312845', 7777, 2023729, NULL),
(7, 'albumin', 4, 'mg/dl', '2023-09-04 05:14:38.312845', '2023-09-04 05:14:38.312845', 888, 2023729, NULL),
(8, 'BUN', 5, 'mg/dl', '2023-09-04 05:21:55.590047', '2023-09-04 05:21:55.590047', 555, 2023729, NULL),
(9, 'Creatinine', 5, 'mg/dl', '2023-09-04 05:21:55.590047', '2023-09-04 05:21:55.590047', 55, 2023729, NULL),
(10, 'potasium', 5, 'mg/dl', '2023-09-04 05:21:55.590047', '2023-09-04 05:21:55.590047', 55, 2023729, NULL),
(11, 'sodium', 5, 'mg/dl', '2023-09-04 05:21:55.590047', '2023-09-04 05:21:55.590047', 5, 2023729, NULL),
(12, 'chloride', 5, 'mg/dl', '2023-09-04 05:21:55.590047', '2023-09-04 05:21:55.590047', 55, 2023729, NULL),
(13, 'bicarbonate', 5, 'mg/dl', '2023-09-04 05:21:55.590047', '2023-09-04 05:21:55.590047', 5, 2023729, NULL),
(14, 'albumin', 5, 'mg/dl', '2023-09-04 05:21:55.590047', '2023-09-04 05:21:55.590047', 555, 2023729, NULL),
(15, 'BUN', 36, 'mg/dl', '2023-09-04 12:48:28.371105', '2023-09-04 12:48:28.371105', 12, 2023729, NULL),
(16, 'Creatinine', 36, 'mg/dl', '2023-09-04 12:48:28.371105', '2023-09-04 12:48:28.371105', 121, 2023729, NULL),
(17, 'potasium', 36, 'mg/dl', '2023-09-04 12:48:28.371105', '2023-09-04 12:48:28.371105', 221, 2023729, NULL),
(18, 'sodium', 36, 'mg/dl', '2023-09-04 12:48:28.371105', '2023-09-04 12:48:28.371105', 11, 2023729, NULL),
(19, 'chloride', 36, 'mg/dl', '2023-09-04 12:48:28.371105', '2023-09-04 12:48:28.371105', 11, 2023729, NULL),
(20, 'bicarbonate', 36, 'mg/dl', '2023-09-04 12:48:28.371105', '2023-09-04 12:48:28.371105', 11, 2023729, NULL),
(21, 'albumin', 36, 'mg/dl', '2023-09-04 12:48:28.371105', '2023-09-04 12:48:28.371105', 11, 2023729, NULL),
(22, 'BUN', 58, 'mg/dl', '2023-09-05 11:26:39.651770', '2023-09-05 11:26:39.651770', 44, 2023854, NULL),
(23, 'Creatinine', 58, 'mg/dl', '2023-09-05 11:26:39.651770', '2023-09-05 11:26:39.651770', 44, 2023854, NULL),
(24, 'potasium', 58, 'mg/dl', '2023-09-05 11:26:39.651770', '2023-09-05 11:26:39.651770', 599, 2023854, NULL),
(25, 'sodium', 58, 'mg/dl', '2023-09-05 11:26:39.651770', '2023-09-05 11:26:39.651770', 568, 2023854, NULL),
(26, 'chloride', 58, 'mg/dl', '2023-09-05 11:26:39.651770', '2023-09-05 11:26:39.651770', 5589, 2023854, NULL),
(27, 'bicarbonate', 58, 'mg/dl', '2023-09-05 11:26:39.651770', '2023-09-05 11:26:39.651770', 566, 2023854, NULL),
(28, 'albumin', 58, 'mg/dl', '2023-09-05 11:26:39.651770', '2023-09-05 11:26:39.651770', 69, 2023854, NULL),
(29, 'BUN', 62, 'mg/dl', '2023-09-06 09:56:24.875914', '2023-09-06 09:56:24.875914', 555, 2023854, NULL),
(30, 'Creatinine', 62, 'mg/dl', '2023-09-06 09:56:24.875914', '2023-09-06 09:56:24.875914', 55, 2023854, NULL),
(31, 'potasium', 62, 'mg/dl', '2023-09-06 09:56:24.875914', '2023-09-06 09:56:24.875914', 55, 2023854, NULL),
(32, 'sodium', 62, 'mg/dl', '2023-09-06 09:56:24.875914', '2023-09-06 09:56:24.875914', 555, 2023854, NULL),
(33, 'chloride', 62, 'mg/dl', '2023-09-06 09:56:24.875914', '2023-09-06 09:56:24.875914', 55, 2023854, NULL),
(34, 'bicarbonate', 62, 'mg/dl', '2023-09-06 09:56:24.875914', '2023-09-06 09:56:24.875914', 55, 2023854, NULL),
(35, 'albumin', 62, 'mg/dl', '2023-09-06 09:56:24.875914', '2023-09-06 09:56:24.875914', 5, 2023854, NULL),
(36, 'BUN', 112, 'mg/dl', '2023-10-30 13:46:04.253241', '2023-10-30 13:46:04.253241', 88, 20239721, NULL),
(37, 'Creatinine', 112, 'mg/dl', '2023-10-30 13:46:04.253241', '2023-10-30 13:46:04.253241', 44, 20239721, NULL),
(38, 'potasium', 112, 'mg/dl', '2023-10-30 13:46:04.253241', '2023-10-30 13:46:04.253241', 444, 20239721, NULL),
(39, 'sodium', 112, 'mg/dl', '2023-10-30 13:46:04.253241', '2023-10-30 13:46:04.253241', 44, 20239721, NULL),
(40, 'chloride', 112, 'mg/dl', '2023-10-30 13:46:04.253241', '2023-10-30 13:46:04.253241', 444, 20239721, NULL),
(41, 'bicarbonate', 112, 'mg/dl', '2023-10-30 13:46:04.253241', '2023-10-30 13:46:04.253241', 444, 20239721, NULL),
(42, 'albumin', 112, 'mg/dl', '2023-10-30 13:46:04.253241', '2023-10-30 13:46:04.253241', 444, 20239721, NULL),
(43, 'ahDy', 112, 'UH', '2023-10-30 13:46:04.253241', '2023-10-30 13:46:04.253241', 44, 20239721, NULL),
(44, 'BUN', 200, 'mg/dl', '2023-11-20 22:33:03.608639', '2023-11-20 22:33:03.608639', 44, 2023101539, NULL),
(45, 'Creatinine', 200, 'mg/dl', '2023-11-20 22:33:03.608639', '2023-11-20 22:33:03.608639', 44, 2023101539, NULL),
(46, 'potasium', 200, 'mg/dl', '2023-11-20 22:33:03.608639', '2023-11-20 22:33:03.608639', 44, 2023101539, NULL),
(47, 'sodium', 200, 'mg/dl', '2023-11-20 22:33:03.608639', '2023-11-20 22:33:03.608639', 44, 2023101539, NULL),
(48, 'chloride', 200, 'mg/dl', '2023-11-20 22:33:03.608639', '2023-11-20 22:33:03.608639', 444, 2023101539, NULL),
(49, 'bicarbonate', 200, 'mg/dl', '2023-11-20 22:33:03.608639', '2023-11-20 22:33:03.608639', 44, 2023101539, NULL),
(50, 'albumin', 200, 'mg/dl', '2023-11-20 22:33:03.608639', '2023-11-20 22:33:03.608639', 44, 2023101539, NULL),
(51, 'ahDy', 200, 'UH', '2023-11-20 22:33:03.608639', '2023-11-20 22:33:03.608639', 44, 2023101539, NULL),
(52, 'BUN', 203, 'mg/dl', '2023-11-23 19:45:02.802759', '2023-11-23 19:45:02.802759', 969, 2023101539, NULL),
(53, 'Creatinine', 203, 'mg/dl', '2023-11-23 19:45:02.802759', '2023-11-23 19:45:02.802759', 969, 2023101539, NULL),
(54, 'potasium', 203, 'mg/dl', '2023-11-23 19:45:02.802759', '2023-11-23 19:45:02.802759', 969, 2023101539, NULL),
(55, 'sodium', 203, 'mg/dl', '2023-11-23 19:45:02.802759', '2023-11-23 19:45:02.802759', 969, 2023101539, NULL),
(56, 'chloride', 203, 'mg/dl', '2023-11-23 19:45:02.802759', '2023-11-23 19:45:02.802759', 969, 2023101539, NULL),
(57, 'bicarbonate', 203, 'mg/dl', '2023-11-23 19:45:02.802759', '2023-11-23 19:45:02.802759', 969, 2023101539, NULL),
(58, 'albumin', 203, 'mg/dl', '2023-11-23 19:45:02.802759', '2023-11-23 19:45:02.802759', 969, 2023101539, NULL),
(59, 'ahDy', 203, 'UH', '2023-11-23 19:45:02.802759', '2023-11-23 19:45:02.802759', 969, 2023101539, NULL),
(60, 'potasium', 218, 'mg/dl', '2023-12-09 08:17:32.218898', '2023-12-09 08:17:32.218898', 20, 1702110827377, 2),
(61, 'sodium', 218, 'mg/dl', '2023-12-09 08:17:32.218898', '2023-12-09 08:17:32.218898', 20, 1702110827377, 2),
(62, 'chloride', 218, 'mg/dl', '2023-12-09 08:17:32.218898', '2023-12-09 08:17:32.218898', 20, 1702110827377, 2),
(63, 'bicarbonate', 218, 'mg/dl', '2023-12-09 08:17:32.218898', '2023-12-09 08:17:32.218898', 20, 1702110827377, 2),
(64, 'albumin', 218, 'mg/dl', '2023-12-09 08:17:32.218898', '2023-12-09 08:17:32.218898', 202, 1702110827377, 2),
(65, 'BUN', 218, 'mg/dl', '2023-12-09 08:17:32.218898', '2023-12-09 08:17:32.218898', 202, 1702110827377, 2),
(66, 'potasium', 283, 'mg/dl', '2024-01-06 21:15:23.531677', '2024-01-06 21:15:23.531677', 200, 1702808069956, 2),
(67, 'sodium', 283, 'mg/dl', '2024-01-06 21:15:23.531677', '2024-01-06 21:15:23.531677', 200, 1702808069956, 2),
(68, 'chloride', 283, 'mg/dl', '2024-01-06 21:15:23.531677', '2024-01-06 21:15:23.531677', 300, 1702808069956, 2),
(69, 'bicarbonate', 283, 'mg/dl', '2024-01-06 21:15:23.531677', '2024-01-06 21:15:23.531677', 30, 1702808069956, 2),
(70, 'albumin', 283, 'mg/dl', '2024-01-06 21:15:23.531677', '2024-01-06 21:15:23.531677', 300, 1702808069956, 2),
(71, 'BUN', 283, 'mg/dl', '2024-01-06 21:15:23.531677', '2024-01-06 21:15:23.531677', 30, 1702808069956, 2);

-- --------------------------------------------------------

--
-- Table structure for table `result_haemoglobin_electrophoresis`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_haemoglobin_electrophoresis`;
CREATE TABLE `result_haemoglobin_electrophoresis` (
  `keyid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `value` int(255) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_haemoglobin_electrophoresis`:
--

-- --------------------------------------------------------

--
-- Table structure for table `result_helicobacter_pylori`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_helicobacter_pylori`;
CREATE TABLE `result_helicobacter_pylori` (
  `keyid` int(255) NOT NULL,
  `specimen` varchar(50) NOT NULL,
  `result` varchar(50) NOT NULL,
  `billingid` int(50) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `patientid` bigint(255) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_helicobacter_pylori`:
--

--
-- Dumping data for table `result_helicobacter_pylori`
--

INSERT INTO `result_helicobacter_pylori` (`keyid`, `specimen`, `result`, `billingid`, `created_on`, `updated_on`, `patientid`, `comments`, `employeeid`) VALUES
(1, 'blood', 'non reactive', 3, '2023-09-03 14:39:35.466056', NULL, 2023729, 'jefujwejwewek\n\n\nprobably', NULL),
(2, 'blood', 'non reactive', 2, '2023-09-03 14:43:09.644603', NULL, 2023729, 'fljkkfkwfhfefujqehfjh\njejejtjej\nprince is here to stay\ngoing to time with in close database and probably things', NULL),
(3, 'blood', 'non reactive', 52, '2023-09-05 05:43:59.951468', NULL, 202384, 'wekgjkgjk', NULL),
(4, 'blood', 'non reactive', 59, '2023-09-05 11:27:15.568153', NULL, 202385, 'ekofilwgwhufykfpoo\n\niowgiuigfuwefoweuiui\n\n\nefiwgoegufiwdfui', NULL),
(5, 'blood', 'non reactive', 78, '2023-09-18 10:17:02.523009', NULL, 20238186, 'hello world my dear', NULL),
(6, 'blood', 'non reactive', 204, '2023-11-26 11:40:58.483868', NULL, 2023101537, 'Negative', NULL),
(7, 'blood', 'non reactive', 204, '2023-11-26 11:40:58.550406', NULL, 2023101537, 'Negative', NULL),
(8, 'blood', 'non reactive', 204, '2023-11-26 11:40:58.551059', NULL, 2023101537, 'Negative', NULL),
(9, 'blood', 'non reactive', 204, '2023-11-26 11:40:58.551647', NULL, 2023101537, 'Negative', NULL),
(10, 'blood', 'non reactive', 204, '2023-11-26 11:40:58.551953', NULL, 2023101537, 'Negative', NULL),
(11, 'blood', 'non reactive', 204, '2023-11-26 11:40:58.552318', NULL, 2023101537, 'Negative', NULL),
(12, 'blood', 'non reactive', 207, '2023-11-26 15:12:33.449260', NULL, 2023101538, 'Blood comments are here to stay and provide feedback and stay loop', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `result_lipid_profile`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_lipid_profile`;
CREATE TABLE `result_lipid_profile` (
  `keyid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `value` int(255) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='betathalassemia';

--
-- RELATIONSHIPS FOR TABLE `result_lipid_profile`:
--

--
-- Dumping data for table `result_lipid_profile`
--

INSERT INTO `result_lipid_profile` (`keyid`, `parameter`, `billingid`, `unit`, `created_on`, `updated_on`, `value`, `patientid`, `employeeid`) VALUES
(1, 'CHOLESTEROL', 210, 'mg/dl', '2023-11-27 07:12:31.429170', NULL, 6688, 2023101539, NULL),
(2, 'TRIGLYCERIDES', 210, 'mg/dl', '2023-11-27 07:12:31.429170', NULL, 888, 2023101539, NULL),
(3, 'HDL', 210, 'mg/dl', '2023-11-27 07:12:31.429170', NULL, 84848, 2023101539, NULL),
(4, 'LDL', 210, 'mg/dl', '2023-11-27 07:12:31.429170', NULL, 66, 2023101539, NULL),
(5, 'TOTAL CHOLESEROL', 210, 'mg/dl', '2023-11-27 07:12:31.429170', NULL, 66, 2023101539, NULL),
(6, 'TG/HDL', 210, 'mg/dl', '2023-11-27 07:12:31.429170', NULL, 666, 2023101539, NULL),
(7, 'CHOLESTEROL', 215, 'mg/dl', '2023-12-04 20:00:18.900263', '2023-12-05 08:52:24.000000', 200, 2023101539, NULL),
(8, 'TRIGLYCERIDES', 215, 'mg/dl', '2023-12-04 20:00:18.900263', '2023-12-05 08:52:24.000000', 200, 2023101539, NULL),
(9, 'HDL', 215, 'mg/dl', '2023-12-04 20:00:18.900263', '2023-12-05 08:52:24.000000', 200, 2023101539, NULL),
(10, 'LDL', 215, 'mg/dl', '2023-12-04 20:00:18.900263', '2023-12-05 08:52:24.000000', 200, 2023101539, NULL),
(11, 'TOTAL CHOLESEROL', 215, 'mg/dl', '2023-12-04 20:00:18.900263', '2023-12-05 08:52:24.000000', 200, 2023101539, NULL),
(12, 'TG/HDL', 215, 'mg/dl', '2023-12-04 20:00:18.900263', '2023-12-05 08:52:24.000000', 200, 2023101539, NULL),
(13, 'CHOLESTEROL', 219, 'mg/dl', '2023-12-12 09:22:59.003144', '2024-01-05 12:10:23.000000', 40, 1702200924561, 2),
(14, 'TRIGLYCERIDES', 219, 'mg/dl', '2023-12-12 09:22:59.003144', '2024-01-05 12:10:23.000000', 40, 1702200924561, 2),
(15, 'HDL', 219, 'mg/dl', '2023-12-12 09:22:59.003144', '2024-01-05 12:10:23.000000', 40, 1702200924561, 2),
(16, 'LDL', 219, 'mg/dl', '2023-12-12 09:22:59.003144', '2024-01-05 12:10:23.000000', 40, 1702200924561, 2),
(17, 'TOTAL CHOLESEROL', 219, 'mg/dl', '2023-12-12 09:22:59.003144', '2024-01-05 12:10:23.000000', 40, 1702200924561, 2),
(18, 'TG/HDL', 219, 'mg/dl', '2023-12-12 09:22:59.003144', '2024-01-05 12:10:23.000000', 40, 1702200924561, 2),
(19, 'CHOLESTEROL', 283, 'mg/dl', '2024-01-06 21:34:16.154836', NULL, 200, 1702808069956, 2),
(20, 'TRIGLYCERIDES', 283, 'mg/dl', '2024-01-06 21:34:16.154836', NULL, 79, 1702808069956, 2),
(21, 'HDL', 283, 'mg/dl', '2024-01-06 21:34:16.154836', NULL, 80, 1702808069956, 2),
(22, 'LDL', 283, 'mg/dl', '2024-01-06 21:34:16.154836', NULL, 89, 1702808069956, 2),
(23, 'TOTAL CHOLESEROL', 283, 'mg/dl', '2024-01-06 21:34:16.154836', NULL, 7777, 1702808069956, 2),
(24, 'TG/HDL', 283, 'mg/dl', '2024-01-06 21:34:16.154836', NULL, 7777, 1702808069956, 2);

-- --------------------------------------------------------

--
-- Table structure for table `result_pregnancy_test`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_pregnancy_test`;
CREATE TABLE `result_pregnancy_test` (
  `keyid` int(255) NOT NULL,
  `method` varchar(50) NOT NULL,
  `value` varchar(10) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `comments` varchar(255) DEFAULT NULL,
  `patientid` bigint(255) NOT NULL,
  `billingid` int(60) NOT NULL,
  `testid` int(50) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_pregnancy_test`:
--

--
-- Dumping data for table `result_pregnancy_test`
--

INSERT INTO `result_pregnancy_test` (`keyid`, `method`, `value`, `created_on`, `updated_on`, `comments`, `patientid`, `billingid`, `testid`, `employeeid`) VALUES
(1, 'Blood', 'negative', '2023-11-28 14:10:44.100955', '2023-11-28 14:10:44.100955', '<p>wdjjjfjfjfjqjfkkdk</p>', 2023101537, 211, 14, NULL),
(2, 'Urine', 'positive', '2023-12-07 10:01:37.849433', '2023-12-07 10:01:37.849433', '<p>hhhhhhhhhh</p>', 2023854, 209, 14, 2);

-- --------------------------------------------------------

--
-- Table structure for table `result_random_blood_sugar`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_random_blood_sugar`;
CREATE TABLE `result_random_blood_sugar` (
  `keyid` int(255) NOT NULL,
  `billingid` int(60) NOT NULL,
  `patientid` bigint(50) NOT NULL,
  `result` int(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `comments` varchar(50) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_random_blood_sugar`:
--

--
-- Dumping data for table `result_random_blood_sugar`
--

INSERT INTO `result_random_blood_sugar` (`keyid`, `billingid`, `patientid`, `result`, `unit`, `created_on`, `updated_on`, `comments`, `employeeid`) VALUES
(2, 214, 2023101539, 400, 'mg/dl', '2023-12-04 01:35:55.728503', '2023-12-04 01:37:44.000000', '<p>kfiwefiq</p>', NULL),
(3, 213, 2023101539, 40, 'mg/dl', '2023-12-04 01:36:19.911581', '2023-12-07 12:03:33.000000', '<p>nkkwefk</p>', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `result_thyroid_functional_test`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_thyroid_functional_test`;
CREATE TABLE `result_thyroid_functional_test` (
  `setupid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `billingid` int(255) NOT NULL,
  `value` int(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL,
  `patientid` bigint(255) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_thyroid_functional_test`:
--

--
-- Dumping data for table `result_thyroid_functional_test`
--

INSERT INTO `result_thyroid_functional_test` (`setupid`, `parameter`, `billingid`, `value`, `created_on`, `updated_on`, `patientid`, `unit`, `employeeid`) VALUES
(7, 'TSH', 210, 88, '2023-11-27 07:13:18.590065', NULL, 2023101539, 'pmol/L', NULL),
(8, 'T4', 210, 88, '2023-11-27 07:13:18.590065', NULL, 2023101539, 'pmol/L', NULL),
(9, 'T3', 210, 88, '2023-11-27 07:13:18.590065', NULL, 2023101539, 'pmol/L', NULL),
(10, 'TSH', 212, 737, '2023-11-29 09:29:13.261424', NULL, 2023101537, 'pmol/L', NULL),
(11, 'T4', 212, 77777, '2023-11-29 09:29:13.261424', NULL, 2023101537, 'pmol/L', NULL),
(12, 'T3', 212, 777, '2023-11-29 09:29:13.261424', NULL, 2023101537, 'pmol/L', NULL),
(13, 'TSH', 283, 200, '2024-01-06 21:14:43.555606', NULL, 1702808069956, 'pmol/L', 2),
(14, 'T4', 283, 300, '2024-01-06 21:14:43.555606', NULL, 1702808069956, 'pmol/L', 2),
(15, 'T3', 283, 300, '2024-01-06 21:14:43.555606', NULL, 1702808069956, 'pmol/L', 2);

-- --------------------------------------------------------

--
-- Table structure for table `result_widal`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `result_widal`;
CREATE TABLE `result_widal` (
  `KEYID` int(255) NOT NULL,
  `TYPHIO` varchar(10) NOT NULL,
  `TYPHIH` varchar(10) NOT NULL,
  `PARATYPHIAH` varchar(10) DEFAULT NULL,
  `PARATYPHIBH` varchar(10) DEFAULT NULL,
  `COMMENTS` varchar(255) NOT NULL,
  `CREATED_ON` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `UPDATED_ON` datetime(6) DEFAULT NULL,
  `BILLINGID` int(255) NOT NULL,
  `PATIENTID` bigint(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `result_widal`:
--

--
-- Dumping data for table `result_widal`
--

INSERT INTO `result_widal` (`KEYID`, `TYPHIO`, `TYPHIH`, `PARATYPHIAH`, `PARATYPHIBH`, `COMMENTS`, `CREATED_ON`, `UPDATED_ON`, `BILLINGID`, `PATIENTID`, `employeeid`) VALUES
(1, '1/20', '1/80', '1/80', '1/20', 'gkrgllwel', '2023-09-04 05:22:06.357165', NULL, 5, 2023729, NULL),
(2, '1/20', '1/20', '1/80', '1/80', 'wdfowfgiwufgouidqvuedgu2eoufgi', '2023-09-05 11:26:58.154081', NULL, 58, 2023854, NULL),
(3, '1/20', '1/80', '1/20', '1/20', 'eiiuwfuweu', '2023-09-21 09:47:49.660265', NULL, 79, 202382111, NULL),
(4, '1/80', '1/80', '1/160', '1/80', 'efuie2ui', '2023-09-21 12:52:36.129191', NULL, 81, 2023854, NULL),
(5, '1/20', '1/160', '1/80', '1/80', 'jqjjwdjfjjcjqsj', '2023-10-10 19:24:40.233861', NULL, 108, 20239723, NULL),
(6, '1/20', '1/20', '1/80', '1/80', 'efowowefoo', '2023-10-30 13:45:17.066345', NULL, 110, 20239723, NULL),
(7, '1/20', '1/20', '', '', 'reactive', '2023-10-31 00:37:36.950871', NULL, 122, 20238155, NULL),
(8, '1/20', '1/160', '1/80', '1/80', 'Non reactive', '2023-11-26 11:43:52.996562', '2023-11-26 11:43:55.000000', 194, 202310127, NULL),
(9, '1/20', '1/160', '1/80', '1/80', 'kfiefi2i', '2023-11-27 05:52:36.062138', NULL, 197, 2023101429, NULL),
(10, '1/20', '1/80', '1/20', '1/20', 'kifeii', '2023-11-28 14:11:28.884080', NULL, 211, 2023101537, NULL),
(11, '1/20', '1/20', '', '', '<p>j2ejwej</p>', '2023-12-07 12:30:35.342160', NULL, 213, 2023101539, NULL),
(12, '1/20', '1/80', '1/80', '1/80', '<p>hfwefjwfjjwfjqwj</p>', '2024-01-06 21:14:58.107130', NULL, 283, 1702808069956, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `employeeid` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_created` date NOT NULL DEFAULT current_timestamp(),
  `TIME` time(6) NOT NULL DEFAULT current_timestamp(),
  `refresh_token` varchar(255) DEFAULT NULL,
  `activation` tinyint(1) NOT NULL DEFAULT 0,
  `email` varchar(200) NOT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '\'{}\'',
  `updated_on` datetime(6) DEFAULT NULL,
  `emailAuthenticated` varchar(6) NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `roles`:
--

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`employeeid`, `username`, `role`, `password`, `date_created`, `TIME`, `refresh_token`, `activation`, `email`, `permissions`, `updated_on`, `emailAuthenticated`) VALUES
(1, 'Nyaaba Asana Awineyila', 'phelobotomist', '$2b$10$F.klTJZBHH6eBf0PsjZwA.mFY8ciMrYSKnoJeEZaQsceh6/G7YWde', '2023-09-03', '08:54:05.000000', NULL, 1, 'mildred@gmail.com', '{\"deletev\":false,\"role\":\"phelobotomist\",\"registerv\":false,\"pageAccess\":{\"registration\":false,\"inventory\":false,\"activation\":false,\"suppliers\":false,\"operations\":false,\"approvals\":false,\"settings\":false,\"payments\":false,\"billing\":false,\"phelobotomy\":true,\"samples\":false,\"organization\":false,\"clinician\":false,\"appointment\":false}}', '0000-00-00 00:00:00.000000', 'true'),
(2, 'Tiifu Hamza Boronson', 'admin', '$2b$10$VQAUNbjKwGiv99NZa.iQpeK7M6FKXrkVwmuyTONpaRTSmJocyAMUO', '2023-09-06', '10:24:18.000000', NULL, 1, 'tiifu@gmail.com', '{}', '0000-00-00 00:00:00.000000', 'true'),
(3, 'tiifu hamza', 'admin', '$2b$10$M3oXcg3BPJUPK6uFxq0cvuVffwlp/yjjwEhZ7bUtWq6Dl9qgHXgpm', '2023-09-10', '14:29:06.000000', NULL, 1, 'hamzatiifu45@gmail.com', '{\"registerClient\":true,\"deleteClient\":true,\"editClient\":true,\"printResult\":true,\"activateClient\":true,\"viewClient\":true,\"enterResult\":true,\"viewResult\":true,\"deleteResult\":true,\"pageAccess\":{\"registration\":true,\"inventory\":true,\"activation\":true,\"suppliers\":true,\"operations\":true,\"approvals\":true,\"settings\":true,\"payments\":true,\"billing\":true,\"phelobotomy\":true,\"samples\":true,\"organization\":true,\"clinician\":true,\"appointment\":true}}', '0000-00-00 00:00:00.000000', 'true'),
(26, 'shefik tiifu', 'customer service representative', '$2b$10$sXTNsHAATjbcER/KJGgAnOn1xRfhUWO/aUBhS5GSlhtIOv6J3VCn6', '2023-10-28', '03:46:52.000000', NULL, 1, 'shefiktiifu@yahoo.com', '{\"registerClient\":true,\"deleteClient\":false,\"editClient\":true,\"printResult\":false,\"activateClient\":true,\"viewClient\":true,\"enterResult\":false,\"viewResult\":false,\"deleteResult\":false,\"pageAccess\":{\"registration\":true,\"inventory\":false,\"activation\":true,\"suppliers\":false,\"operations\":false,\"approvals\":false,\"settings\":false,\"payments\":false,\"billing\":false,\"phelobotomy\":false,\"samples\":false,\"organization\":true,\"clinician\":true,\"appointment\":false}}', '2023-10-28 03:46:52.628656', 'true'),
(27, 'abu hajia sheheda', 'scientist', '$2b$10$AwtvrsW7AmD.7f1mui7yne.LrIepeCLI1JmKCxoR/kLGssamtnsWW', '2023-10-28', '04:06:27.000000', NULL, 1, 'hajiasheheda@yahoo.com', '{}', '2023-10-28 04:06:27.665669', 'true'),
(28, 'tiifu hak', 'sonographer', '$2b$10$nsd0KxWtMDafszAKigxh1OV1hK8kKbwxXg5n3t2GuN3nYjlIrWfdu', '2023-10-28', '04:53:39.000000', NULL, 1, 'haktiifu@yahoo.com', '{}', '2023-10-28 04:53:39.218409', 'true'),
(29, 'Mr razak abdulai', 'clinician', '$2b$10$tO2jwWn.ZHEHbvZ8GLZdRe06kmHAGIYfuk1S6TtfTXQ0ibfaoMrOi', '2023-12-12', '10:05:41.000000', NULL, 0, 'zak@gmail.com', '{}', '2023-12-12 10:05:41.184758', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `samplestatus`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `samplestatus`;
CREATE TABLE `samplestatus` (
  `keyid` int(100) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `rejectionmessage` varchar(255) DEFAULT NULL,
  `testid` int(50) NOT NULL,
  `billingid` int(50) NOT NULL,
  `approvalstatus` tinyint(1) NOT NULL DEFAULT 0,
  `sampleMessage` varchar(50) DEFAULT NULL,
  `phelobotomist` int(10) NOT NULL,
  `ascensionid` int(50) NOT NULL,
  `redraw` tinyint(1) DEFAULT NULL,
  `redrawOrderDate` datetime(6) DEFAULT NULL,
  `samplevalidatedon` datetime(6) DEFAULT NULL,
  `validatedby` int(10) DEFAULT NULL,
  `disputedby` int(20) DEFAULT NULL,
  `disputedon` datetime(6) DEFAULT NULL,
  `disputereason` varchar(200) DEFAULT NULL,
  `resolution` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='this keep a log of samples accepted or declined';

--
-- RELATIONSHIPS FOR TABLE `samplestatus`:
--

--
-- Dumping data for table `samplestatus`
--

INSERT INTO `samplestatus` (`keyid`, `date`, `rejectionmessage`, `testid`, `billingid`, `approvalstatus`, `sampleMessage`, `phelobotomist`, `ascensionid`, `redraw`, `redrawOrderDate`, `samplevalidatedon`, `validatedby`, `disputedby`, `disputedon`, `disputereason`, `resolution`) VALUES
(13, '2023-11-17 11:06:28.363198', NULL, 19, 172, 0, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, '2023-11-17 11:08:18.291886', NULL, 19, 173, 0, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, '2023-11-17 11:12:36.699412', NULL, 19, 174, 0, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, '2023-11-17 11:13:14.210406', NULL, 19, 175, 0, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(117, '2023-12-12 09:21:52.387553', NULL, 1, 219, 1, '', 2, 324, NULL, NULL, '2023-12-12 17:22:25.078000', 1, NULL, NULL, NULL, NULL),
(118, '2023-12-12 09:21:52.390104', NULL, 12, 219, 1, '', 2, 326, NULL, NULL, '2023-12-12 17:22:25.717000', 1, NULL, NULL, NULL, NULL),
(119, '2023-12-12 09:21:52.390391', NULL, 56, 219, 1, '', 2, 325, NULL, NULL, '2023-12-12 17:22:26.494000', 1, NULL, NULL, NULL, NULL),
(164, '2023-12-16 02:53:17.480226', NULL, 1, 233, 0, NULL, 1, 371, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(165, '2023-12-16 02:53:17.483502', NULL, 11, 233, 0, NULL, 1, 372, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(166, '2023-12-16 02:53:17.483744', NULL, 10, 233, 0, NULL, 1, 373, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(168, '2023-12-16 04:43:40.035845', NULL, 10, 235, 0, '', 1, 375, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(207, '2023-12-17 02:15:11.982545', NULL, 11, 258, 0, NULL, 1, 414, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(208, '2023-12-17 02:15:11.986363', NULL, 10, 258, 0, NULL, 1, 415, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(209, '2023-12-17 02:15:11.986519', NULL, 2, 258, 0, NULL, 1, 416, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(210, '2023-12-17 02:15:11.986755', NULL, 34, 258, 0, NULL, 1, 417, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(211, '2023-12-17 02:15:11.987011', NULL, 12, 258, 0, NULL, 1, 418, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(218, '2023-12-17 02:34:28.673560', NULL, 1, 263, 0, NULL, 1, 425, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(219, '2023-12-21 00:47:34.385135', NULL, 19, 264, 1, '', 2, 426, NULL, NULL, '2024-01-06 20:14:13.570000', 1, NULL, NULL, NULL, NULL),
(220, '2023-12-21 00:50:18.338930', NULL, 19, 265, 1, '', 2, 427, NULL, NULL, '2024-01-06 20:13:51.376000', 1, NULL, NULL, NULL, NULL),
(221, '2023-12-21 00:50:18.341109', NULL, 16, 265, 1, '', 2, 428, NULL, NULL, '2024-01-06 20:13:50.709000', 1, NULL, NULL, NULL, NULL),
(222, '2023-12-21 00:50:18.340997', NULL, 1, 265, 1, '', 2, 429, NULL, NULL, '2024-01-06 20:13:49.830000', 1, NULL, NULL, NULL, NULL),
(324, '2024-01-06 20:04:54.796069', NULL, 6, 283, 1, '', 2, 531, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(325, '2024-01-06 20:04:54.796236', NULL, 3, 283, 1, '', 2, 532, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(326, '2024-01-06 20:04:54.801039', NULL, 13, 283, 1, '', 2, 536, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(327, '2024-01-06 20:04:54.800916', NULL, 12, 283, 1, NULL, 2, 535, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(328, '2024-01-06 20:04:54.800605', NULL, 10, 283, 1, NULL, 2, 533, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(329, '2024-01-06 20:04:54.801169', NULL, 15, 283, 1, NULL, 2, 537, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(330, '2024-01-06 20:04:54.800740', NULL, 11, 283, 1, NULL, 2, 534, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(331, '2024-01-09 17:13:41.520494', NULL, 8, 284, 1, NULL, 2, 538, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(332, '2024-01-09 17:13:41.520685', NULL, 5, 284, 1, NULL, 2, 539, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(333, '2024-01-09 17:13:41.529120', NULL, 54, 284, 1, NULL, 2, 540, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(334, '2024-01-09 17:13:41.529332', NULL, 20, 284, 1, NULL, 2, 541, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(335, '2024-01-09 17:13:41.529719', NULL, 51, 284, 1, NULL, 2, 543, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(336, '2024-01-09 17:13:41.529525', NULL, 31, 284, 1, NULL, 2, 542, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(337, '2024-01-09 17:20:12.974598', NULL, 1, 285, 1, NULL, 2, 544, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(338, '2024-01-09 17:20:12.977719', NULL, 4, 285, 1, NULL, 2, 546, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(339, '2024-01-09 17:20:12.977457', NULL, 11, 285, 1, NULL, 2, 545, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(340, '2024-01-18 16:38:57.748075', NULL, 19, 286, 1, '', 2, 547, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(341, '2024-01-18 16:38:57.748273', NULL, 1, 286, 1, '', 2, 548, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sampletype`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `sampletype`;
CREATE TABLE `sampletype` (
  `id` int(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `addedon` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `sampletype`:
--

--
-- Dumping data for table `sampletype`
--

INSERT INTO `sampletype` (`id`, `name`, `addedon`) VALUES
(1, 'urine', '2023-09-03'),
(2, 'blood', '2023-09-03'),
(3, 'serum', '2023-09-03'),
(4, 'stool', '2023-09-03'),
(5, 'cerebrospinal fluid', '2023-09-22');

-- --------------------------------------------------------

--
-- Table structure for table `samplingtest`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `samplingtest`;
CREATE TABLE `samplingtest` (
  `TestKey` int(255) NOT NULL,
  `TestId` int(50) NOT NULL,
  `Billingid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `samplingtest`:
--

-- --------------------------------------------------------

--
-- Table structure for table `scanreport`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `scanreport`;
CREATE TABLE `scanreport` (
  `id` int(255) NOT NULL,
  `patientid` bigint(50) NOT NULL,
  `billingid` int(50) NOT NULL,
  `testid` int(10) NOT NULL,
  `scan` varchar(100) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `content` longtext NOT NULL,
  `sonographer` varchar(255) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `scanreport`:
--

--
-- Dumping data for table `scanreport`
--

INSERT INTO `scanreport` (`id`, `patientid`, `billingid`, `testid`, `scan`, `created_on`, `updated_on`, `content`, `sonographer`, `employeeid`) VALUES
(0, 2023101434, 144, 54, 'abdominal pelvic scan', '2023-11-19 08:55:43.358962', '2023-12-02 13:20:53.162599', '', 'Tiifu Hamza Kojo Boronson', NULL),
(38, 20238187, 96, 50, 'abdominal ultrasound scan', '2023-10-05 10:21:10.601925', '2023-10-05 18:23:03.799463', '<p>KWIIDI	</p><p>02/09/2022</p><p>​Director</p><p>Client Company name</p><p>Box KN 472 Kaneshie</p><p>Accra, Ghana</p><p><br></p><p><br></p><p>Dear Sir/Madam,</p><p class=\"ql-align-center\"><strong><u>MTR11 PROPOSAL CONSIDERATION</u></strong></p><p>Thank you for meeting with us to discuss your company’s software project requirements. Attached is our detailed software proposal for your consideration and approval.</p><p>At Ethnicsoft solutions, we know that creating client-oriented software takes a mixture of technical excellence and clear communication.</p><p>Our firm hires only the very best to ensure you receive both. We know that every client is unique, so we strive to deliver an individual, innovative, and affordable proposal every time, following through with an outstanding delivery that is both on time and within budget.</p><p>We have more than 12 years of development in this area and our previous clients include:</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bestcare Clinic at Target</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prestige Hospital at NMTC Campus</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Abdel Kadiri clinic at kukuo last stop</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Newlife hospital at Kukuo and other facilities and pharmacies to mention.</p><p>Please let us know if you would like to get in touch with these existing clients to hear their testimonials about Ethnicsoft solutions. You can learn more from our website at <a href=\"https://www.ethnicsoft.com/\" rel=\"noopener noreferrer\" target=\"_blank\">https://www.ethnicsoft.com</a> and our Facebook page https://wwwfacebook.com/ethnicsoft, where you can view our portfolio of previous work and our highly-trained staff.</p><p>We also pride ourselves on our after-sales client-care including our guarantees, staff training, and onsite and offsite support.</p><p>Finally, we realize that you are very busy and wanted to thank you in advance for your time spent reviewing our business proposal.</p><p><br></p><p>Yours Faithfully</p><p><img src=\"//:0\"></p><p>_________________________</p><p>ILHAM AMISSAH (Managing Director)</p><p>(Ethnicsoft Solutions)</p>', 'Tiifu Hamza Kojo Boronson', NULL),
(39, 202382111, 95, 50, 'abdominal ultrasound scan', '2023-10-05 10:21:19.781697', '2023-10-05 18:22:51.948184', '<p>KJIW	</p><p>02/09/2022</p><p>​Director</p><p>Client Company name</p><p>Box KN 472 Kaneshie</p><p>Accra, Ghana</p><p><br></p><p><br></p><p>Dear Sir/Madam,</p><p class=\"ql-align-center\"><strong><u>MTR11 PROPOSAL CONSIDERATION</u></strong></p><p>Thank you for meeting with us to discuss your company’s software project requirements. Attached is our detailed software proposal for your consideration and approval.</p><p>At Ethnicsoft solutions, we know that creating client-oriented software takes a mixture of technical excellence and clear communication.</p><p>Our firm hires only the very best to ensure you receive both. We know that every client is unique, so we strive to deliver an individual, innovative, and affordable proposal every time, following through with an outstanding delivery that is both on time and within budget.</p><p>We have more than 12 years of development in this area and our previous clients include:</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bestcare Clinic at Target</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prestige Hospital at NMTC Campus</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Abdel Kadiri clinic at kukuo last stop</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Newlife hospital at Kukuo and other facilities and pharmacies to mention.</p><p>Please let us know if you would like to get in touch with these existing clients to hear their testimonials about Ethnicsoft solutions. You can learn more from our website at <a href=\"https://www.ethnicsoft.com/\" rel=\"noopener noreferrer\" target=\"_blank\">https://www.ethnicsoft.com</a> and our Facebook page https://wwwfacebook.com/ethnicsoft, where you can view our portfolio of previous work and our highly-trained staff.</p><p>We also pride ourselves on our after-sales client-care including our guarantees, staff training, and onsite and offsite support.</p><p>Finally, we realize that you are very busy and wanted to thank you in advance for your time spent reviewing our business proposal.</p><p><br></p><p>Yours Faithfully</p><p><img src=\"//:0\"></p><p>_________________________</p><p>ILHAM AMISSAH (Managing Director)</p><p>(Ethnicsoft Solutions)</p>', 'Tiifu Hamza Kojo Boronson', NULL),
(40, 202382112, 93, 50, 'abdominal ultrasound scan', '2023-10-05 10:24:26.035084', '2023-10-05 18:23:11.322244', '<p>keofdufjwghdmnqscqsgtfdyjhmdnqs az	</p><p>02/09/2022</p><p>​Director</p><p>Client Company name</p><p>Box KN 472 Kaneshie</p><p>Accra, Ghana</p><p><br></p><p><br></p><p>Dear Sir/Madam,</p><p class=\"ql-align-center\"><strong><u>MTR11 PROPOSAL CONSIDERATION</u></strong></p><p>Thank you for meeting with us to discuss your company’s software project requirements. Attached is our detailed software proposal for your consideration and approval.</p><p>At Ethnicsoft solutions, we know that creating client-oriented software takes a mixture of technical excellence and clear communication.</p><p>Our firm hires only the very best to ensure you receive both. We know that every client is unique, so we strive to deliver an individual, innovative, and affordable proposal every time, following through with an outstanding delivery that is both on time and within budget.</p><p>We have more than 12 years of development in this area and our previous clients include:</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bestcare Clinic at Target</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prestige Hospital at NMTC Campus</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Abdel Kadiri clinic at kukuo last stop</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Newlife hospital at Kukuo and other facilities and pharmacies to mention.</p><p>Please let us know if you would like to get in touch with these existing clients to hear their testimonials about Ethnicsoft solutions. You can learn more from our website at <a href=\"https://www.ethnicsoft.com/\" rel=\"noopener noreferrer\" target=\"_blank\">https://www.ethnicsoft.com</a> and our Facebook page https://wwwfacebook.com/ethnicsoft, where you can view our portfolio of previous work and our highly-trained staff.</p><p>We also pride ourselves on our after-sales client-care including our guarantees, staff training, and onsite and offsite support.</p><p>Finally, we realize that you are very busy and wanted to thank you in advance for your time spent reviewing our business proposal.</p><p><br></p><p>Yours Faithfully</p><p><img src=\"//:0\"></p><p>_________________________</p><p>ILHAM AMISSAH (Managing Director)</p><p>(Ethnicsoft Solutions)</p>', 'Tiifu Hamza Kojo Boronson', NULL);
INSERT INTO `scanreport` (`id`, `patientid`, `billingid`, `testid`, `scan`, `created_on`, `updated_on`, `content`, `sonographer`, `employeeid`) VALUES
(41, 202381910, 92, 51, 'obstetrics scan', '2023-10-05 10:24:45.804563', '2023-10-05 19:41:24.220452', '<p><br></p><p><span style=\"color: black;\">Aggression against others should be avoided and petty annoyances will be found if you push issues, it is better to back off for now. Working hard to make things beautiful can be satisfying for you. Don\'t hurt someone you like by making a ruthless remark that you have to apologize for later. This is a very artistic time that should be utilized to the maximum.</span></p><p><span style=\"color: black;\"> Romantic relationships started at this time will prove to be most stimulating and fulfilling. Business connected to art, music, luxury items and insurance is favored.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 10 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Sextile Node</span></p><p><span style=\"color: black;\">Communications increase with harmonious results now. This is also a favorable time for public relations, advertising, short trips and contacts with the general public and it is also a very sociable time for the exchange of ideas. You have a good grasp of any situation at hand and your judgements are sound so use it for any form of the written or oral word. Joint plans and the exchange of ideas will prosper now and the same goes for any intellectual pursuits, social or business communications.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 11 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Jupiter Trine Mercury</span></p><p><span style=\"color: black;\">Education, self study and communications are favored because of your optimistic attitude and relationships can come much closer together through travel or an increase in knowledge that you both have something in common in. Your communications with your spouse or partner will flow very easily as well.</span></p><p><span style=\"color: black;\"> Incoming news is apt to be very good at this time and a lucky break can happen, just when you need it. Opportunities can present themselves for acquiring something of substantial value and should you have the need, get expert professional opinions from others now. The power of positive thinking will get you what you want, so magnetize it and make it yours.</span></p><p><span style=\"color: black;\"> Make pacts or agreements and sign documents while this transit is in effect. Credit purchases can soar now, just make sure that you can afford what you buy. Fair settlements can be attained in legal or business transactions as well. Decisions can be made to take legal action against another at this time, perhaps with great reluctance. At the very least you may be forced to seek the advice and counsel of an attorney, especially while Jupiter is retrograde.</span></p><p><span style=\"color: black;\"> Travels (short distance or long distance) and communications are favored. This is a great time for fun and fond memories. Communications with foreigner or people at a distance will be flawless and this will prove to be a favorable time for writing, teaching, lecturing, or reading. Expect everyday phone calls to increase drastically now!</span></p><p><span style=\"color: black;\"> Mail order sales and shipping is favored and a promotion of some kind may have your name on it. Increases in mail and phone calls may keep you very busy. If you have been under the weather at all, this transit can help to put the rosiness back into those cherub cheeks. Are you waiting for a car loan to be approved? This can be the time to get the financing you need, as Jupiter rules travel and transortation and Mercury also rules transportation, travel and good news.</span></p><p><span style=\"color: black;\"> Take tests or written exams now and write down ideas, you may miss out on some inspirational insights. Words come very easy to you at this time or that long awaited phone call or letter may come.</span></p><p><span style=\"color: black;\"> Talking will be highly beneficial in your relations with others. The Mind becomes very stimulated and there is great ease in grasping \"game\" ideas. This transit may expand the thinking process somewhere in the realm of exaggerations which can make for some really great tall tales.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 12 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Trine Moon</span></p><p><span style=\"color: black;\">It will be very easy for you to express your feelings to loved ones or the public now. Perhaps you need to seek favors of others in authority and the time is appropriate to do so. You will be able to grasp situations easily and your judgment will be correct so make positive use of it. An active time where your dealings with others will have a protective and compassionate feel to it. You may also receive some very pleasant news that puts a smile on your face. This period is important for all who need to have an honest talk with others. Consider buying items at this time because you will know what you need and what you don\'t.</span></p><p><span style=\"color: black;\"> You will experience an increase in phone calls from people and relations will be better. This is a great transit for bringing people together in very odd ways and life is sure to speed up to some extent.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 13 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Sextile Mercury</span></p><p><span style=\"color: black;\">That trip you may have been planning is favored now. Communications will be at their peak, so get your point across to others while you can. You will be able to understand new concepts very easily and your social intercourse with others will be pleasant.</span></p><p><span style=\"color: black;\"> You will notice a state of restlessness now so don\'t sit around, go for a walk at least. This is the time to sign contracts or conclude agreements that have been pending. Appointments made now, will be on time and prosperous. This transit also favors reading, teaching, lecturing and group activities.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 14 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Jupiter Square Venus</span></p><p><span style=\"color: black;\">Be careful when offering your opinion without having all of the available facts, we don\'t wan\'t you making any foolish mistakes. Overindulgences can cause you to put on excess body weight during this time, so be careful what you indulge in. Sweets are one way this can be accomplished, but laziness that often accompanies this placement is the best way.</span></p><p><span style=\"color: black;\"> Insincere friendships are likely during this transit. There will be difficulty in sharing with others at this time, or in finding the delight in other peoples happiness.</span></p><p><span style=\"color: black;\"> Taking chances with money is unwise and any health problems that occur now may be linked to overindulgence, so be good to your body. Stay as close to earth as possible, so you won\'t have too far to fall should circumstances go wrong.</span></p><p><span style=\"color: black;\"> Modify your extravagance, you are likely to wind up broke! Plans you have been looking forward to will NOT materialize now and items purchased now will have a high probability of being returned to the store. Faulty emotional and financial judgment is to be expected at this time, but you will do okay if you keep expectations realistic and practical.</span></p><p><span style=\"color: black;\"> A new and significant relationship can start at this time and it will be very stimulating to say the least and allow to see yourself in a new light. Caution is advised however, because your emotions are out of whack temporarily.</span></p><p><span style=\"color: black;\"> Too much partying can leave you feeling under the weather now and gambling and speculative ventures may be very appealing to you now but don\'t go overboard so you can keep your losses to a minimum.</span></p><p><span style=\"color: black;\"> Evasion of work for the pursuit of pleasures is the theme of this transit. The expanded love urge is looking for expression, so seek and you just may find what you are looking for.</span></p><p><span style=\"color: black;\"> Vacation trips will not work out as expected because there can easily be some hidden costs involved that you didn\'t count on. This is not a productive period for work, because how can you work when your heart is set on play.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 15 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Sun Sextile Node</span></p><p><span style=\"color: black;\">Social activities and artistic expression are favored. Social popularity soars. You may assume a leadership role. Intellectual contacts and meetings can take place where you can assume a role to work as a team. Relationships with the public become more important and a woman can be united with a man.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 16 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Jupiter Sextile Moon</span></p><p><span style=\"color: black;\">Luck is sure to arrive in all areas of family life and business matters as well. You will share good times with your partners where there will be an abundance of emotional enjoyment. Sports and outdoor activities and pleasant contacts with others are very favorable now and people will enjoy your increased sense of humor.</span></p><p><span style=\"color: black;\"> This transit should find you feeling pretty good, so go out and work in the garden if you can and get a little closer to old mother earth. This is a good time to pay bills and balance the check book and caring for others in some way will be at the top of your list, especially people who may call on you for assistance. You are in an excellent frame of mind now, so enjoy it, you never know when someone is going to come along and foul it up!</span></p><p><span style=\"color: black;\"> Educational and group activities can take place at your home and people who come from a great distance from you can be a source of enjoyment, entertainment, educational or religious stimulation. Your mind may wander back to times that were very happy for you and find a greater understanding and compassion for those people less fortunate than yourself.</span></p><p><span style=\"color: black;\"> Personal contacts with others will be warm and sincere and you will see only the good in people while recognizing that everyone has a bad side. This transit increases faith in the universe and supports a greater devotion to ones higher self.</span></p><p><span style=\"color: black;\"> Prosperity will be found in finances, food related fields, business, farming, real estate and domestic products and services and your emotional responses will be filled with curiosity. One danger of this transit is laziness however and this is an excellent transit for any dealings with people.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 17 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Sun Trine Moon</span></p><p><span style=\"color: black;\">The creative juices are flowing now! What can you use that creativity on? Let your mind go free and experience something perhaps for the first time.</span></p><p><span style=\"color: black;\"> Don\'t be so easygoing now that people take advantage of you unless you want them to, that is the only real danger. Ultra Mellow frames of mind exist at this time. Romance and Real Estate matters are also favored.</span></p><p><span style=\"color: black;\"> Satisfaction with working conditions allows a better product to be produced and a more traditional type of entertainment will prove more satisfying to you in your off time.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 18 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Sextile Sun</span></p><p><span style=\"color: black;\">Are you the creative type? Do you have to make a speech or get your point across to others? Now is the time to do it. The thought and speech processes are clear as a bell and ready for ringing. Business will go well if other aspects support it.</span></p><p><span style=\"color: black;\"> This aspect is notorious for letting the phone ring off the wall with activity and keeping you extremely busy. Present your new ideas to those in authority now as they will be more open to receive them.</span></p><p><span style=\"color: black;\"> Romances, social affairs, pleasure trips, studying, publishing, dieting, buying clothes and personal hygiene are all under favorable auspices now.</span></p><p><span style=\"color: black;\"> Communications are favored, so if you have to buy, sell, travel, write, teach, or do any research this is the time to do so.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 19 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Sun Sextile Mercury</span></p><p><span style=\"color: black;\">Speak your mind in any way you need to because now is the time. This is an excellent time for romantic encounters or a special trip to a place with no return address or a rendezvous of some sort.</span></p><p><span style=\"color: black;\"> The thought and speech process are clear as a bell and ready for ringing. If you have to give a speech or think out problems to a successful conclusion, this is the time. Business will go well if other aspects support it.</span></p><p><span style=\"color: black;\"> News that arrives at this time is bound to be very gratifying and if you are awaiting news involving finances, this can be a very exciting time for you. Contracts can be agreed to and settlements can come to a head now.</span></p><p><span style=\"color: black;\"> This aspect is known for letting the phone ring off the wall with activity and keeps you extremely busy. Present your new ideas to those in authority NOW! Romance, social affairs, pleasure trips, studying, publishing, dieting, buying clothes and personal hygiene are all under favorable auspices.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 20 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Venus Square Moon</span></p><p><span style=\"color: black;\">Don\'t make the mistake of smothering others with love now, instead give them enough attention to make them want more, but not so much that they gag from it. Give them breathing room! Relations with people in general will not be very successful.</span></p><p><span style=\"color: black;\"> You may very well choose to end a relationship with a woman who has been dishonest to you recently, no matter how strong the feelings are.</span></p><p><span style=\"color: black;\"> Problems can develop in business especially if your dealings are with people you are close to. You may be a little more overprotective than usual and may feel somewhat unloved. Avoid diving into the sugar syndrome (cakes, sweets and fattening foods) for satisfaction.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 21 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mars Conjunct Mars</span></p><p><span style=\"color: black;\">This transit brings with it a renewal of a 2 year cycle connected with energy, so take the initiative and start something brand new. Restless energy is activated NOW and it needs a positive outlet. Energy is rated high and physical work, sports, athletics and competition are favored. An excellent time for dealing with machinery, tools, weapons, taxes and wills.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 22 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Sextile Saturn</span></p><p><span style=\"color: black;\">Common sense is the rule to follow for success and seek advice from those people whom you respect. This is also an excellent time for seeking the advice from a doctor for the correct diagnosis. Saying the right thing can make a great impression on people now so choose your words well or rehearse them in your mind just before you speak. Shop for practical and long lasting items because this is a favorable time for it.</span></p><p><span style=\"color: black;\"> The ability to find the right words for any situation is with you now, and problem solving should be a breeze. This is also a good time for writing and research.</span></p><p><span style=\"color: black;\"> Your education may become very important to you now, or if you are so inclined, marriage plans or engagement plans can be entered into or discussed now. Household repairs should be considered during this favorable phase as well. Cooperation can be best obtained by working in cooperation with others.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 23 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Uranus Opposes Sun</span></p><p><span style=\"color: black;\">Expect circumstances to arise quite suddenly that can make you quite \"miffed\" to say the very least. Matters that were previously settled and agreed to can come back to haunt you through missed correspondence and messages. Expect any accounts with debtors \"NOT\" to be serviced as promised at this time, no matter how hard you try. It is important to have all the information available when dealing with people, remember to get the names of people that you spoke to, times and dates. Keep copies of all letters for future reference.</span></p><p><span style=\"color: black;\"> Freedom will be sought no matter what the consequences and sudden romance begin and will end just as quickly now. This is an unfavorable time for group activity. Discrepancies in legal disputes and settlements can be found and ruinous speculation has its home here. Irregular heart actions are a direct effect of this transit. This can be a time of electrical fires as well so make sure you take precautions.</span></p><p><span style=\"color: black;\"> Murphys Law is in full effect now, so if it can go wrong it will now so hold on to something and prepare for a shock! This is not a good time for private negotiations and disappointments in all areas of life are to be expected. Conflicts of interest can easily occur and a whole new set of problems can arise without any warning. The possibility for accidents is high now, and challenges, separations and divorces can occur as well.</span></p><p><span style=\"color: black;\"> You will experience difficulties in expressing yourself and it will be tough to do with your foot in your mouth. You will have the advice potential of a blind man now, you just won\'t see it, or take it.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 24 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Conjunct Neptune</span></p><p><span style=\"color: black;\">Straightforward explanations will work best now, so if you are looking for the right time to discuss something with someone, you have it now. You may find that people you idolize have feet of clay and check out those great ideas carefully before implementing them as you may find some errors to be corrected at the last minute. Bring comfort to those who need it. Patience and tolerance is needed to keep your life in harmony and you will find that dreams and dreamlike states have you a little fuzzy in the reality department for a few days.</span></p><p><span style=\"color: black;\"> The imagination and illusion levels are high so try to keep your prospective as unclear and confused thinking accompany this transit. In the romance department, recognize love for what it is. Is it Sex, love or a short lived infatuation?</span></p><p><span style=\"color: black;\"> This is a very creative time to explore something new using the intuitive self. The ability to attract love is strong and exotic travel to places real or imagined can take place now. Drink plenty of liquids for the functioning of the kidneys can be susceptible to slowdowns now. This is not the time to make decisions on any matter. If you are wondering whether you\'re in love or not, you\'re not!</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 25 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Saturn Sextile Jupiter</span></p><p><span style=\"color: black;\">This is the right time to make some realistic and practical goals for yourself, both in your time and energy. An auspicious time to add to your resources for the future as well. Your needs for a partner at this time will be for someone who is somewhat serious but has a longing for travel and an adventure or two. It will be easy to see your relationship for what it really is now.</span></p><p><span style=\"color: black;\"> Achieve success by using the middle of the road approach in all matters now and long range business and financial plans looks good. Opportunities can be gained through hard work now and expect some growth potential from business, professional or educational pursuits.</span></p><p><span style=\"color: black;\"> Foundations for heavy responsibility can be formulated now. The projects that you have been working on for so long can pay off handsomely for you now and working with people or groups of people in some sort of structured unit has the greatest chances for success. Take note that as soon as this influence ends, it will become very quiet in your life. Perhaps that is because you have been working so hard that you deserve a break. Take advantage of the quiet time after this transit and take a rest, you never know when the next \"rush\" will be coming in.</span></p><p><span style=\"color: black;\"> Harmony will be found among friends and in social situations and you will find that you possess a remarkable organizational ability with this transit and should utilize it to get your life in order.</span></p><p><span style=\"color: black;\"> Wise investments for future rewards are favorable to make now, just make sure that you are honest and above board in all dealings. Opportunities for advancement can come from older, more mature, or authority figures. A Stable time has arrived in your life.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 26 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Conjunct Uranus</span></p><p><span style=\"color: black;\">The quest for scientific knowledge can take a sudden turn in a new direction at this time and you may come up with a terrific new idea. A totally unplanned trip may arise that can take you quite by surprise. Changes are coming, trouble is, no one knows what they are! Think before you speak so you don\'t offend someone, as it will be easy to do especially now. New concepts will come to you easily now because the thought process is accelerated. You may be asked to mediate between opposing parties that are facing problems and every attempt should be made to offer assistance. This transit also favors writing, teaching and visiting others.</span></p><p><span style=\"color: black;\"> Transportation accidents and electrical problems can manifest on aircraft, in the home, automobile or at work. If you have been waiting for the best time to sign contracts and make agreements, this is the time.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 27 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Sun Sextile Sun</span></p><p><span style=\"color: black;\">If other aspects point to it, this is a good day to put $1 on your favorite lotto number or other diversion of your choice.</span></p><p><span style=\"color: black;\"> This transit characterizes harmony in social endeavors, romantic encounters, self expression, energy and vitality, educational pursuits, leadership and confidence and creativity. Investments may pay off handsomely now and pleasure and travel trips will be very enjoyable.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 28 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mars Conjunct Jupiter</span></p><p><span style=\"color: black;\">Good fortune can come to you from behind the scenes now. It is better to stand firm on ideas now, rather then let them get away. Good will towards others can work to your advantage if you play your cards right, and an active lifestyle now can bring your special projects or accomplishments to a successful conclusion. This transit favors bravery, courage, working with men, seeking employment or advancement, legal actions, wills and taxes. Business is under a very fortunate star at this time.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 29 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Square Node</span></p><p><span style=\"color: black;\">Communications and ideas are out of sync with the rest of the world at this time. Socializing may be non existent or very difficult, so it would be best to leave it until a more favorable time. This is not a favorable time for dealing with the public, media relations or advertising.</span></p><p><span style=\"color: black;\"> Problems with the nervous system can develop, so make sure to add some physical exercise to your daily routine to stay in shape. The negative side of this transit is disruptions in relationships, gossiping, being unpleasant or totally unsociable.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 30 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mars Square Saturn</span></p><p><span style=\"color: black;\">Industrial or transportation accidents are possible, so use extreme caution. Urgent situations can arise at this time, calling for urgent solutions to problems. The presence of extreme anger should be recognized and dealt with before it gets out of hand. Young and old can easily face each other in that old popular favorite, the generation gap and matters of law and order may seem to be ineffective temporarily.</span></p><p><span style=\"color: black;\"> Don\'t force any issues because you are going to be very frustrated in your attempt, so expect blockages to your plans and ideas. Don\'t panic! The universe has a sense of humor, don\'t forget to keep yours. Difficulties can easily arise with father figures, the boss or any authority figures. Legal matters and dealing with the government are unfavorable.</span></p><p><span style=\"color: black;\"> Stick only to programs that have been working for a long time and don\'t try to make any changes or rock the boat. Those of you who waste the bosses time with foolish actions or behavior will feel the mighty wrath of who is really in charge. Difficulties over financial arrangements can arise and durability testing in relationships occurs from time to time to point out the weak areas to be worked on, this is one of those times. Separations and breakups from close attachments that occur at this time will be the result of your own actions and no one can be blamed but you!</span></p><p><span style=\"color: black;\"> Health matters that can arise now are broken bones and problems with the teeth and caution should be observed with automobiles, tools, machinery and weapons no matter how small, as injuries can occur. The burdens of older people can arise now to be dealt with as well.</span></p><p><span style=\"color: rgb(86, 70, 107);\">December 31 2021</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Sextile Pluto</span></p><p><span style=\"color: black;\">This is a very Spiritually attuned time in which new insights can be gained into the world. Your thinking may be off in the edges of \"outer space\" somewhere now, so wait until you come back to earth to make decisions. Recreational clubs and activities can flourish and the potential for writing or speaking to others is very favorable now.</span></p><p><span style=\"color: black;\"> Be on the alert for positive trends in business and finance, you may be able to take advantage of it for your own personal use. The accuracy of interpretations and personal insights are profound at this time. Paying attention to details can uncover some wonderful facets of your life, so practice positive thinking for mental stability. Your perceptions are right on target, so make sure to pay attention to your own little voice. Be flexible and willing to bend when dealing with others. You possess the ability to comfort others in their time of need.</span></p><p><span style=\"color: black;\"> Courage is abundant to face the future now and any dealings and communications with other people is favored. You can act as a mediator for people experiencing conflicts, or go over your personal finances and make the necessary changes. Advise and council others if you are asked.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 01 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Square Moon</span></p><p><span style=\"color: black;\">Communications will be strained during this time, so do not issue emotional ultimatums to others now, wait until another time when you are better in sync to speak \"to\" people, not \"at\" them. Start a diary or journal of daily routines to reflect on for future reference.</span></p><p><span style=\"color: black;\"> If you make appointments during this transit expect them to be missed, cancelled, late, experience traffic delays, or get lost in route. Unexpected visits by people you probably don\'t want to see can easily occur.</span></p><p><span style=\"color: black;\"> On the health front you can experience colds or digestive problems and watch what you put in your body, it can have an adverse reaction to the wrong substances. Wait until another time to consider advertising or deal with the public, as the ideas are good, but the timing is wrong.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 02 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Square Mercury</span></p><p><span style=\"color: black;\">This short period will not be beneficial to try and discuss matters with others because the mind is inflexible and not willing to compromise. The Ego may be out of sync with others and verbal confrontations can be expected with heavy oppositions to your ideas. Wait for another more prosperous day to make your point to others. Concerns for brothers or sisters can cause agitation in relationships and everyday matters and insignificant problems will be of greater concern than normal.</span></p><p><span style=\"color: black;\"> Incoming news may be upsetting and the thinking process will be slow and seem to be very fuzzy. How can you grasp new concepts when your mind is not functioning at its peak? Simply reschedule that meeting for another day. A fidgety type of composure exists with the urge to go and do, but you may not be sure of just what it is you should do. Patience will be non existent at this time that can cause mistakes. Stay away from stimulants which will only upset the inner you.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 03 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Sextile Venus</span></p><p><span style=\"color: black;\">This is a time of fortunate communications with others, both in person and long distance by phone. Communications are easy now and will flow quite nicely.</span></p><p><span style=\"color: black;\"> Mentally stimulating friends can be fun and this is also a good time for a sincere chat about important issues as the mind and emotions are in sync. Use this transit for making speeches to the public or attend a lecture.</span></p><p><span style=\"color: black;\"> This is an auspicious time for legal matters and marriage or studying any subject. This transit favors advertising and business communications as well as short trips. Good news might be received about a loved one that can make you very happy.</span></p><p><span style=\"color: black;\"> Consider this a quiet and peaceful time in your life. Enjoy it, you never know when the inlaws or other oddities in life will be showing up. Opportunities for social activities and romantic interludes can also come up at this time.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 04 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Sun Sextile Saturn</span></p><p><span style=\"color: black;\">Long lasting commitments and responsibilities are favorable. Buy a new car for endurance and to insure a long lasting investment at this time. You may find someone from your past coming back into your life at this time as well, or find that relationships that have experienced disagreements or breakups can suddenly begin again on another level.</span></p><p><span style=\"color: black;\"> Long range goals become important and this transit favors the favorable outcome for legal matters. Art forms are likely to have a much more structured appearance. This transit favors politics, executives and business. Have faith in yourself to reach your goals. Perhaps this is the time to face the fact that you need to seek the advice or counsel of an attorney to take you out of unpleasant situations, but with great reluctance.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 05 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Sun Conjunct Neptune</span></p><p><span style=\"color: black;\">Visionary projects of vast proportions or spiritual endeavors should be started now if you are so inclined. An artistic and creative time exists where you are very receptive to the world around you. Unusual experiences, dreams and visions can occur. You will be extremely sensitive to your surroundings and more spiritually attuned to the universe. Wait until you come back to earth for a clearer picture of what is happening. Spiritual help and guidance can easily arrive from any walk of life. Your \" psychic abilities \" will prove to be very accurate, but only if you listen. Unexplainable luck and good fortune that cannot be rationalized can easily arrive at this time.</span></p><p><span style=\"color: black;\"> This is a great transit for playing psychic detective and discovering secrets. What a day for a day dream! Ideal love relationships can begin at this time as well as those that are kept secret for reasons of your own.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 06 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Saturn Square Sun</span></p><p><span style=\"color: black;\">A time of ENDINGS has arrived in your life. What has been limiting your growth? These are the things that will pass from existence now. Let things go as gracefully as possible and prepare for new beginnings up the road.</span></p><p><span style=\"color: black;\"> This is a time of restructuring, streamlining and reorganizing the way that you work. Frustrations and depression just prior to this transit will signal the changes that are coming. Normal procedures that are done with ease will face the inevitable frustrations called \"one step forward, and two steps back.\" Work hours will increase as you try to correct the foul ups that are bound to coincide as well. You can completely abandon the work you are doing so that you can begin again at a new level.</span></p><p><span style=\"color: black;\"> The back, heart and teeth are susceptible to illness at this time, so do all that you can to prevent it, by slowing down and taking it easy! Colds or the flu can put you to bed for a while as well now.</span></p><p><span style=\"color: black;\"> Someone in your domestic arena or friends may depart at this time, and expect delays and obstacles to confront you, but you can overcome them, just be realistic in your approach and you will be fine.</span></p><p><span style=\"color: black;\"> Take further note that because of incidents that come up now you may adopt a very rigid, hard and unforgiving attitude. That\'s okay, but remember how easy it is to crack a stone.</span></p><p><span style=\"color: black;\"> Needless to say this isn\'t a favorable time for social appointments or romance as many burdens and resentments can pop up to be dealt with. Perhaps they have been neglected for too long and it will be a way of clearing the air.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 07 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Square Sun</span></p><p><span style=\"color: black;\">Communication with others is apt to be intense to say the least. That may prove to be the key to survival here. \"Say the least.\" Do not formulate or sign contracts and legal documents at this time as important points can easily be overlooked. Business meetings can be delayed at the last minute, or cancelled altogether.</span></p><p><span style=\"color: black;\"> This transit is notorious for absent-minded behavior and you may wind up somewhere you had no intention of going, with no idea how you got there. A very fuzzy mind exists that will cause you to make mistakes. You may encounter some unpleasant experiences or receive some disturbing news at this time.</span></p><p><span style=\"color: black;\"> This is a very busy and active time, but you can expect HEAVY opposition in communications with others. Avoid making any promises, forming contracts or agreements now because they are likely to fall apart as fast as they started.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 08 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Mercury Sextile Mars</span></p><p><span style=\"color: black;\">People involved in sales or communications will prosper and the home, property and family interests will be activated. Mental alertness now will bring quick decisions resulting in success. Total recall of past events aids you in discovering hidden elements of yourself. This is one of those time periods that supports sticking to your guns for what you believe in.</span></p><p><span style=\"color: black;\"> Winning arguments can be easy now and any communications, study, writing and research of any kind will be fortunate. This is an excellent placement for the formulation of agreements and contracts and any military and police activities.</span></p><p><span style=\"color: black;\"> This is an excellent transit to make peace with others, not war. Teach, council and help others. Short trips related to work are emphasized and last minute invitations to sporting events can arrive. This is an excellent time to do some investigative work into something you are curious about.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 09 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Sun Conjunct Uranus</span></p><p><span style=\"color: black;\">The dandiest friendships can develop most unexpectedly. Excitement is on your mind in every fiber of your being. Metaphysical, psychological, spiritual and astrological interests can light up your life. Every aspect of these days can take on an electrical, exciting and a very surprising tone. Surprising others through your actions is also possible. Explosions and fire potentials can increase now, so keep an eye out for hazards.</span></p><p><span style=\"color: black;\"> When forming a contract, don\'t forget an escape clause just in case you need to do just that. Conflicts and arguments can pop up easily in your daily environment. Your intuitive and psychic abilities will be high, so pay some attention to your \"little voice\" and expect to remember your dreams.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 10 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Pluto Conjunct Uranus</span></p><p><span style=\"color: black;\">Being a rebel with a cause is a wonderful thing, unfortunately there are no \"causes\" connected with this transit, but that won\'t stop you from being a rebel anyway.</span></p><p><span style=\"color: black;\"> Changes at the very root of your self can take place now and very rapidly I might add. Evidently you had the chance to make changes before this transit came up, but you didn\'t take advantage of it so now the Universe in all of its wisdom is forcing you to do it and now there is no choice. You can easily experience some clairvoyant and psychic occurrences at this time as well.</span></p><p><span style=\"color: black;\"> Friendships can very well end now and new ones can begin just as suddenly, or if you have any interest in reincarnation or parapsychology, this would be an excellent time to look into it, as latent talents and abilities you never knew you had can emerge quite nicely at this time.</span></p><p><span style=\"color: black;\"> You can experience changes in money matters, the way that you handle your taxes and insurance needs as well during this transit.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 11 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Jupiter Sextile Moon</span></p><p><span style=\"color: black;\">Luck is sure to arrive in all areas of family life and business matters as well. You will share good times with your partners where there will be an abundance of emotional enjoyment. Sports and outdoor activities and pleasant contacts with others are very favorable now and people will enjoy your increased sense of humor.</span></p><p><span style=\"color: black;\"> This transit should find you feeling pretty good, so go out and work in the garden if you can and get a little closer to old mother earth. This is a good time to pay bills and balance the check book and caring for others in some way will be at the top of your list, especially people who may call on you for assistance. You are in an excellent frame of mind now, so enjoy it, you never know when someone is going to come along and foul it up!</span></p><p><span style=\"color: black;\"> Educational and group activities can take place at your home and people who come from a great distance from you can be a source of enjoyment, entertainment, educational or religious stimulation. Your mind may wander back to times that were very happy for you and find a greater understanding and compassion for those people less fortunate than yourself.</span></p><p><span style=\"color: black;\"> Personal contacts with others will be warm and sincere and you will see only the good in people while recognizing that everyone has a bad side. This transit increases faith in the universe and supports a greater devotion to ones higher self.</span></p><p><span style=\"color: black;\"> Prosperity will be found in finances, food related fields, business, farming, real estate and domestic products and services and your emotional responses will be filled with curiosity. One danger of this transit is laziness however and this is an excellent transit for any dealings with people.</span></p><p><span style=\"color: rgb(86, 70, 107);\">January 12 2022</span></p><p><br></p><p class=\"ql-align-justify\"><span style=\"color: rgb(93, 143, 72);\">Neptune Conjunct Saturn</span></p><p><span style=\"color: black;\">There may be a need to deceive others as to your intentions or make sure that lies or non truths told to others will not be discovered in any way.</span></p><p><span style=\"color: black;\"> Adverse conditions for business and government are in full effect now and thefts can occur especially in business. A very uninspired time for the creative, musical and artistic mind and you may find that some sacrifices are not only necessary, but they are called for in your life at this time.</span></p><p><span style=\"color: black;\"> Unrealistic hopes, desires and expectations will be difficult to overcome and you can best utilize this energy to find someone that can use compassion and charity and help them. This is not a favorable time for any drinking, smoking or the taking of drugs (pharmaceutical or other) because they will have an adverse affect on the body and you may find that the lungs are equally as vulnerable. This would be an excellent time for self discipline for a specific purpose.</span></p><p><span style=\"color: black;\"> Leave the psychic and spiritual endeavors for another time as they will be out of whack now and you will also fin uncertainties in business and partnerships can occur. Neptune always offers that foggy appearance to everything and that fog will not clear until this transit does. You may also be involved in some secret investigations or secret business negotiations during this transit.</span></p><p class=\"ql-align-center\"><span style=\"color: black;\">COPYRIGHT © 2000-2021 AstroMary. All rights reserved&nbsp;</span><em style=\"color: black;\">-</em><span style=\"color: black;\">&nbsp;</span><a href=\"https://www.astromary.com/terms.php?token=D0499F5E3C3CDD9623ECC5064AEA09D6\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(34, 34, 34);\">Terms &amp; Conditions of services - Privacy Policy</a></p><p><br></p><p><br></p><p>djuwquqjkqcqw</p><p><br></p><p><br></p><p><br></p><p>uwuqwfjk</p><p><br></p><p><br></p><p><br></p><p>fuqwfjqwfkfwqa</p><p><br></p><p><br></p><p>02/09/2022</p><p>​Director</p><p>Client Company name</p><p>Box KN 472 Kaneshie</p><p>Accra, Ghana</p><p><br></p><p><br></p><p>Dear Sir/Madam,</p><p class=\"ql-align-center\"><strong><u>MTR11 PROPOSAL CONSIDERATION</u></strong></p><p>Thank you for meeting with us to discuss your company’s software project requirements. Attached is our detailed software proposal for your consideration and approval.</p><p>At Ethnicsoft solutions, we know that creating client-oriented software takes a mixture of technical excellence and clear communication.</p><p>Our firm hires only the very best to ensure you receive both. We know that every client is unique, so we strive to deliver an individual, innovative, and affordable proposal every time, following through with an outstanding delivery that is both on time and within budget.</p><p>We have more than 12 years of development in this area and our previous clients include:</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bestcare Clinic at Target</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prestige Hospital at NMTC Campus</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Abdel Kadiri clinic at kukuo last stop</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Newlife hospital at Kukuo and other facilities and pharmacies to mention.</p><p>Please let us know if you would like to get in touch with these existing clients to hear their testimonials about Ethnicsoft solutions. You can learn more from our website at <a href=\"https://www.ethnicsoft.com/\" rel=\"noopener noreferrer\" target=\"_blank\">https://www.ethnicsoft.com</a> and our Facebook page https://wwwfacebook.com/ethnicsoft, where you can view our portfolio of previous work and our highly-trained staff.</p><p>We also pride ourselves on our after-sales client-care including our guarantees, staff training, and onsite and offsite support.</p><p>Finally, we realize that you are very busy and wanted to thank you in advance for your time spent reviewing our business proposal.</p><p><br></p><p>Yours Faithfully</p><p><img src=\"//:0\"></p><p>_________________________</p><p>ILHAM AMISSAH (Managing Director)</p><p>(Ethnicsoft Solutions)</p>', 'Tiifu Hamza Kojo Boronson', NULL),
(42, 20238187, 96, 54, 'abdominal pelvic scan', '2023-10-05 21:19:02.820427', NULL, '<p>gqhdjq,kdq	ws	hjkld/q`w	hkl;\'</p><p>;lkwjhvdcjkl;\'</p><p>	\';lskjhcvsnnk;l\'</p><p>4\';lkjhmjkl;\'</p><p>45</p><p>\';lkjhgjkl;\'</p><p>4\';jhg	</p>', 'Tiifu Hamza Kojo Boronson', NULL),
(43, 202382112, 102, 50, 'abdominal ultrasound scan', '2023-10-06 03:20:51.998147', NULL, '<p>lp2eoeogieklfwdifeiofwklvsdfweiofoiof2ejkfkwds</p><p><br></p><p><br></p><p><br></p><p>wpfoegpogjkwdgwd</p><p>4</p><p><br></p><p><br></p><p><br></p><p><br></p><p>dfpwpfgoepogepopoewpowe</p><p><br></p><p><br></p><p><br></p><p><br></p><p>powpfoepofpoepfowdpofw</p><p><br></p><p><br></p><p><br></p><p><br></p><p>poefpowepofeppo	</p>', 'Tiifu Hamza Kojo Boronson', NULL),
(44, 202382112, 102, 51, 'obstetrics scan', '2023-10-06 03:21:05.191331', NULL, '<p>ki2efi2eoroq	edpo</p><p><br></p><p><br></p><p><br></p><p><br></p><p>wpowpfwpfp[qw</p><p><br></p><p><br></p><p><br></p><p><br></p><p>plqwpfqp[</p>', 'Tiifu Hamza Kojo Boronson', NULL),
(45, 20239723, 110, 7, 'Hepatitis B Profile', '2023-10-17 19:35:22.141227', NULL, '<p>ooFIOIOFIQFIFOOIFIQFQIO]</p><p><br></p><p><br></p><p><br></p><p>FKWKFKWFJKSA</p><p><br></p><p><br></p><p><br></p><p>authentic?.user?.permissions</p><p><br></p><p><br></p><p><br></p><p><br></p><p>\'JDVKWD</p>', 'Tiifu Hamza Kojo Boronson', NULL);
INSERT INTO `scanreport` (`id`, `patientid`, `billingid`, `testid`, `scan`, `created_on`, `updated_on`, `content`, `sonographer`, `employeeid`) VALUES
(46, 20239721, 112, 7, 'Hepatitis B Profile', '2023-10-17 19:35:35.739322', NULL, '<p>OAWFOWODO	</p><p><br></p><p><br></p><p><br></p><p>SLVDLAL</p><p><br></p><p><br></p><p><br></p><p>LKSVKASK</p>', 'Tiifu Hamza Kojo Boronson', NULL),
(47, 20239723, 119, 54, 'abdominal pelvic scan', '2023-10-28 11:09:26.927401', '2023-10-31 03:00:17.267597', '<p>Tiifu Hamza</p><p>Kalpohin Lowcost 30A, Tamale</p><p>Northern Region, Tamale.</p><p>21/04/2023.</p><p><br></p><p>The Registrar</p><p>Klintaps College of Health Science</p><p>DTD TDC Plot 30A, Klagon, Community 19, Tema.Accra,Klagon,</p><p>Dear Registrar,</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><u>REQUEST TO PUT HOLD ON EDUCATION FOR A YEAR</u></strong></p><p>I hope this letter finds you well. I am writing to formally request a hold on my education for a year at Klintaps college of Health Sciences Due to financial constraints, I am unable to continue with my studies at the present time.</p><p>I have been facing significant financial challenges that have made it difficult for me to meet the financial obligations associated with my education. Despite my best efforts to secure financial assistance, I am unable to afford the tuition fees and other expenses associated with my studies at this time.</p><p>After careful consideration, I have made the difficult decision to put my education on hold for a year in order to work and save up the necessary funds to continue my studies. During this time, I plan to seek additional sources of financial support and explore various options to alleviate my financial situation.</p><p>I would like to assure you that I am committed to completing my education and I plan to return to resume my studies as soon as I am able to overcome my financial challenges.</p><p>I kindly request your assistance in facilitating the process of putting my education on hold for a year. I am also open to any advice or guidance you may have on this matter. I am grateful for your understanding and support in this situation. Please let me know of any further steps or documentation required from my end to formalize this request.</p><p>Thank you for considering my request. I am looking forward to your positive response.</p><p>Sincerely,</p><p>Tiifu Hamza</p><h1>0595964565</h1>', 'Tiifu Hamza Kojo Boronson', NULL),
(48, 202392724, 120, 50, 'abdominal ultrasound scan', '2023-10-29 14:45:08.713976', '2023-10-31 02:59:29.947885', '<p>Tiifu Hamza</p><p>Kalpohin Lowcost 30A, Tamale</p><p>Northern Region, Tamale.</p><p>21/04/2023.</p><p><br></p><p>The Registrar</p><p>Klintaps College of Health Science</p><p>DTD TDC Plot 30A, Klagon, Community 19, Tema.Accra,Klagon,</p><p>Dear Registrar,</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><u>REQUEST TO PUT HOLD ON EDUCATION FOR A YEAR</u></strong></p><p>I hope this letter finds you well. I am writing to formally request a hold on my education for a year at Klintaps college of Health Sciences Due to financial constraints, I am unable to continue with my studies at the present time.</p><p>I have been facing significant financial challenges that have made it difficult for me to meet the financial obligations associated with my education. Despite my best efforts to secure financial assistance, I am unable to afford the tuition fees and other expenses associated with my studies at this time.</p><p>After careful consideration, I have made the difficult decision to put my education on hold for a year in order to work and save up the necessary funds to continue my studies. During this time, I plan to seek additional sources of financial support and explore various options to alleviate my financial situation.</p><p>I would like to assure you that I am committed to completing my education and I plan to return to resume my studies as soon as I am able to overcome my financial challenges.</p><p>I kindly request your assistance in facilitating the process of putting my education on hold for a year. I am also open to any advice or guidance you may have on this matter. I am grateful for your understanding and support in this situation. Please let me know of any further steps or documentation required from my end to formalize this request.</p><p>Thank you for considering my request. I am looking forward to your positive response.</p><p>Sincerely,</p><p>Tiifu Hamza</p><h1>0595964565</h1>', 'Tiifu Hamza Kojo Boronson', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `semenanalysis`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `semenanalysis`;
CREATE TABLE `semenanalysis` (
  `keyid` int(255) NOT NULL,
  `spermcount` varchar(100) NOT NULL,
  `collectiontime` varchar(6) NOT NULL,
  `collectionDate` date NOT NULL,
  `abstinence` tinyint(10) NOT NULL,
  `quantity` tinyint(10) NOT NULL,
  `colour` varchar(30) NOT NULL,
  `consistency` varchar(50) NOT NULL,
  `motility` tinyint(20) NOT NULL,
  `motilityGrade` varchar(100) NOT NULL,
  `morphology` varchar(100) NOT NULL,
  `pusCells` varchar(20) NOT NULL DEFAULT 'absent',
  `rbcs` varchar(20) NOT NULL DEFAULT 'absent',
  `impression` varchar(100) NOT NULL,
  `billingid` int(11) NOT NULL,
  `liquefactionTime` varchar(20) NOT NULL,
  `ph` int(10) NOT NULL,
  `fructose` varchar(20) NOT NULL,
  `epithelialCells` varchar(20) NOT NULL,
  `patientid` bigint(100) NOT NULL,
  `updated_on` datetime(6) DEFAULT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `semenanalysis`:
--

--
-- Dumping data for table `semenanalysis`
--

INSERT INTO `semenanalysis` (`keyid`, `spermcount`, `collectiontime`, `collectionDate`, `abstinence`, `quantity`, `colour`, `consistency`, `motility`, `motilityGrade`, `morphology`, `pusCells`, `rbcs`, `impression`, `billingid`, `liquefactionTime`, `ph`, `fructose`, `epithelialCells`, `patientid`, `updated_on`, `employeeid`) VALUES
(0, '80', '20:56', '2021-01-08', 3, 4, 'Greyish white', 'Viscous', 40, 'Grade 3', 'Normal', 'absent', 'absent', 'Normal semen analysis', 209, '30 mins', 10, 'Positive', 'present', 2023854, '2023-11-26 12:12:13.000000', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `setupbetathalassemia`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setupbetathalassemia`;
CREATE TABLE `setupbetathalassemia` (
  `setupid` int(255) NOT NULL,
  `upper` int(10) NOT NULL,
  `lower` int(10) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `parameter` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setupbetathalassemia`:
--

--
-- Dumping data for table `setupbetathalassemia`
--

INSERT INTO `setupbetathalassemia` (`setupid`, `upper`, `lower`, `unit`, `gender`, `parameter`) VALUES
(1, 4000, 200, 'mg/dl', '', 'HFA'),
(2, 3030, 288, 'mg/sl', '', 'HFB');

-- --------------------------------------------------------

--
-- Table structure for table `setupglucose`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setupglucose`;
CREATE TABLE `setupglucose` (
  `id` int(100) NOT NULL,
  `parameter` varchar(100) NOT NULL,
  `upper` double NOT NULL,
  `lower` double NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `unit` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setupglucose`:
--

--
-- Dumping data for table `setupglucose`
--

INSERT INTO `setupglucose` (`id`, `parameter`, `upper`, `lower`, `created_on`, `updated_on`, `unit`) VALUES
(1, 'random blood sugar', 10, 4, '2023-12-02 15:13:10.180344', NULL, 'mg/dl'),
(2, 'fasting blood sugar', 10, 4, '2023-12-02 15:13:10.245038', NULL, 'mg/dl');

-- --------------------------------------------------------

--
-- Table structure for table `setupliteraturereview`
--
-- Creation: Dec 02, 2023 at 03:07 PM
--

DROP TABLE IF EXISTS `setupliteraturereview`;
CREATE TABLE `setupliteraturereview` (
  `id` int(50) NOT NULL,
  `testname` varchar(100) NOT NULL,
  `literature` text DEFAULT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000' ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setupliteraturereview`:
--

--
-- Dumping data for table `setupliteraturereview`
--

INSERT INTO `setupliteraturereview` (`id`, `testname`, `literature`, `created_on`, `updated_on`) VALUES
(1, 'haemoglobin_electrophoresis', '<p>jwdjdkwdk</p>', '2023-12-02 07:28:38.297332', '0000-00-00 00:00:00.000000'),
(2, 'cardiac_enzymes', '<p>udates here&nbsp;</p>', '2023-12-02 07:39:13.423612', '0000-00-00 00:00:00.000000'),
(3, 'liver_function_test', '<p>liver functional test</p>', '2023-12-02 07:42:54.387878', '0000-00-00 00:00:00.000000'),
(4, 'renal_function_test', '<p>ogrgpfpp</p>', '2023-12-02 07:47:00.750941', '2023-12-02 08:04:50.264705'),
(5, 'thyroid_functional_test', '<p>thyroid functional test</p>', '2023-12-02 07:47:50.199989', '0000-00-00 00:00:00.000000'),
(6, 'luteinizing_hormone', '<p>literature review&nbsp;</p>', '2023-12-02 08:10:35.818037', '0000-00-00 00:00:00.000000'),
(7, 'follicle_stimulating_hormone', '<p>fsh literature here please</p>', '2023-12-02 08:12:34.626948', '0000-00-00 00:00:00.000000'),
(8, 'prostate_specific_antigen_test', '<p>psa lietrature here</p>', '2023-12-02 08:16:40.065005', '0000-00-00 00:00:00.000000'),
(9, 'esr', '<p>jqEJJEJW</p>', '2023-12-02 12:56:07.988177', '2023-12-02 13:09:50.083790'),
(10, 'lipid_profile', '<p>lipid profile test</p>', '2023-12-02 13:42:18.022035', '0000-00-00 00:00:00.000000'),
(11, 'bloodCulture', '<p>ididisdisi</p>', '2023-12-02 14:13:48.338386', '0000-00-00 00:00:00.000000'),
(12, 'random_blood_sugar', '<p>kawfkdk</p><p>&nbsp;</p>', '2023-12-02 15:13:10.368393', '0000-00-00 00:00:00.000000'),
(13, 'betathalassemia', '<p>jwdfjfjw</p>', '2023-12-05 08:08:27.014552', '0000-00-00 00:00:00.000000'),
(14, 'beta_thalassemia', '<p>This is a necessary evil to keep in loop</p>', '2023-12-05 08:55:03.121743', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `setup_beta_hcg`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_beta_hcg`;
CREATE TABLE `setup_beta_hcg` (
  `keyid` int(255) NOT NULL,
  `weeks` int(10) NOT NULL,
  `lower` int(255) NOT NULL,
  `upper` int(255) NOT NULL,
  `unit` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_beta_hcg`:
--

--
-- Dumping data for table `setup_beta_hcg`
--

INSERT INTO `setup_beta_hcg` (`keyid`, `weeks`, `lower`, `upper`, `unit`) VALUES
(1, 2, 88, 200, 'UL/ml'),
(2, 3, 450000, 5949400, 'UL/gl'),
(3, 4, 45000, 6049400, 'UL/gl'),
(4, 5, 45000, 6049400, 'UL/gl'),
(5, 6, 45000, 6049400, 'UL/gl'),
(6, 7, 45000, 6049400, 'UL/gl'),
(7, 8, 45000, 6049400, 'UL/gl'),
(8, 9, 45000, 6049400, 'UL/gl'),
(9, 10, 45000, 6049400, 'UL/gl'),
(10, 11, 45000, 6049400, 'UL/gl'),
(11, 12, 45000, 6049400, 'UL/gl'),
(12, 13, 45000, 6049400, 'UL/gl'),
(13, 14, 45000, 6049400, 'UL/gl'),
(14, 15, 45000, 6049400, 'UL/gl'),
(15, 16, 45000, 6049400, 'UL/gl');

-- --------------------------------------------------------

--
-- Table structure for table `setup_cardiac_enzymes`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_cardiac_enzymes`;
CREATE TABLE `setup_cardiac_enzymes` (
  `setupid` int(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `upper` int(20) NOT NULL,
  `lower` int(20) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `display` varchar(10) NOT NULL DEFAULT 'TRUE',
  `createdon` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updatedon` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_cardiac_enzymes`:
--

--
-- Dumping data for table `setup_cardiac_enzymes`
--

INSERT INTO `setup_cardiac_enzymes` (`setupid`, `unit`, `upper`, `lower`, `parameter`, `display`, `createdon`, `updatedon`) VALUES
(1, 'U/L', 800, 200, 'creatinine kinase (CK)', 'TRUE', '2023-12-02 07:39:13.328943', NULL),
(2, 'U/L', 600, 243, 'lactate dehydrogenase (LDH)', 'TRUE', '2023-12-02 07:39:13.334230', NULL),
(3, 'U/L', 700, 243, 'aspartate transaminase(AST)', 'TRUE', '2023-12-02 07:39:13.334875', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `setup_esr`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_esr`;
CREATE TABLE `setup_esr` (
  `keyid` int(255) NOT NULL,
  `agelimit` varchar(50) NOT NULL,
  `upper` int(50) NOT NULL,
  `lower` int(50) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `gender` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_esr`:
--

--
-- Dumping data for table `setup_esr`
--

INSERT INTO `setup_esr` (`keyid`, `agelimit`, `upper`, `lower`, `created_on`, `gender`) VALUES
(1, 'under 50 years', 200, 50, '2023-12-02 14:53:54.622880', 'female'),
(2, 'over 50 years', 200, 50, '2023-12-02 14:53:54.647121', 'female'),
(3, 'under 50 years', 200, 50, '2023-12-02 14:53:54.671449', 'male'),
(4, 'over 50 years', 200, 50, '2023-12-02 14:53:54.733715', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `setup_fullcount_paramters`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_fullcount_paramters`;
CREATE TABLE `setup_fullcount_paramters` (
  `setupid` int(255) NOT NULL,
  `parameter` varchar(250) NOT NULL,
  `upper` int(100) NOT NULL,
  `lower` int(100) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_fullcount_paramters`:
--

--
-- Dumping data for table `setup_fullcount_paramters`
--

INSERT INTO `setup_fullcount_paramters` (`setupid`, `parameter`, `upper`, `lower`, `unit`, `date`) VALUES
(0, 'heamoglobinx', 14, 8, 'g/dl', '2023-11-26 16:16:10.768700'),
(1, 'haemoglobin', 18, 10, 'mg/dl', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `setup_full_blood_count_test_general`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_full_blood_count_test_general`;
CREATE TABLE `setup_full_blood_count_test_general` (
  `setupid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `lower` int(10) NOT NULL,
  `upper` int(10) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_full_blood_count_test_general`:
--

--
-- Dumping data for table `setup_full_blood_count_test_general`
--

INSERT INTO `setup_full_blood_count_test_general` (`setupid`, `parameter`, `unit`, `lower`, `upper`, `created_on`) VALUES
(1, 'wbc', 'mg/dl', 20, 30, '2023-11-26 17:22:35.450427'),
(2, 'neutrophils', 'mg/dlg/dl', 39, 499, '2023-11-26 17:22:35.474417'),
(3, 'eosinophils', 'mg/dl', 299, 3893, '2023-11-26 17:22:35.499366'),
(4, 'basophils', 'mg/dl', 29, 499, '2023-11-26 17:22:35.549115'),
(5, 'lymphocytes', 'mg/dl', 29, 3883, '2023-11-26 17:22:35.674250'),
(6, 'monocytes', 'mg/dlg/hj', 28, 388, '2023-11-26 17:22:35.700125'),
(7, 'mch', 'mg/dlg/hj', 40, 3883, '2023-11-26 17:22:35.753613'),
(8, 'mcv', 'mg/dlg/hj', 29, 3838, '2023-11-26 17:22:35.775042'),
(9, 'mchc', 'mg/dl%', 20, 969, '2023-11-26 17:22:35.800317'),
(10, 'rdw-cv', 'mg/dl%', 10, 813, '2023-11-26 17:22:35.824914'),
(11, 'rdw-sd', 'mg/dl%', 29, 293, '2023-11-26 17:22:35.850460');

-- --------------------------------------------------------

--
-- Table structure for table `setup_full_blood_count_test_male`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_full_blood_count_test_male`;
CREATE TABLE `setup_full_blood_count_test_male` (
  `setupid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `lower` float NOT NULL,
  `upper` float NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_full_blood_count_test_male`:
--

--
-- Dumping data for table `setup_full_blood_count_test_male`
--

INSERT INTO `setup_full_blood_count_test_male` (`setupid`, `parameter`, `unit`, `lower`, `upper`, `created_on`) VALUES
(1, 'wbc', 'mg/dl', 20, 30, '2023-11-27 07:16:14.261254'),
(2, 'neutrophils', 'mg/dlg/dl', 20, 400, '2023-11-27 07:16:14.302269'),
(3, 'eosinophils', 'mg/dl', 30, 3000, '2023-11-27 07:16:14.327507'),
(4, 'basophils', 'mg/dl', 29, 4949, '2023-11-27 07:16:14.418236'),
(5, 'lymphocytes', 'mg/dl', 929, 9393, '2023-11-27 07:16:14.476587'),
(6, 'monocytes', 'mg/dlg/hj', 10, 399, '2023-11-27 07:16:14.519933'),
(7, 'mch', 'mg/dlg/hj', 39, 993, '2023-11-27 07:16:14.618748'),
(8, 'mcv', 'mg/dlg/hj', 299, 399, '2023-11-27 07:16:14.665015'),
(9, 'mchc', 'mg/dl%', 299, 3993, '2023-11-27 07:16:14.710543'),
(10, 'rdw-cv', 'mg/dl%', 39, 399, '2023-11-27 07:16:14.760796'),
(11, 'rdw-sd', 'mg/dl%', 399, 3993, '2023-11-27 07:16:14.785409');

-- --------------------------------------------------------

--
-- Table structure for table `setup_full_count_count_female`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_full_count_count_female`;
CREATE TABLE `setup_full_count_count_female` (
  `parameter` varchar(255) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `upper` int(10) NOT NULL,
  `lower` int(10) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `keyid` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_full_count_count_female`:
--

--
-- Dumping data for table `setup_full_count_count_female`
--

INSERT INTO `setup_full_count_count_female` (`parameter`, `unit`, `upper`, `lower`, `created_on`, `keyid`) VALUES
('wbc', 'mg/dl', 30, 20, '2023-11-26 17:21:54.041591', 1),
('neutrophils', 'mg/dlg/dl', 100, 20, '2023-11-26 17:21:54.085990', 2),
('eosinophils', 'mg/dl', 3000, 200, '2023-11-26 17:21:54.107307', 3),
('basophils', 'mg/dl', 300, 20, '2023-11-26 17:21:54.156750', 4),
('lymphocytes', 'mg/dl', 3000, 30, '2023-11-26 17:21:54.206737', 5),
('monocytes', 'mg/dlg/hj', 300, 29, '2023-11-26 17:21:54.231258', 6),
('mch', 'mg/dlg/hj', 399, 92, '2023-11-26 17:21:54.257897', 7),
('mcv', 'mg/dlg/hj', 2947, 388, '2023-11-26 17:21:54.282416', 8),
('mchc', 'mg/dl%', 388, 88, '2023-11-26 17:21:54.324717', 9),
('rdw-cv', 'mg/dl%', 3838, 188, '2023-11-26 17:21:54.710496', 10),
('rdw-sd', 'mg/dl%', 3883, 38, '2023-11-26 17:21:54.769536', 11);

-- --------------------------------------------------------

--
-- Table structure for table `setup_glycated_heamoglobin_test`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_glycated_heamoglobin_test`;
CREATE TABLE `setup_glycated_heamoglobin_test` (
  `TESTID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_glycated_heamoglobin_test`:
--

-- --------------------------------------------------------

--
-- Table structure for table `setup_lipid_profile_test`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_lipid_profile_test`;
CREATE TABLE `setup_lipid_profile_test` (
  `setupid` int(255) NOT NULL,
  `parameter` varchar(100) NOT NULL,
  `upper` int(100) NOT NULL,
  `lower` int(100) NOT NULL,
  `unit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_lipid_profile_test`:
--

--
-- Dumping data for table `setup_lipid_profile_test`
--

INSERT INTO `setup_lipid_profile_test` (`setupid`, `parameter`, `upper`, `lower`, `unit`) VALUES
(1, 'CHOLESTEROL', 600, 498, 'mg/dl'),
(2, 'TRIGLYCERIDES', 600, 498, 'mg/dl'),
(3, 'HDL', 600, 498, 'mg/dl'),
(4, 'LDL', 600, 498, 'mg/dl'),
(5, 'TOTAL CHOLESEROL', 600, 498, 'mg/dl'),
(6, 'TG/HDL', 600, 498, 'mg/dl');

-- --------------------------------------------------------

--
-- Table structure for table `setup_liver_function_test`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_liver_function_test`;
CREATE TABLE `setup_liver_function_test` (
  `setupid` int(255) NOT NULL,
  `parameter` varchar(100) NOT NULL,
  `upper` int(100) NOT NULL,
  `lower` int(100) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `unit` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_liver_function_test`:
--

--
-- Dumping data for table `setup_liver_function_test`
--

INSERT INTO `setup_liver_function_test` (`setupid`, `parameter`, `upper`, `lower`, `created_on`, `unit`) VALUES
(1, 'creatinine', 600, 600, '2023-12-02 07:47:23.218709', 'mg/dl'),
(2, 'alp', 600, 600, '2023-12-02 07:47:23.219121', 'mg/dl'),
(3, 'albumin', 300, 600, '2023-12-02 07:47:23.219428', 'mg/dl'),
(4, 'total protein', 600, 300, '2023-12-02 07:47:23.219839', 'mg/dl'),
(5, 'ast', 6000, 600, '2023-12-02 07:47:23.220439', 'mg/dl'),
(6, 'alt', 600, 600, '2023-12-02 07:47:23.220930', 'mg/dl'),
(7, 'bun', 600, 600, '2023-12-02 07:47:23.221378', 'mg/dl'),
(8, 'i am me ', 3000, 200, '2024-01-13 22:54:19.532885', 'me'),
(9, 'i am him', 4949, 3090, '2024-01-13 22:54:19.547912', 'him ');

-- --------------------------------------------------------

--
-- Table structure for table `setup_renal_function_test`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_renal_function_test`;
CREATE TABLE `setup_renal_function_test` (
  `setupid` int(255) NOT NULL,
  `parameter` varchar(100) NOT NULL,
  `upper` int(50) NOT NULL,
  `lower` int(50) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `created_on` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_renal_function_test`:
--

--
-- Dumping data for table `setup_renal_function_test`
--

INSERT INTO `setup_renal_function_test` (`setupid`, `parameter`, `upper`, `lower`, `unit`, `created_on`) VALUES
(1, 'potasium', 2520, 10, 'mg/dl', NULL),
(2, 'sodium', 6822, 300, 'mg/dl', NULL),
(3, 'chloride', 55845, 6000, 'mg/dl', NULL),
(4, 'bicarbonate', 1000, 50, 'mg/dl', NULL),
(5, 'albumin', 1000, 50, 'mg/dl', NULL),
(6, 'BUN', 5555, 600, 'mg/dl', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `setup_thyroid_test`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `setup_thyroid_test`;
CREATE TABLE `setup_thyroid_test` (
  `setupid` int(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `upper` int(255) NOT NULL,
  `lower` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `setup_thyroid_test`:
--

--
-- Dumping data for table `setup_thyroid_test`
--

INSERT INTO `setup_thyroid_test` (`setupid`, `parameter`, `unit`, `upper`, `lower`) VALUES
(1, 'TSH', 'pmol/L', 2000, 498),
(2, 'T4', 'pmol/L', 30000, 498),
(3, 'T3', 'pmol/L', 40000, 498);

-- --------------------------------------------------------

--
-- Table structure for table `shelves`
--
-- Creation: Jan 11, 2024 at 04:45 PM
--

DROP TABLE IF EXISTS `shelves`;
CREATE TABLE `shelves` (
  `id` int(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `warehouse` int(25) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `shelves`:
--

--
-- Dumping data for table `shelves`
--

INSERT INTO `shelves` (`id`, `name`, `warehouse`, `created_on`) VALUES
(1, 'tiifu', 3, '2024-01-11 18:38:38.974970'),
(2, 'racr45', 5, '2024-01-11 18:40:39.177936'),
(3, 'racr45', 5, '2024-01-11 18:41:00.328183'),
(4, 'rack676', 6, '2024-01-11 18:41:38.849228'),
(5, 'Rack101', 6, '2024-01-11 23:31:12.967000'),
(6, 'Tiifu Rack is here', 7, '2024-01-11 23:31:40.165925'),
(7, 'rack area 67', 2, '2024-01-11 23:33:01.778148'),
(8, 'rack 80', 2, '2024-01-11 23:39:48.732130'),
(9, 'tiifu', 9, '2024-01-11 23:44:36.743714'),
(10, 'genseis', 5, '2024-01-11 23:45:08.833661'),
(11, 'xxxxx', 2, '2024-01-11 23:46:34.227170'),
(12, 'tiifux', 9, '2024-01-11 23:46:58.159013'),
(13, 'hhhhh', 5, '2024-01-11 23:47:20.056450'),
(14, 'jjjjjjjjj', 5, '2024-01-11 23:47:56.876129'),
(15, 'YUUUUU', 7, '2024-01-11 23:48:49.269134'),
(16, 'kkkk', 8, '2024-01-11 23:50:41.925798'),
(17, 'hamzaRack1', 10, '2024-01-12 10:18:17.717653'),
(18, '309', 10, '2024-01-12 12:42:11.090311'),
(19, 'dolimenaa', 3, '2024-01-13 19:25:06.824820'),
(20, 'tiifu hamza is here for good and to make an impact towards humanity', 3, '2024-01-15 13:11:55.297525');

-- --------------------------------------------------------

--
-- Table structure for table `stockcategory`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `stockcategory`;
CREATE TABLE `stockcategory` (
  `id` int(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `stockcategory`:
--

--
-- Dumping data for table `stockcategory`
--

INSERT INTO `stockcategory` (`id`, `category`, `date`) VALUES
(1, 'consumables', '2023-09-24 02:37:41.387396'),
(2, 'disposable', '2023-10-13 07:50:18.375552'),
(3, 'furnitures', '2023-10-13 07:51:34.740246'),
(4, 'asserts', '2023-10-13 07:53:23.156986'),
(5, 'medicine ', '2023-10-13 08:32:38.932631'),
(6, 'liquids', '2023-10-16 18:10:58.236496'),
(7, 'assets', '2023-10-27 18:30:48.349296'),
(8, 'consumablesxx', '2024-01-16 11:20:00.294370'),
(10, 'consumables hamza', '2024-01-16 12:06:17.451058');

-- --------------------------------------------------------

--
-- Table structure for table `stocksbrands`
--
-- Creation: Jan 16, 2024 at 02:48 PM
--

DROP TABLE IF EXISTS `stocksbrands`;
CREATE TABLE `stocksbrands` (
  `brandid` int(50) NOT NULL,
  `stockid` int(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `created_on` datetime(6) DEFAULT current_timestamp(6),
  `updated_on` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `stocksbrands`:
--

--
-- Dumping data for table `stocksbrands`
--

INSERT INTO `stocksbrands` (`brandid`, `stockid`, `brand`, `created_on`, `updated_on`) VALUES
(8, 9, 'generalx', '2024-01-16 17:02:50.476585', NULL),
(9, 9, 'General', '2024-01-16 17:03:57.114446', NULL),
(24, 2, 'global', '2024-01-16 23:24:50.695877', NULL),
(29, 4, 'JJEAJW', '2024-01-17 00:32:38.365174', NULL),
(32, 2, 'okdfkosdfkako', '2024-01-17 07:05:52.961500', NULL),
(33, 2, 'ksdkaDK', '2024-01-17 07:10:39.605665', NULL),
(34, 2, 'kkjdjdjdjjjjjvj', '2024-01-17 07:10:42.822554', NULL),
(35, 2, 'kvkekk', '2024-01-17 07:10:45.812007', NULL),
(36, 2, 'dkdkd', '2024-01-17 07:10:49.252495', NULL),
(37, 10, 'kxksk', '2024-01-17 07:11:47.090632', NULL),
(38, 10, 'kkevksdk', '2024-01-17 07:11:49.663921', NULL),
(39, 10, 'kdfvksvkk', '2024-01-17 07:11:52.191621', NULL),
(40, 10, 'kfkkdksdk', '2024-01-17 07:11:54.941315', NULL),
(41, 10, 'kkfvksdfk', '2024-01-17 07:11:58.479926', NULL),
(42, 7, 'mildred bag 1', '2024-01-17 22:14:28.539151', NULL),
(43, 7, 'mildred bag 2', '2024-01-17 22:14:34.686189', NULL),
(44, 3, 'genesis', '2024-01-20 07:32:59.714127', NULL),
(45, 3, 'filla', '2024-01-20 07:33:04.156574', NULL),
(46, 8, 'cotton 1', '2024-01-20 07:33:16.289692', NULL),
(47, 8, 'cotton 2', '2024-01-20 07:33:19.874390', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stocksesrow`
--
-- Creation: Jan 22, 2024 at 09:50 PM
-- Last update: Jan 22, 2024 at 11:12 PM
--

DROP TABLE IF EXISTS `stocksesrow`;
CREATE TABLE `stocksesrow` (
  `esrowid` int(20) NOT NULL,
  `productordersid` int(20) NOT NULL,
  `stockid` int(20) NOT NULL,
  `brandid` int(20) NOT NULL,
  `batchnumber` varchar(50) NOT NULL,
  `addedon` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `receivedon` datetime(6) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `type` varchar(50) NOT NULL DEFAULT 'debit',
  `qty` int(50) NOT NULL,
  `requisitionid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `stocksesrow`:
--

--
-- Dumping data for table `stocksesrow`
--

INSERT INTO `stocksesrow` (`esrowid`, `productordersid`, `stockid`, `brandid`, `batchnumber`, `addedon`, `receivedon`, `status`, `type`, `qty`, `requisitionid`) VALUES
(33, 3, 3, 44, 'LOT67', '2024-01-22 22:57:24.145402', NULL, 'pending', 'debit', 500, 15),
(34, 2, 4, 29, 'EIEI', '2024-01-23 00:12:52.684481', NULL, 'pending', 'debit', 500, 16);

-- --------------------------------------------------------

--
-- Table structure for table `stocktransactions`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `stocktransactions`;
CREATE TABLE `stocktransactions` (
  `keyid` int(255) NOT NULL,
  `stockid` int(100) NOT NULL,
  `quantity` int(255) NOT NULL,
  `batchno` varchar(50) NOT NULL,
  `added_on` datetime(6) DEFAULT NULL,
  `updated_on` datetime(6) DEFAULT NULL,
  `purchaseunit` varchar(100) NOT NULL,
  `supplierid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `stocktransactions`:
--

-- --------------------------------------------------------

--
-- Table structure for table `stoolanalysisresult`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `stoolanalysisresult`;
CREATE TABLE `stoolanalysisresult` (
  `id` int(100) NOT NULL,
  `comments` varchar(50) NOT NULL,
  `billingid` int(50) NOT NULL,
  `patientid` bigint(50) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL ON UPDATE current_timestamp(6),
  `results` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`results`)),
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `stoolanalysisresult`:
--

--
-- Dumping data for table `stoolanalysisresult`
--

INSERT INTO `stoolanalysisresult` (`id`, `comments`, `billingid`, `patientid`, `created_on`, `updated_on`, `results`, `employeeid`) VALUES
(1, '<p>dfkfkkdksdks</p>', 214, 2023101539, '2023-12-04 04:26:12.661443', NULL, '[{\"name\":\"color\",\"value\":\"Yellow\"},{\"name\":\"consistency\",\"value\":\"liquid\"},{\"name\":\"Frank blood\",\"value\":\"present\"},{\"name\":\"Mucus\",\"value\":\"present\"},{\"name\":\"Parasites\",\"value\":\"present\"},{\"name\":\"Reaction\",\"value\":\"Acidic\"},{\"name\":\"Occult blood\",\"value\":\"present\"},{\"name\":\"RBC\",\"value\":\"present\"},{\"name\":\"Pus cells\",\"value\":\"present\"},{\"name\":\"Macrophages\",\"value\":\"present\"},{\"name\":\"Fat globules\",\"value\":\"present\"},{\"name\":\"Starch granules\",\"value\":\"present\"},{\"name\":\"Vegetable cells\",\"value\":\"present\"},{\"name\":\"Ova\",\"value\":\"present\"},{\"name\":\"Cysts\",\"value\":\"present\"}]', NULL),
(2, '<p>ejjejejjw2j1jwj</p>', 217, 20239720, '2023-12-07 11:41:39.434497', NULL, '[{\"name\":\"color\",\"value\":\"Yellow\"},{\"name\":\"consistency\",\"value\":\"semi-solid\"},{\"name\":\"Frank blood\",\"value\":\"present\"},{\"name\":\"Mucus\",\"value\":\"present\"},{\"name\":\"Parasites\",\"value\":\"present\"},{\"name\":\"Reaction\",\"value\":\"Acidic\"},{\"name\":\"Occult blood\",\"value\":\"present\"},{\"name\":\"RBC\",\"value\":\"present\"},{\"name\":\"Pus cells\",\"value\":\"present\"},{\"name\":\"Macrophages\",\"value\":\"present\"},{\"name\":\"Fat globules\",\"value\":\"present\"},{\"name\":\"Starch granules\",\"value\":\"present\"},{\"name\":\"Vegetable cells\",\"value\":\"present\"},{\"name\":\"Ova\",\"value\":\"present\"},{\"name\":\"Cysts\",\"value\":\"present\"}]', 2);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier` (
  `supplierid` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `phonenumber` int(255) NOT NULL,
  `contactperson` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `supplier`:
--

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplierid`, `name`, `address`, `date`, `phonenumber`, `contactperson`, `region`, `email`) VALUES
(1, 'johnson johnson', 'jfkwk', '2023-10-11 10:58:08.074301', 595964565, 'tiifu shefik ', 'Upper East', 'lkk2@gmail.com'),
(3, 'king joe suppliers', 'Kalpohin Lowcost 30A', '2023-10-11 12:50:16.958579', 595964565, 'Tiifu Hamza', 'Northern', 'hamzatiifu455jsdjs5@99gmail.com'),
(4, 'Tiifu adams', 'yipala r/c primary school', '2024-01-10 11:00:36.159161', 241758550, 'tiifu hamza kojo hamza', 'Savannah', 'xelobcoder@gmail.com'),
(5, 'Barakah Delimwine', 'kalphonin lowcost', '2024-01-11 08:56:30.798402', 505898484, 'Tiifu nHamza', 'Northern', 'hamzatiifu45@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `supplierorderscount`
--
-- Creation: Jan 10, 2024 at 11:11 AM
--

DROP TABLE IF EXISTS `supplierorderscount`;
CREATE TABLE `supplierorderscount` (
  `id` int(50) NOT NULL,
  `supplierid` int(50) NOT NULL,
  `ordersDelivered` int(50) NOT NULL,
  `ordersPending` int(50) NOT NULL,
  `updated_on` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `supplierorderscount`:
--

-- --------------------------------------------------------

--
-- Table structure for table `syphilis`
--
-- Creation: Nov 25, 2023 at 01:19 PM
--

DROP TABLE IF EXISTS `syphilis`;
CREATE TABLE `syphilis` (
  `id` int(100) NOT NULL,
  `sampletype` varchar(50) NOT NULL,
  `reaction` varchar(25) NOT NULL,
  `result` varchar(25) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `billingid` int(100) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000' ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `syphilis`:
--

--
-- Dumping data for table `syphilis`
--

INSERT INTO `syphilis` (`id`, `sampletype`, `reaction`, `result`, `patientid`, `billingid`, `comments`, `created_on`, `updated_on`) VALUES
(1, 'serum', 'reactive', 'negative', 2023101539, 206, '<p>j2j2rjjq</p>', '2023-11-25 05:18:43.170977', '2023-12-02 03:39:52.911324'),
(5, 'serum', 'reactive', 'positive', 2023101537, 211, 'jdfkdkk', '2023-11-28 14:11:18.148120', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `tax`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `tax`;
CREATE TABLE `tax` (
  `name` varchar(50) NOT NULL,
  `value` int(50) NOT NULL,
  `createdOn` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `apply` varchar(10) NOT NULL DEFAULT 'Yes',
  `id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `tax`:
--

--
-- Dumping data for table `tax`
--

INSERT INTO `tax` (`name`, `value`, `createdOn`, `apply`, `id`) VALUES
('VAT', 10, '2023-11-08 22:28:29.972006', 'No', 1),
('NHIS-Levy', 3, '2023-11-08 22:40:38.408875', 'No', 2),
('E-levy', 4, '2023-11-08 23:49:12.457009', 'No', 3),
('sanitation Tax', 2, '2023-11-08 23:52:22.074302', 'No', 4),
('Energy Tax', 1, '2023-11-08 23:53:42.261833', 'No', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tempo`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `tempo`;
CREATE TABLE `tempo` (
  `ID` int(144) NOT NULL,
  `TITLE` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `tempo`:
--

-- --------------------------------------------------------

--
-- Table structure for table `test_ascension`
--
-- Creation: Dec 26, 2023 at 08:50 AM
-- Last update: Jan 22, 2024 at 09:19 PM
--

DROP TABLE IF EXISTS `test_ascension`;
CREATE TABLE `test_ascension` (
  `id` int(255) NOT NULL,
  `testid` int(11) NOT NULL,
  `billingid` int(11) NOT NULL,
  `collection` varchar(50) DEFAULT 'false',
  `processing` varchar(50) DEFAULT 'false',
  `ready` varchar(50) DEFAULT 'false',
  `processing_date` datetime(6) DEFAULT NULL,
  `collection_date` datetime(6) DEFAULT NULL,
  `ready_date` timestamp(6) NULL DEFAULT NULL,
  `printedNumber` int(25) DEFAULT NULL,
  `printedDate` datetime(6) DEFAULT NULL,
  `approvalStatus` tinyint(1) NOT NULL DEFAULT 0,
  `Scientist` int(10) DEFAULT NULL,
  `ApprovedBy` int(10) DEFAULT NULL,
  `declineMessage` varchar(255) DEFAULT NULL,
  `actionPlan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `test_ascension`:
--

--
-- Dumping data for table `test_ascension`
--

INSERT INTO `test_ascension` (`id`, `testid`, `billingid`, `collection`, `processing`, `ready`, `processing_date`, `collection_date`, `ready_date`, `printedNumber`, `printedDate`, `approvalStatus`, `Scientist`, `ApprovedBy`, `declineMessage`, `actionPlan`) VALUES
(220, 19, 172, 'true', 'false', 'false', NULL, '2023-11-17 00:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(221, 19, 173, 'true', 'false', 'false', NULL, '2023-11-17 00:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(222, 19, 174, 'true', 'false', 'false', NULL, '2023-11-17 00:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(223, 19, 175, 'true', 'false', 'false', NULL, '2023-11-17 00:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(324, 1, 219, 'true', 'true', 'true', '2023-12-12 09:22:39.000000', '2023-12-12 17:22:10.035000', '2023-12-12 17:23:08.000000', NULL, NULL, 1, NULL, 2, NULL, NULL),
(325, 56, 219, 'true', 'true', 'true', '2023-12-12 09:22:40.000000', '2023-12-12 17:22:11.593000', '2023-12-12 17:23:17.000000', NULL, NULL, 1, NULL, 2, NULL, NULL),
(326, 12, 219, 'true', 'true', 'true', '2023-12-12 09:22:41.000000', '2023-12-12 17:22:10.774000', '2023-12-12 17:22:59.000000', NULL, NULL, 1, NULL, 2, NULL, NULL),
(371, 1, 233, 'true', 'false', 'false', NULL, '2023-12-15 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(372, 11, 233, 'true', 'false', 'false', NULL, '2023-12-15 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(373, 10, 233, 'true', 'false', 'false', NULL, '2023-12-15 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(375, 10, 235, 'true', 'false', 'false', NULL, '2024-01-08 10:06:33.014000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(414, 11, 258, 'true', 'false', 'false', NULL, '2023-12-16 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(415, 10, 258, 'true', 'false', 'false', NULL, '2023-12-16 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(416, 2, 258, 'true', 'false', 'false', NULL, '2023-12-16 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(417, 34, 258, 'true', 'false', 'false', NULL, '2023-12-16 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(418, 12, 258, 'true', 'false', 'false', NULL, '2023-12-16 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(425, 1, 263, 'true', 'false', 'false', NULL, '2023-12-16 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(426, 19, 264, 'true', 'false', 'false', NULL, '2024-01-06 20:13:59.666000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(427, 19, 265, 'true', 'false', 'true', NULL, '2024-01-06 12:26:11.508000', '2024-01-22 21:19:03.000000', NULL, NULL, 0, NULL, NULL, NULL, NULL),
(428, 16, 265, 'true', 'false', 'true', NULL, '2024-01-06 12:26:12.286000', '2024-01-22 21:18:50.000000', NULL, NULL, 0, NULL, NULL, NULL, NULL),
(429, 1, 265, 'true', 'false', 'false', NULL, '2024-01-06 12:26:13.114000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(531, 6, 283, 'true', 'true', 'true', '2024-01-06 21:14:24.000000', '2024-01-06 20:13:15.668000', '2024-01-22 21:19:24.000000', NULL, NULL, 0, NULL, NULL, NULL, NULL),
(532, 3, 283, 'true', 'true', 'true', '2024-01-06 21:14:24.000000', '2024-01-06 20:13:16.272000', '2024-01-06 20:14:58.000000', NULL, NULL, 1, NULL, 2, NULL, NULL),
(533, 10, 283, 'true', 'true', 'true', '2024-01-06 21:14:25.000000', '2024-01-05 23:00:00.000000', '2024-01-06 20:15:13.000000', NULL, NULL, 1, NULL, 2, NULL, NULL),
(534, 11, 283, 'true', 'true', 'true', '2024-01-06 21:14:26.000000', '2024-01-05 23:00:00.000000', '2024-01-06 20:15:23.000000', NULL, NULL, 1, NULL, 2, NULL, NULL),
(535, 12, 283, 'true', 'true', 'true', '2024-01-06 21:14:30.000000', '2024-01-05 23:00:00.000000', '2024-01-06 20:34:16.000000', NULL, NULL, 1, NULL, 2, NULL, NULL),
(536, 13, 283, 'true', 'true', 'false', '2024-01-06 21:14:31.000000', '2024-01-06 20:13:16.919000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(537, 15, 283, 'true', 'true', 'true', '2024-01-06 21:14:35.000000', '2024-01-05 23:00:00.000000', '2024-01-06 20:14:43.000000', NULL, NULL, 1, NULL, 2, NULL, NULL),
(538, 8, 284, 'true', 'false', 'false', NULL, '2024-01-08 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(539, 5, 284, 'true', 'false', 'false', NULL, '2024-01-08 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(540, 54, 284, 'true', 'false', 'false', NULL, '2024-01-08 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(541, 20, 284, 'true', 'false', 'false', NULL, '2024-01-08 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(542, 31, 284, 'true', 'false', 'false', NULL, '2024-01-08 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(543, 51, 284, 'true', 'false', 'false', NULL, '2024-01-08 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(544, 1, 285, 'true', 'false', 'false', NULL, '2024-01-08 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(545, 11, 285, 'true', 'false', 'false', NULL, '2024-01-08 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(546, 4, 285, 'true', 'false', 'false', NULL, '2024-01-08 23:00:00.000000', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(547, 19, 286, 'true', 'true', 'true', '2024-01-18 18:43:57.000000', '2024-01-18 17:41:54.153000', '2024-01-22 21:19:13.000000', NULL, NULL, 0, NULL, NULL, NULL, NULL),
(548, 1, 286, 'true', 'true', 'true', '2024-01-18 18:43:58.000000', '2024-01-18 17:41:55.428000', '2024-01-18 17:44:52.000000', NULL, NULL, 1, NULL, 2, NULL, NULL);

--
-- Triggers `test_ascension`
--
DROP TRIGGER IF EXISTS `onDelete`;
DELIMITER $$
CREATE TRIGGER `onDelete` AFTER DELETE ON `test_ascension` FOR EACH ROW BEGIN 
DELETE FROM samplestatus WHERE testid = OLD.testid
AND billingid = OLD.billingid;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `samplestatus`;
DELIMITER $$
CREATE TRIGGER `samplestatus` AFTER INSERT ON `test_ascension` FOR EACH ROW BEGIN
INSERT INTO samplestatus(billingid,testid,approvalstatus,ascensionid) VALUES(NEW.billingid,NEW.testid,0,NEW.id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `test_categories`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `test_categories`;
CREATE TABLE `test_categories` (
  `ID` int(255) NOT NULL,
  `CATEGORY` varchar(255) NOT NULL,
  `DESCRIPTION` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `test_categories`:
--

-- --------------------------------------------------------

--
-- Table structure for table `test_panels`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `test_panels`;
CREATE TABLE `test_panels` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` int(50) NOT NULL,
  `price` int(20) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `sample` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `sample_container` varchar(100) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `qty_required` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `test_panels`:
--

--
-- Dumping data for table `test_panels`
--

INSERT INTO `test_panels` (`id`, `name`, `category`, `price`, `created_on`, `sample`, `description`, `sample_container`, `unit`, `qty_required`) VALUES
(1, 'Malaria', 2, 20, '2023-04-12 05:54:35.000000', '4', 'jwdfjwdjkwdjkfjkwejk wdfkwegkekge\nhejhwdjgjev\negjejgjegje', 'urine', 'mls', '499'),
(2, 'Glycated Heamoglobin', 3, 600, '2023-04-12 07:02:57.000000', '4', 'test for blood sugar usage ', 'edta tube', 'mls', '4'),
(3, 'Widal', 2, 600, '2023-04-12 13:08:29.000000', '4', 'For testing salmonella typhi infection', 'edta tube', 'mls', '3'),
(4, 'blood grouping', 2, 50, '2023-04-12 15:28:43.000000', '4', 'nullKFKWKFWEKFKWFKQKFKQWFKWKFKWFKQWK', 'edta tube', 'mls', '32'),
(5, 'cardiac enzymes', 1, 600, '2023-04-12 15:29:35.000000', '4', 'analysis of cardiac enzymes', 'gell tube ', 'g/dl', '5'),
(6, 'Hepatitis B', 2, 500, '2023-04-13 07:06:15.000000', '6', 'Hepatitis b is not null', 'edta tube', 'mls', '320'),
(7, 'Hepatitis B Profile', 5, 500, '2023-04-13 07:20:25.000000', 'serum', 'Test for all antigens related to viral hepatitis ', 'gell tube', 'mls', '50'),
(8, 'Hepatitis C', 1, 600, '2023-04-13 07:21:47.000000', '9', 'Testing for Hepatitis C infection', 'edta tube', 'mls', '3'),
(10, 'liver function test', 1, 509, '2023-04-13 18:53:09.000000', '4', 'priced here is not null be offensive', 'gell tube', 'mls', '3'),
(11, 'renal function test', 2, 500, '2023-04-13 18:53:34.000000', 'serum', 'Renal functional test is a test to check the function of the kidney', 'gell tube', 'mls', '5'),
(12, 'Lipid profile', 4, 900, '2023-04-17 12:15:45.000000', 'serum', 'efjwejfjwfjq', 'gell tube', 'mls', '4'),
(13, 'urinalysis', 5, 60, '2023-04-27 01:48:23.000000', 'urine', 'Urine taking', 'urine', 'mls', '50'),
(14, '', 3, 0, '2023-04-30 09:16:19.000000', '', NULL, '', '', NULL),
(15, 'Thyroid functional test', 3, 600, '2023-05-02 22:33:32.000000', 'serum', 'Test for the functionality of the thyroid', 'gell tube', 'mg/dl', '5'),
(16, 'BetaHcg', 5, 600, '2023-05-07 12:21:11.000000', '2', 'BetaHcg', 'edta tube', 'mls', '4'),
(17, 'aids', 2, 20, '2023-05-07 12:34:48.000000', 'blood', 'testing for aids test', 'blood', 'mls', '4'),
(19, 'estimated sedimentation rate (ESR)', 1, 60, '2023-05-07 23:34:36.000000', 'blood', 'uefueururu', 'gell tube', 'mls', '5'),
(20, 'fasting blood sugar', 3, 20, '2023-05-16 10:45:28.000000', 'blood', 'testing for blood sugar in the body', 'edta tube', 'mg/dl', '3'),
(21, 'random blood sugar', 4, 20, '2023-05-16 10:46:09.000000', 'blood', 'sugar testing ', 'gell tube ', 'mg/dl', '3'),
(22, 'full blood count', 3, 50, '2023-04-30 09:16:19.000000', 'blood', 'Blood cell analysis', 'edta tube', 'mls', '4'),
(25, 'stool analysis', 2, 29, '2023-07-15 22:39:21.000000', 'stool', 'rjgje', 'stool container', 'g', '10g'),
(26, 'clotting and bleeding time', 3, 200, '2023-07-16 00:08:49.000000', '3', 'jdjdjdj', 'edta tube', 'mls', '5'),
(27, 'helicobacter pylori', 5, 50, '2023-07-17 10:08:56.000000', '4', 'jgjwgjk', 'edta tube', 'mls', '5'),
(28, 'semen analysis', 4, 200, '2023-07-17 10:12:00.000000', 'semen', 'eguirlkgwdjlguwjk,m', 'semen', 'mls', '5'),
(31, 'Luteinizing Hormone', 3, 50, '2023-07-17 10:20:19.000000', 'blood', 'uhfjsdjvjk', 'gell tube', 'mls', '5'),
(32, 'Follicle Stimulating Hormone', 3, 50, '2023-07-17 10:20:46.000000', 'blood', 'uhfjsdjvjk', 'gell tube', 'mls', '5'),
(33, 'heamoglobin test', 4, 49, '2023-08-24 22:41:14.000000', 'urine', 'lorem ipsum', 'Edta Tube', 'mls', '5'),
(34, 'Haemoglogin electrophoreesis', 4, 500, '2023-08-25 08:46:19.000000', 'blood', 'AGREEMENT\n\n\nTHIS agreement is entered into as of ___________________ by and between kadimart enterprise, a subsidiary of Kadima Company limited and __________________ also referred herein as a sale representative both of whom agree to be bound by this agr', 'edta tube', 'mls', '4'),
(50, 'abdominal ultrasound scan', 6, 100, '2023-10-03 07:46:28.000000', 'null', 'null', 'null', '', '50'),
(51, 'obstetrics scan', 6, 80, '2023-10-03 10:55:42.000000', '3', NULL, '', '', '93'),
(52, 'breast scan', 6, 200, '2023-10-04 21:58:38.000000', '', NULL, '', '', NULL),
(53, 'pelvic scan', 6, 60, '2023-10-04 21:58:38.000000', '', NULL, '', '', NULL),
(54, 'abdominal pelvic scan', 6, 120, '2023-10-04 21:59:25.000000', '', NULL, '', '', NULL),
(55, 'urological scan', 5, 200, '2023-10-04 21:59:25.000000', '', NULL, '', '', NULL),
(56, 'prostate specific antigen test', 3, 100, '2023-10-07 10:02:20.000000', '2', 'prostate specific antigen test is indicator of the growth of the prostate gland', 'gell tubbe', 'mls', '4'),
(57, 'syphilis', 5, 40, '2023-11-25 02:31:33.000000', '3', NULL, '', '', '5'),
(58, 'beta thalassemia', 3, 50, '0000-00-00 00:00:00.000000', '3', NULL, 'edta tube', 'mls', '3mls');

-- --------------------------------------------------------

--
-- Table structure for table `typhoid_test`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `typhoid_test`;
CREATE TABLE `typhoid_test` (
  `TESTID` int(255) NOT NULL,
  `PATIENTID` bigint(255) NOT NULL,
  `BILLINGID` int(255) NOT NULL,
  `RESULT` varchar(255) NOT NULL,
  `COMMENTS` varchar(255) NOT NULL,
  `TYPHI_O` float DEFAULT NULL,
  `TYPHI_H` float DEFAULT NULL,
  `PARATYPHI_BH` float DEFAULT NULL,
  `PARATYPHI_AH` float DEFAULT NULL,
  `DATE` date NOT NULL DEFAULT current_timestamp(),
  `TIME` time(6) NOT NULL DEFAULT current_timestamp(),
  `ENTERED_BY` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `typhoid_test`:
--

-- --------------------------------------------------------

--
-- Table structure for table `urinalysisresult`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `urinalysisresult`;
CREATE TABLE `urinalysisresult` (
  `urinalysisKey` int(255) NOT NULL,
  `appearance` varchar(50) NOT NULL,
  `color` varchar(20) NOT NULL,
  `urobilinogen` varchar(50) NOT NULL,
  `ketones` varchar(50) NOT NULL,
  `bilirubin` varchar(50) NOT NULL,
  `nitrite` varchar(20) NOT NULL,
  `microalbumin` varchar(20) NOT NULL,
  `glucose` varchar(20) NOT NULL,
  `specific_gravity` float NOT NULL,
  `ph` float NOT NULL,
  `microscopy` text DEFAULT NULL,
  `billingid` int(20) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `patientid` bigint(255) NOT NULL,
  `blood` varchar(50) NOT NULL,
  `leukocytes` varchar(50) NOT NULL,
  `employeeid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `urinalysisresult`:
--

--
-- Dumping data for table `urinalysisresult`
--

INSERT INTO `urinalysisresult` (`urinalysisKey`, `appearance`, `color`, `urobilinogen`, `ketones`, `bilirubin`, `nitrite`, `microalbumin`, `glucose`, `specific_gravity`, `ph`, `microscopy`, `billingid`, `remarks`, `patientid`, `blood`, `leukocytes`, `employeeid`) VALUES
(1, 'Hazy', 'straw', 'negative', 'positive(+)', 'negative', 'negative', 'trace', 'negative', 1.05, 3, NULL, 209, '\nheywyqwyqwyqwy', 2023854, 'yellpw', 'positive(+)', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--
-- Creation: Jan 11, 2024 at 12:17 PM
--

DROP TABLE IF EXISTS `warehouse`;
CREATE TABLE `warehouse` (
  `id` int(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_on` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `warehouse`:
--

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`id`, `name`, `created_on`, `updated_on`) VALUES
(1, 'tiifu', '2024-01-11 15:21:54.399969', NULL),
(2, 'tiifuxxx', '2024-01-11 15:22:33.650080', NULL),
(3, 'warehouse 573 ddd', '2024-01-11 15:24:47.878933', NULL),
(4, 'Warehouse 979000', '2024-01-11 15:40:09.038779', NULL),
(5, 'genesis 111', '2024-01-11 15:42:37.246720', NULL),
(6, 'Kalpohin Lowcost 30A', '2024-01-11 15:51:37.700449', NULL),
(7, 'Warehouse 2', '2024-01-11 15:57:16.657254', NULL),
(8, 'Warehouse 3', '2024-01-11 15:57:57.837066', NULL),
(9, 'Attabissinm ', '2024-01-11 16:22:49.722913', NULL),
(10, 'hamza', '2024-01-12 10:17:58.500114', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wastagecount`
--
-- Creation: Jan 17, 2024 at 01:43 PM
--

DROP TABLE IF EXISTS `wastagecount`;
CREATE TABLE `wastagecount` (
  `id` int(100) NOT NULL,
  `amount` int(100) NOT NULL,
  `wastedCount` int(50) NOT NULL,
  `updated_on` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `wastagecount`:
--

-- --------------------------------------------------------

--
-- Table structure for table `wastagehx`
--
-- Creation: Jan 18, 2024 at 03:32 PM
--

DROP TABLE IF EXISTS `wastagehx`;
CREATE TABLE `wastagehx` (
  `id` int(100) NOT NULL,
  `stockid` int(100) NOT NULL,
  `brandid` int(100) NOT NULL,
  `removedOn` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `qty` int(100) NOT NULL,
  `price` int(100) NOT NULL,
  `departmentid` int(100) NOT NULL,
  `batchnumber` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `wastagehx`:
--

-- --------------------------------------------------------

--
-- Table structure for table `you`
--
-- Creation: Dec 26, 2023 at 08:50 AM
--

DROP TABLE IF EXISTS `you`;
CREATE TABLE `you` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `you`:
--

--
-- Dumping data for table `you`
--

INSERT INTO `you` (`id`, `user`) VALUES
(4, 4),
(5, 7),
(6, 8),
(7, 9),
(8, 10),
(9, 11),
(10, 12),
(11, 13),
(12, 14),
(13, 15),
(14, 16),
(15, 17),
(16, 18),
(17, 19),
(18, 20),
(19, 21),
(20, 22),
(21, 23),
(22, 24),
(23, 25),
(24, 26),
(25, 27),
(26, 28),
(27, 29),
(28, 30);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activation`
--
ALTER TABLE `activation`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `applicationsettings`
--
ALTER TABLE `applicationsettings`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `betathalassemia`
--
ALTER TABLE `betathalassemia`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`billingid`),
  ADD KEY `BILLINGID` (`billingid`);

--
-- Indexes for table `billinghx`
--
ALTER TABLE `billinghx`
  ADD PRIMARY KEY (`KeyID`);

--
-- Indexes for table `billingtemporarytable`
--
ALTER TABLE `billingtemporarytable`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `bloodcultureandsensitivitytestsetup`
--
ALTER TABLE `bloodcultureandsensitivitytestsetup`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `bloodgroup`
--
ALTER TABLE `bloodgroup`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branchid`);

--
-- Indexes for table `clinicianbasicinfo`
--
ALTER TABLE `clinicianbasicinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clinicianpaymentinfo`
--
ALTER TABLE `clinicianpaymentinfo`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `clinicianscredentials`
--
ALTER TABLE `clinicianscredentials`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clinicianid` (`clinicianid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `clotbleedingtime`
--
ALTER TABLE `clotbleedingtime`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `commodity`
--
ALTER TABLE `commodity`
  ADD PRIMARY KEY (`comid`);

--
-- Indexes for table `companyprofile`
--
ALTER TABLE `companyprofile`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `composedemails`
--
ALTER TABLE `composedemails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departmentconsumption`
--
ALTER TABLE `departmentconsumption`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departmentconsumptionhx`
--
ALTER TABLE `departmentconsumptionhx`
  ADD PRIMARY KEY (`comsumeid`);

--
-- Indexes for table `departmentrequisitionhx`
--
ALTER TABLE `departmentrequisitionhx`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `department` (`department`);

--
-- Indexes for table `departmentstocks`
--
ALTER TABLE `departmentstocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emaillog`
--
ALTER TABLE `emaillog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emailpreference`
--
ALTER TABLE `emailpreference`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fshresult`
--
ALTER TABLE `fshresult`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `fshsetup`
--
ALTER TABLE `fshsetup`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `generalemailsettings`
--
ALTER TABLE `generalemailsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generalstocks`
--
ALTER TABLE `generalstocks`
  ADD PRIMARY KEY (`stockid`);

--
-- Indexes for table `generalstorecredithx`
--
ALTER TABLE `generalstorecredithx`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generalstoredebithx`
--
ALTER TABLE `generalstoredebithx`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `glycated_haemoglobin`
--
ALTER TABLE `glycated_haemoglobin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `haemoglobinelectrophoresis`
--
ALTER TABLE `haemoglobinelectrophoresis`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `hepatitisbresult`
--
ALTER TABLE `hepatitisbresult`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hepatitisb_profile`
--
ALTER TABLE `hepatitisb_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hepatitiscresult`
--
ALTER TABLE `hepatitiscresult`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventorycustomization`
--
ALTER TABLE `inventorycustomization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lhresult`
--
ALTER TABLE `lhresult`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `lhsetup`
--
ALTER TABLE `lhsetup`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `loginlogs`
--
ALTER TABLE `loginlogs`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `mainstoresupply`
--
ALTER TABLE `mainstoresupply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `malaria`
--
ALTER TABLE `malaria`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `manager_sample_descision`
--
ALTER TABLE `manager_sample_descision`
  ADD PRIMARY KEY (`sampleid`);

--
-- Indexes for table `me`
--
ALTER TABLE `me`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_patients`
--
ALTER TABLE `new_patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderreceivedaccountsummary`
--
ALTER TABLE `orderreceivedaccountsummary`
  ADD UNIQUE KEY `orderTransactionid` (`orderTransactionid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`productordersid`);

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organizationaccountinformation`
--
ALTER TABLE `organizationaccountinformation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `organization_id` (`organizationid`);

--
-- Indexes for table `organizationcontactperson`
--
ALTER TABLE `organizationcontactperson`
  ADD PRIMARY KEY (`id`),
  ADD KEY `organization_id` (`organizationid`);

--
-- Indexes for table `pageaccess`
--
ALTER TABLE `pageaccess`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `patientemmergencycontactinformation`
--
ALTER TABLE `patientemmergencycontactinformation`
  ADD PRIMARY KEY (`keyid`),
  ADD UNIQUE KEY `patientid` (`patientid`);

--
-- Indexes for table `patientsaddress`
--
ALTER TABLE `patientsaddress`
  ADD PRIMARY KEY (`keyid`),
  ADD UNIQUE KEY `patientid` (`patientid`),
  ADD UNIQUE KEY `patientid_2` (`patientid`);

--
-- Indexes for table `patients_credentials`
--
ALTER TABLE `patients_credentials`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `patientid` (`patientid`);

--
-- Indexes for table `patients_settings`
--
ALTER TABLE `patients_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `patientid` (`patientid`);

--
-- Indexes for table `paymentmodes`
--
ALTER TABLE `paymentmodes`
  ADD PRIMARY KEY (`KeyID`),
  ADD UNIQUE KEY `PaymentMode` (`PaymentMode`);

--
-- Indexes for table `performing_test`
--
ALTER TABLE `performing_test`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `psaresult`
--
ALTER TABLE `psaresult`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `psasetup`
--
ALTER TABLE `psasetup`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `result_aids`
--
ALTER TABLE `result_aids`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_beta_hcg`
--
ALTER TABLE `result_beta_hcg`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_cardiac_enzymes`
--
ALTER TABLE `result_cardiac_enzymes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result_comments`
--
ALTER TABLE `result_comments`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_esr`
--
ALTER TABLE `result_esr`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_fasting_blood_sugar`
--
ALTER TABLE `result_fasting_blood_sugar`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_function_full_blood_count`
--
ALTER TABLE `result_function_full_blood_count`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_function_liver`
--
ALTER TABLE `result_function_liver`
  ADD PRIMARY KEY (`liverid`);

--
-- Indexes for table `result_function_renal`
--
ALTER TABLE `result_function_renal`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_haemoglobin_electrophoresis`
--
ALTER TABLE `result_haemoglobin_electrophoresis`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_helicobacter_pylori`
--
ALTER TABLE `result_helicobacter_pylori`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_lipid_profile`
--
ALTER TABLE `result_lipid_profile`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_pregnancy_test`
--
ALTER TABLE `result_pregnancy_test`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `result_random_blood_sugar`
--
ALTER TABLE `result_random_blood_sugar`
  ADD PRIMARY KEY (`keyid`),
  ADD UNIQUE KEY `billingid` (`billingid`);

--
-- Indexes for table `result_thyroid_functional_test`
--
ALTER TABLE `result_thyroid_functional_test`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `result_widal`
--
ALTER TABLE `result_widal`
  ADD PRIMARY KEY (`KEYID`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`employeeid`);

--
-- Indexes for table `samplestatus`
--
ALTER TABLE `samplestatus`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `sampletype`
--
ALTER TABLE `sampletype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `samplingtest`
--
ALTER TABLE `samplingtest`
  ADD PRIMARY KEY (`TestKey`);

--
-- Indexes for table `scanreport`
--
ALTER TABLE `scanreport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semenanalysis`
--
ALTER TABLE `semenanalysis`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `setupbetathalassemia`
--
ALTER TABLE `setupbetathalassemia`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `setupglucose`
--
ALTER TABLE `setupglucose`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setupliteraturereview`
--
ALTER TABLE `setupliteraturereview`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setup_beta_hcg`
--
ALTER TABLE `setup_beta_hcg`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `setup_cardiac_enzymes`
--
ALTER TABLE `setup_cardiac_enzymes`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `setup_esr`
--
ALTER TABLE `setup_esr`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `setup_fullcount_paramters`
--
ALTER TABLE `setup_fullcount_paramters`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `setup_full_blood_count_test_general`
--
ALTER TABLE `setup_full_blood_count_test_general`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `setup_full_blood_count_test_male`
--
ALTER TABLE `setup_full_blood_count_test_male`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `setup_full_count_count_female`
--
ALTER TABLE `setup_full_count_count_female`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `setup_glycated_heamoglobin_test`
--
ALTER TABLE `setup_glycated_heamoglobin_test`
  ADD PRIMARY KEY (`TESTID`);

--
-- Indexes for table `setup_lipid_profile_test`
--
ALTER TABLE `setup_lipid_profile_test`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `setup_liver_function_test`
--
ALTER TABLE `setup_liver_function_test`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `setup_renal_function_test`
--
ALTER TABLE `setup_renal_function_test`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `setup_thyroid_test`
--
ALTER TABLE `setup_thyroid_test`
  ADD PRIMARY KEY (`setupid`);

--
-- Indexes for table `shelves`
--
ALTER TABLE `shelves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stockcategory`
--
ALTER TABLE `stockcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stocksbrands`
--
ALTER TABLE `stocksbrands`
  ADD PRIMARY KEY (`brandid`);

--
-- Indexes for table `stocksesrow`
--
ALTER TABLE `stocksesrow`
  ADD PRIMARY KEY (`esrowid`);

--
-- Indexes for table `stocktransactions`
--
ALTER TABLE `stocktransactions`
  ADD PRIMARY KEY (`keyid`);

--
-- Indexes for table `stoolanalysisresult`
--
ALTER TABLE `stoolanalysisresult`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplierid`);

--
-- Indexes for table `supplierorderscount`
--
ALTER TABLE `supplierorderscount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `syphilis`
--
ALTER TABLE `syphilis`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `billingid` (`billingid`);

--
-- Indexes for table `tax`
--
ALTER TABLE `tax`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tempo`
--
ALTER TABLE `tempo`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `TITLE` (`TITLE`);

--
-- Indexes for table `test_ascension`
--
ALTER TABLE `test_ascension`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_categories`
--
ALTER TABLE `test_categories`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `test_panels`
--
ALTER TABLE `test_panels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typhoid_test`
--
ALTER TABLE `typhoid_test`
  ADD PRIMARY KEY (`TESTID`);

--
-- Indexes for table `urinalysisresult`
--
ALTER TABLE `urinalysisresult`
  ADD PRIMARY KEY (`urinalysisKey`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wastagecount`
--
ALTER TABLE `wastagecount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wastagehx`
--
ALTER TABLE `wastagehx`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `you`
--
ALTER TABLE `you`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activation`
--
ALTER TABLE `activation`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `applicationsettings`
--
ALTER TABLE `applicationsettings`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `betathalassemia`
--
ALTER TABLE `betathalassemia`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `billingid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=287;

--
-- AUTO_INCREMENT for table `billinghx`
--
ALTER TABLE `billinghx`
  MODIFY `KeyID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=308;

--
-- AUTO_INCREMENT for table `billingtemporarytable`
--
ALTER TABLE `billingtemporarytable`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `bloodcultureandsensitivitytestsetup`
--
ALTER TABLE `bloodcultureandsensitivitytestsetup`
  MODIFY `keyid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bloodgroup`
--
ALTER TABLE `bloodgroup`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branchid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `clinicianbasicinfo`
--
ALTER TABLE `clinicianbasicinfo`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `clinicianpaymentinfo`
--
ALTER TABLE `clinicianpaymentinfo`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `clinicianscredentials`
--
ALTER TABLE `clinicianscredentials`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `clotbleedingtime`
--
ALTER TABLE `clotbleedingtime`
  MODIFY `keyid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `commodity`
--
ALTER TABLE `commodity`
  MODIFY `comid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `companyprofile`
--
ALTER TABLE `companyprofile`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `composedemails`
--
ALTER TABLE `composedemails`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `departmentconsumption`
--
ALTER TABLE `departmentconsumption`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `departmentconsumptionhx`
--
ALTER TABLE `departmentconsumptionhx`
  MODIFY `comsumeid` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `departmentrequisitionhx`
--
ALTER TABLE `departmentrequisitionhx`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `departmentstocks`
--
ALTER TABLE `departmentstocks`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `emaillog`
--
ALTER TABLE `emaillog`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `emailpreference`
--
ALTER TABLE `emailpreference`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fshresult`
--
ALTER TABLE `fshresult`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fshsetup`
--
ALTER TABLE `fshsetup`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `generalemailsettings`
--
ALTER TABLE `generalemailsettings`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `generalstocks`
--
ALTER TABLE `generalstocks`
  MODIFY `stockid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `generalstorecredithx`
--
ALTER TABLE `generalstorecredithx`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `generalstoredebithx`
--
ALTER TABLE `generalstoredebithx`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `glycated_haemoglobin`
--
ALTER TABLE `glycated_haemoglobin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `haemoglobinelectrophoresis`
--
ALTER TABLE `haemoglobinelectrophoresis`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hepatitisbresult`
--
ALTER TABLE `hepatitisbresult`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `hepatitisb_profile`
--
ALTER TABLE `hepatitisb_profile`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `hepatitiscresult`
--
ALTER TABLE `hepatitiscresult`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `inventorycustomization`
--
ALTER TABLE `inventorycustomization`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lhresult`
--
ALTER TABLE `lhresult`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lhsetup`
--
ALTER TABLE `lhsetup`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `loginlogs`
--
ALTER TABLE `loginlogs`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mainstoresupply`
--
ALTER TABLE `mainstoresupply`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `malaria`
--
ALTER TABLE `malaria`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `manager_sample_descision`
--
ALTER TABLE `manager_sample_descision`
  MODIFY `sampleid` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `me`
--
ALTER TABLE `me`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `new_patients`
--
ALTER TABLE `new_patients`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `productordersid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `organizationaccountinformation`
--
ALTER TABLE `organizationaccountinformation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `organizationcontactperson`
--
ALTER TABLE `organizationcontactperson`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pageaccess`
--
ALTER TABLE `pageaccess`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patientemmergencycontactinformation`
--
ALTER TABLE `patientemmergencycontactinformation`
  MODIFY `keyid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `patientsaddress`
--
ALTER TABLE `patientsaddress`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `patients_credentials`
--
ALTER TABLE `patients_credentials`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `patients_settings`
--
ALTER TABLE `patients_settings`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `paymentmodes`
--
ALTER TABLE `paymentmodes`
  MODIFY `KeyID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `performing_test`
--
ALTER TABLE `performing_test`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `psaresult`
--
ALTER TABLE `psaresult`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `psasetup`
--
ALTER TABLE `psasetup`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `result_aids`
--
ALTER TABLE `result_aids`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `result_beta_hcg`
--
ALTER TABLE `result_beta_hcg`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `result_cardiac_enzymes`
--
ALTER TABLE `result_cardiac_enzymes`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `result_comments`
--
ALTER TABLE `result_comments`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `result_esr`
--
ALTER TABLE `result_esr`
  MODIFY `keyid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `result_fasting_blood_sugar`
--
ALTER TABLE `result_fasting_blood_sugar`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `result_function_full_blood_count`
--
ALTER TABLE `result_function_full_blood_count`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `result_function_liver`
--
ALTER TABLE `result_function_liver`
  MODIFY `liverid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `result_function_renal`
--
ALTER TABLE `result_function_renal`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `result_helicobacter_pylori`
--
ALTER TABLE `result_helicobacter_pylori`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `result_lipid_profile`
--
ALTER TABLE `result_lipid_profile`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `result_pregnancy_test`
--
ALTER TABLE `result_pregnancy_test`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `result_random_blood_sugar`
--
ALTER TABLE `result_random_blood_sugar`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `result_thyroid_functional_test`
--
ALTER TABLE `result_thyroid_functional_test`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `result_widal`
--
ALTER TABLE `result_widal`
  MODIFY `KEYID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `employeeid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `samplestatus`
--
ALTER TABLE `samplestatus`
  MODIFY `keyid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=342;

--
-- AUTO_INCREMENT for table `setupbetathalassemia`
--
ALTER TABLE `setupbetathalassemia`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `setupglucose`
--
ALTER TABLE `setupglucose`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `setupliteraturereview`
--
ALTER TABLE `setupliteraturereview`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `setup_beta_hcg`
--
ALTER TABLE `setup_beta_hcg`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `setup_cardiac_enzymes`
--
ALTER TABLE `setup_cardiac_enzymes`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `setup_esr`
--
ALTER TABLE `setup_esr`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `setup_full_blood_count_test_general`
--
ALTER TABLE `setup_full_blood_count_test_general`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `setup_full_blood_count_test_male`
--
ALTER TABLE `setup_full_blood_count_test_male`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `setup_full_count_count_female`
--
ALTER TABLE `setup_full_count_count_female`
  MODIFY `keyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `setup_lipid_profile_test`
--
ALTER TABLE `setup_lipid_profile_test`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `setup_liver_function_test`
--
ALTER TABLE `setup_liver_function_test`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `setup_renal_function_test`
--
ALTER TABLE `setup_renal_function_test`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `setup_thyroid_test`
--
ALTER TABLE `setup_thyroid_test`
  MODIFY `setupid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shelves`
--
ALTER TABLE `shelves`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `stockcategory`
--
ALTER TABLE `stockcategory`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `stocksbrands`
--
ALTER TABLE `stocksbrands`
  MODIFY `brandid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `stocksesrow`
--
ALTER TABLE `stocksesrow`
  MODIFY `esrowid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `stoolanalysisresult`
--
ALTER TABLE `stoolanalysisresult`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplierid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `supplierorderscount`
--
ALTER TABLE `supplierorderscount`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `syphilis`
--
ALTER TABLE `syphilis`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `test_ascension`
--
ALTER TABLE `test_ascension`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=549;

--
-- AUTO_INCREMENT for table `test_panels`
--
ALTER TABLE `test_panels`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `urinalysisresult`
--
ALTER TABLE `urinalysisresult`
  MODIFY `urinalysisKey` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `warehouse`
--
ALTER TABLE `warehouse`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wastagecount`
--
ALTER TABLE `wastagecount`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `you`
--
ALTER TABLE `you`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
